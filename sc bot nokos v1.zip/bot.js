const { Telegraf, Markup } = require('telegraf');
const axios = require('axios');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const config = require('./config');
const qs = require('qs');

// ==================== PERBAIKAN MESSAGE UTILS ====================
const messageUtils = {
    // Edit message dengan fallback ke reply baru jika gagal - IMPROVED VERSION
    async safeEditMessage(ctx, text, keyboard = null, parse_mode = 'markdown') {
        try {
            if (ctx.updateType === 'callback_query' && ctx.callbackQuery?.message?.message_id) {
                // Escape text jika menggunakan Markdown untuk menghindari parsing error
                let safeText = text;
                if (parse_mode === 'Markdown' || parse_mode === 'markdown') {
                    // Gunakan escape markdown yang lebih aman
                    safeText = utils.escapeMarkdown(text);
                }
                
                await ctx.editMessageText(safeText, {
                    parse_mode: parse_mode,
                    reply_markup: keyboard ? keyboard.reply_markup : undefined,
                    disable_web_page_preview: true
                });
                return true;
            }
            return false;
        } catch (error) {
            console.log('⚠️ Cannot edit message:', error.message);
            
            // Jika error karena parsing entities, coba tanpa parse_mode
            if (error.message.includes('can\'t parse entities')) {
                try {
                    if (ctx.updateType === 'callback_query' && ctx.callbackQuery?.message?.message_id) {
                        await ctx.editMessageText(text, {
                            parse_mode: undefined, // Hapus parse_mode
                            reply_markup: keyboard ? keyboard.reply_markup : undefined,
                            disable_web_page_preview: true
                        });
                        return true;
                    }
                } catch (retryError) {
                    console.log('⚠️ Retry edit also failed:', retryError.message);
                }
            }
            
            return false;
        }
    },

    // Reply dengan auto-delete message sebelumnya jika ada - IMPROVED VERSION
    async replyWithEdit(ctx, text, keyboard = null, parse_mode = 'Markdown') {
        // Coba edit dulu
        const editSuccess = await this.safeEditMessage(ctx, text, keyboard, parse_mode);
        
        if (!editSuccess) {
            try {
                // Hapus pesan sebelumnya jika ada
                if (ctx.updateType === 'callback_query' && ctx.callbackQuery?.message?.message_id) {
                    try {
                        await ctx.deleteMessage();
                    } catch (e) {
                        // Ignore delete errors
                    }
                }
                
                // Kirim pesan baru dengan safe text
                let safeText = text;
                if (parse_mode === 'Markdown' || parse_mode === 'markdown') {
                    // Escape markdown characters untuk mencegah parsing error
                    safeText = utils.escapeMarkdown(text);
                } else if (parse_mode === 'HTML' || parse_mode === 'html') {
                    // Escape HTML characters
                    safeText = utils.escapeHtml(text);
                }
                
                await ctx.reply(safeText, {
                    parse_mode: parse_mode,
                    reply_markup: keyboard ? keyboard.reply_markup : undefined,
                    disable_web_page_preview: true
                });
            } catch (error) {
                console.error('Error sending message:', error);
                
                // Final fallback: kirim tanpa format
                try {
                    await ctx.reply(text, {
                        parse_mode: undefined,
                        reply_markup: keyboard ? keyboard.reply_markup : undefined,
                        disable_web_page_preview: true
                    });
                } catch (finalError) {
                    console.error('Final fallback also failed:', finalError.message);
                }
            }
        }
    }
};

// ==================== CRITICAL: BOT HEALTH MONITOR & AUTO-RESTART ====================

class BotHealthManager {
    constructor() {
        this.restartCount = 0;
        this.maxRestarts = 15;
        this.lastHealthCheck = Date.now();
        this.consecutiveErrors = 0;
        this.maxConsecutiveErrors = 8;
        this.healthCheckInterval = null;
        this.isShuttingDown = false;
        this.botStartTime = Date.now();
    }

    startHealthMonitor() {
        console.log('🏥 Starting health monitor system...');
        
        this.healthCheckInterval = setInterval(async () => {
            await this.performHealthCheck();
        }, 45000);
        
        setInterval(() => {
            this.monitorMemory();
        }, 60000);
    }

    async performHealthCheck() {
        try {
            const startTime = Date.now();
            
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Health check timeout')), 10000)
            );
            
            const healthCheckPromise = bot.telegram.getMe();
            await Promise.race([healthCheckPromise, timeoutPromise]);
            
            const responseTime = Date.now() - startTime;
            this.lastHealthCheck = Date.now();
            this.consecutiveErrors = 0;
            
            if (responseTime > 3000) {
                console.warn(`⚠️ Bot response slow: ${responseTime}ms`);
                await this.reportToOwner(`⚠️ Bot Response Slow: ${responseTime}ms - But still running`);
            }
            
        } catch (error) {
            this.consecutiveErrors++;
            console.error(`❌ Health check failed (${this.consecutiveErrors}/${this.maxConsecutiveErrors}):`, error.message);
            
            await this.reportToOwner(
                `🚨 HEALTH CHECK FAILED\n\n` +
                `Attempt: ${this.consecutiveErrors}/${this.maxConsecutiveErrors}\n` +
                `Error: ${error.message}\n` +
                `Uptime: ${this.formatUptime()}\n` +
                `Time: ${new Date().toLocaleString('id-ID')}`
            );

            if (this.consecutiveErrors >= this.maxConsecutiveErrors && !this.isShuttingDown) {
                console.error('🚨 CRITICAL: Too many health failures. Emergency restart...');
                await this.emergencyRestart();
            }
        }
    }

    monitorMemory() {
        const memoryUsage = process.memoryUsage();
        const memoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
        
        if (memoryMB > 500) {
            console.warn(`⚠️ High memory usage: ${memoryMB}MB`);
            this.reportToOwner(`⚠️ High Memory: ${memoryMB}MB - Monitoring...`);
        }
        
        if (memoryMB > 800) {
            console.error('🚨 CRITICAL: Memory too high, restarting...');
            this.emergencyRestart();
        }
    }

    formatUptime() {
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        return `${hours}h ${minutes}m`;
    }

    async emergencyRestart() {
        if (this.isShuttingDown) {
            console.log('🔄 Restart already in progress...');
            return;
        }
        
        this.isShuttingDown = true;
        this.restartCount++;
        
        const restartMessage = 
            `🔄 EMERGENCY RESTART INITIATED\n\n` +
            `Restart Count: ${this.restartCount}/${this.maxRestarts}\n` +
            `Uptime: ${this.formatUptime()}\n` +
            `Reason: System instability detected\n` +
            `Time: ${new Date().toLocaleString('id-ID')}`;

        console.log(restartMessage);
        await this.reportToOwner(restartMessage);

        await this.cleanupResources();
        
        if (this.restartCount <= this.maxRestarts) {
            console.log(`🔄 Auto-restarting bot (${this.restartCount}/${this.maxRestarts})...`);
            setTimeout(() => {
                console.log('✅ Restarting process now...');
                process.exit(1);
            }, 3000);
        } else {
            const fatalMessage = '🚨 MAX RESTART ATTEMPTS REACHED - MANUAL INTERVENTION REQUIRED';
            console.error(fatalMessage);
            await this.reportToOwner(fatalMessage);
            process.exit(1);
        }
    }

    async cleanupResources() {
        console.log('🧹 Cleaning up resources before restart...');
        
        if (this.healthCheckInterval) {
            clearInterval(this.healthCheckInterval);
        }
        
        try {
            const stopPromise = bot.stop();
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Stop timeout')), 5000)
            );
            
            await Promise.race([stopPromise, timeoutPromise]);
            console.log('✅ Bot stopped gracefully');
        } catch (error) {
            console.error('❌ Error stopping bot:', error.message);
        }
        
        Object.keys(activeSessions).forEach(key => {
            if (Array.isArray(activeSessions[key])) {
                activeSessions[key] = [];
            } else {
                activeSessions[key] = {};
            }
        });
        
        console.log('✅ Resource cleanup completed');
    }

    async reportToOwner(message) {
        try {
            await bot.telegram.sendMessage(config.OWNER_ID, message);
        } catch (error) {
            console.error('❌ Failed to send report to owner:', error.message);
            fs.appendFileSync('owner_reports.log', `[${new Date().toISOString()}] ${message}\n`);
        }
    }
}

// ==================== CRITICAL: GLOBAL ERROR HANDLER ====================

class UnkillableErrorHandler {
    constructor() {
        this.errorCount = 0;
        this.maxErrorsPerMinute = 25;
        this.errorTimestamps = [];
        this.lastOwnerAlert = 0;
        this.alertCooldown = 60000;
        
        this.setupGlobalHandlers();
    }

    setupGlobalHandlers() {
        process.on('uncaughtException', async (error) => {
            await this.handleCriticalError('uncaughtException', error);
        });

        process.on('unhandledRejection', async (reason, promise) => {
            await this.handleCriticalError('unhandledRejection', reason);
        });

        process.on('SIGTERM', async () => {
            await this.handleShutdown('SIGTERM');
        });

        process.on('SIGINT', async () => {
            await this.handleShutdown('SIGINT');
        });

        process.on('SIGUSR2', async () => {
            await this.handleShutdown('SIGUSR2');
        });

        console.log('🛡️ Global error protection system activated');
    }

    async handleCriticalError(type, error) {
        this.errorCount++;
        const timestamp = Date.now();
        this.errorTimestamps.push(timestamp);
        
        const twoMinutesAgo = timestamp - 120000;
        this.errorTimestamps = this.errorTimestamps.filter(ts => ts > twoMinutesAgo);
        
        const errorsLastTwoMinutes = this.errorTimestamps.length;
        
        console.error(`❌ ${type.toUpperCase()}:`, {
            message: error?.message || error,
            stack: error?.stack?.substring(0, 300),
            totalErrors: this.errorCount,
            recentErrors: errorsLastTwoMinutes
        });

        this.logErrorToFile(type, error);

        const now = Date.now();
        if (errorsLastTwoMinutes <= this.maxErrorsPerMinute && 
            now - this.lastOwnerAlert > this.alertCooldown) {
            
            await this.sendEmergencyAlert(type, error, errorsLastTwoMinutes);
            this.lastOwnerAlert = now;
        }

        if (type === 'uncaughtException' && errorsLastTwoMinutes > this.maxErrorsPerMinute) {
            console.error('🚨 CRITICAL: Too many uncaught exceptions');
            if (!healthManager.isShuttingDown) {
                await healthManager.emergencyRestart();
            }
        }
    }

    async handleShutdown(signal) {
        console.log(`🔄 Received ${signal}, starting graceful shutdown...`);
        
        await this.sendEmergencyAlert(
            'SHUTDOWN_SIGNAL', 
            new Error(`Process received ${signal} signal`),
            0
        );

        await healthManager.cleanupResources();
        process.exit(0);
    }

    async sendEmergencyAlert(type, error, errorsLastTwoMinutes) {
        try {
            const alertMessage = 
                `🚨 ${type.toUpperCase()} - BOT CRASH ALERT\n\n` +
                `🕒 Time: ${new Date().toLocaleString('id-ID')}\n` +
                `📊 Total Errors: ${this.errorCount}\n` +
                `📈 Recent Errors: ${errorsLastTwoMinutes}\n` +
                `🔄 Auto-Restarts: ${healthManager.restartCount}\n` +
                `❌ Error: ${error?.message || 'Unknown error'}\n` +
                `🔧 Stack: ${error?.stack ? error.stack.substring(0, 400) + '...' : 'No stack'}\n\n` +
                `🤖 Bot will auto-recover if possible.`;

            await bot.telegram.sendMessage(config.OWNER_ID, alertMessage);
            
            console.log('📢 Emergency alert sent to owner');
        } catch (alertError) {
            console.error('❌ Failed to send emergency alert:', alertError.message);
        }
    }

    logErrorToFile(type, error) {
        try {
            const logEntry = {
                timestamp: new Date().toISOString(),
                type: type,
                error: {
                    message: error?.message || error,
                    stack: error?.stack
                },
                memory: process.memoryUsage(),
                uptime: process.uptime(),
                restartCount: healthManager.restartCount
            };

            fs.appendFileSync(
                'critical_errors.json', 
                JSON.stringify(logEntry) + '\n'
            );
        } catch (logError) {
            console.error('❌ Failed to log error to file:', logError.message);
        }
    }
}

// ==================== ADVANCED REQUEST QUEUE SYSTEM ====================

class RequestQueue {
    constructor() {
        this.queue = [];
        this.processing = false;
        this.maxConcurrent = 2;
        this.currentConcurrent = 0;
        this.rateLimitDelay = 1000;
        this.lastRequestTime = 0;
    }

    async add(requestFn, priority = 'normal') {
        return new Promise((resolve, reject) => {
            const requestItem = {
                requestFn,
                resolve,
                reject,
                priority: priority === 'high' ? 1 : 0,
                addedAt: Date.now()
            };

            if (priority === 'high') {
                this.queue.unshift(requestItem);
            } else {
                this.queue.push(requestItem);
            }

            this.processQueue();
        });
    }

    async processQueue() {
        if (this.processing || this.queue.length === 0 || this.currentConcurrent >= this.maxConcurrent) {
            return;
        }

        this.processing = true;

        while (this.queue.length > 0 && this.currentConcurrent < this.maxConcurrent) {
            const now = Date.now();
            const timeSinceLastRequest = now - this.lastRequestTime;
            
            if (timeSinceLastRequest < this.rateLimitDelay) {
                await new Promise(resolve => 
                    setTimeout(resolve, this.rateLimitDelay - timeSinceLastRequest)
                );
            }

            const requestItem = this.queue.shift();
            this.currentConcurrent++;
            this.lastRequestTime = Date.now();

            this.executeRequest(requestItem)
                .finally(() => {
                    this.currentConcurrent--;
                    this.processQueue();
                });
        }

        this.processing = false;
    }

    async executeRequest(requestItem) {
        try {
            const result = await requestItem.requestFn();
            requestItem.resolve(result);
        } catch (error) {
            if (error.response?.status === 429) {
                console.log('⚠️ Rate limit terdeteksi, menunggu 5 detik...');
                await new Promise(resolve => setTimeout(resolve, 5000));
                
                try {
                    const retryResult = await requestItem.requestFn();
                    requestItem.resolve(retryResult);
                } catch (retryError) {
                    requestItem.reject(retryError);
                }
            } else {
                requestItem.reject(error);
            }
        }
    }

    getQueueStatus() {
        return {
            queueLength: this.queue.length,
            processing: this.currentConcurrent,
            maxConcurrent: this.maxConcurrent
        };
    }
}

// ==================== NOTIFICATION QUEUE SYSTEM ====================

class NotificationQueue {
    constructor() {
        this.queue = [];
        this.processing = false;
        this.lastNotificationTime = 0;
        this.minDelay = 1000; // Default 1 second, will be overridden by settings
    }

    async addNotification(notificationFn, customDelay = null) {
        return new Promise((resolve) => {
            this.queue.push({ notificationFn, resolve, customDelay });
            this.processQueue();
        });
    }

    async processQueue() {
        if (this.processing || this.queue.length === 0) {
            return;
        }

        this.processing = true;

        while (this.queue.length > 0) {
            const now = Date.now();
            const timeSinceLastNotification = now - this.lastNotificationTime;
            
            // Use custom delay if provided, otherwise use default
            const currentDelay = this.queue[0].customDelay || this.minDelay;
            
            if (timeSinceLastNotification < currentDelay) {
                const waitTime = currentDelay - timeSinceLastNotification;
                await new Promise(resolve => setTimeout(resolve, waitTime));
            }

            const notificationItem = this.queue.shift();
            this.lastNotificationTime = Date.now();

            try {
                await notificationItem.notificationFn();
                notificationItem.resolve();
            } catch (error) {
                console.error('Notification error:', error);
                notificationItem.resolve();
            }
        }

        this.processing = false;
    }
}

// ==================== FIXED PRICE ALERT MANAGER - ANTI SPAM ====================
class PriceAlertManager {
    constructor() {
        this.lastServicePrices = {};
        this.alertInterval = null;
        this.lastAlertTime = 0;
        this.lastAlertedServices = {}; // Tambahan untuk track service yang sudah di-alert
        this.alertCooldown = 5 * 60 * 1000; // 5 menit cooldown per service
    }

    start() {
        console.log('💰 Starting price alert system...');
        this.alertInterval = setInterval(() => {
            this.checkPriceAlerts();
        }, 300000); // Check every 5 minutes
        
        // Cleanup old alerts setiap 30 menit
        setInterval(() => {
            this.cleanupOldAlerts();
        }, 30 * 60 * 1000);
    }

    async checkPriceAlerts() {
        try {
            const settings = db.getSettings();
            const priceDropSettings = settings.priceDropAlert;
            
            // Check if price drop alerts are enabled
            if (!priceDropSettings.enabled) {
                return;
            }

            // Check delay between alerts
            const now = Date.now();
            if (priceDropSettings.lastAlertSent && 
                (now - priceDropSettings.lastAlertSent) < priceDropSettings.delayBetweenAlerts) {
                return;
            }

            const services = await api.rumahotp.getServices();
            if (!services || !services.success) return;

            let alertSent = false;

            for (const service of services.data) {
                if (alertSent) break; // Only send one alert per check

                const countries = await api.rumahotp.getCountries(service.service_code);
                if (!countries || !countries.success) continue;

                for (const country of countries.data) {
                    if (alertSent) break;

                    if (country.pricelist && country.pricelist.length > 0) {
                        const lowestPrice = Math.min(...country.pricelist.map(p => p.price));
                        const finalPrice = utils.calculatePrice(lowestPrice);
                        
                        const serviceKey = `${service.service_code}_${country.number_id}`;
                        
                        if (this.lastServicePrices[serviceKey] && 
                            this.lastServicePrices[serviceKey] > finalPrice) {
                            
                            const priceDrop = this.lastServicePrices[serviceKey] - finalPrice;
                            
                            // Gunakan setting dari database
                            const minDropAmount = priceDropSettings.minDropAmount || 1000;
                            const minDropPercentage = priceDropSettings.minDropPercentage || 0.10;

                            const priceDropPercentage = priceDrop / this.lastServicePrices[serviceKey];
                            const isSignificantDrop = priceDrop >= minDropAmount || priceDropPercentage >= minDropPercentage;

                            if (isSignificantDrop) {
                                await this.notifyPriceDrop(service, country, finalPrice, priceDrop, this.lastServicePrices[serviceKey]);
                                alertSent = true;
                                
                                // Update last alert time
                                priceDropSettings.lastAlertSent = Date.now();
                                db.updateSettings(settings);
                                break;
                            }
                        }
                        
                        this.lastServicePrices[serviceKey] = finalPrice;
                    }
                }
            }
        } catch (error) {
            console.error('Error checking price alerts:', error);
        }
    }

    async notifyPriceDrop(service, country, newPrice, priceDrop, oldPrice) {
        try {
            const settings = db.getSettings();
            const priceDropSettings = settings.priceDropAlert;
            
            // Cek cooldown untuk service spesifik
            const serviceKey = `${service.service_code}_${country.number_id}`;
            const now = Date.now();
            const lastAlertTime = this.lastAlertedServices[serviceKey] || 0;
            
            // Jika service ini sudah di-alert dalam cooldown period, skip
            if ((now - lastAlertTime) < this.alertCooldown) {
                console.log(`⏳ Skipping alert for ${serviceKey} - masih dalam cooldown`);
                return;
            }

            // Cek apakah harganya benar-benar berubah (bukan fluktuasi kecil)
            const minDropAmount = priceDropSettings.minDropAmount || 1000;
            const minDropPercentage = priceDropSettings.minDropPercentage || 0.10;
            
            const priceDropPercentage = priceDrop / oldPrice;
            const isSignificantDrop = priceDrop >= minDropAmount || priceDropPercentage >= minDropPercentage;
            
            if (!isSignificantDrop) {
                console.log(`📊 Price drop too small for ${serviceKey}: ${priceDrop} (${priceDropPercentage.toFixed(2)}%)`);
                return;
            }

            const message = 
                `🎉 *HARGA TURUN!*\n\n` +
                `📱 *Layanan:* ${service.service_name}\n` +
                `🇺🇳 *Negara:* ${country.name}\n` +
                `💰 Harga Lama: Rp${utils.formatNumber(oldPrice)}\n` +
                `💰 *Harga Baru:* Rp${utils.formatNumber(newPrice)}\n` +
                `📉 *Turun:* Rp${utils.formatNumber(priceDrop)} (${(priceDropPercentage * 100).toFixed(1)}%)\n\n` +
                `⚡ *Segera pesan sebelum harga naik lagi!*`;

            await notificationQueue.addNotification(async () => {
                await bot.telegram.sendMessage(
                    config.CHANNEL_ID,
                    message,
                    { parse_mode: 'Markdown' }
                );
                
                // Update last alert time untuk service ini
                this.lastAlertedServices[serviceKey] = now;
                console.log(`💰 Price drop alert sent: ${service.service_name} - ${country.name} - Drop: Rp${priceDrop}`);
            }, priceDropSettings.delayBetweenAlerts);

        } catch (error) {
            console.error('Error sending price drop notification:', error);
        }
    }

    // Cleanup old alerts secara berkala
    cleanupOldAlerts() {
        const now = Date.now();
        const oneHourAgo = now - (60 * 60 * 1000);
        
        for (const [serviceKey, lastAlertTime] of Object.entries(this.lastAlertedServices)) {
            if (lastAlertTime < oneHourAgo) {
                delete this.lastAlertedServices[serviceKey];
            }
        }
    }

    stop() {
        if (this.alertInterval) {
            clearInterval(this.alertInterval);
        }
    }

    // Method untuk reset alert cooldown
    resetCooldown() {
        const settings = db.getSettings();
        settings.priceDropAlert.lastAlertSent = null;
        db.updateSettings(settings);
        this.lastAlertedServices = {}; // Reset semua alert cooldown
        console.log('✅ Price drop alert cooldown reset');
    }
}

// ==================== AUTO DAILY MAINTENANCE SYSTEM ====================

class DailyMaintenanceManager {
    constructor() {
        this.maintenanceSchedule = {
            start: '23:00',
            end: '00:10',
            enabled: true
        };
        this.maintenanceCheckInterval = null;
        this.isMaintenanceTime = false;
        this.maintenanceMessageId = null;
    }

    start() {
        console.log('🔄 Starting daily maintenance scheduler...');
        this.checkMaintenanceStatus();
        
        this.maintenanceCheckInterval = setInterval(() => {
            this.checkMaintenanceStatus();
        }, 30000);
    }

    checkMaintenanceStatus() {
        const nowJakarta = this.getJakartaTime();
        const currentTime = nowJakarta.time;
        
        const [startHour, startMinute] = this.maintenanceSchedule.start.split(':').map(Number);
        const [endHour, endMinute] = this.maintenanceSchedule.end.split(':').map(Number);
        
        const currentTotalMinutes = nowJakarta.hours * 60 + nowJakarta.minutes;
        const startTotalMinutes = startHour * 60 + startMinute;
        const endTotalMinutes = endHour * 60 + endMinute;
        
        let shouldBeMaintenance = false;
        
        if (endTotalMinutes < startTotalMinutes) {
            shouldBeMaintenance = currentTotalMinutes >= startTotalMinutes || currentTotalMinutes <= endTotalMinutes;
        } else {
            shouldBeMaintenance = currentTotalMinutes >= startTotalMinutes && currentTotalMinutes <= endTotalMinutes;
        }
        
        if (shouldBeMaintenance !== this.isMaintenanceTime) {
            this.isMaintenanceTime = shouldBeMaintenance;
            
            if (shouldBeMaintenance) {
                console.log(`🔧 MAINTENANCE MODE ACTIVATED: ${this.maintenanceSchedule.start} - ${this.maintenanceSchedule.end}`);
                this.enableMaintenanceMode();
            } else {
                console.log(`✅ MAINTENANCE MODE DEACTIVATED`);
                this.disableMaintenanceMode();
            }
        }
    }

    getJakartaTime() {
        const now = new Date();
        const jakartaTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Jakarta"}));
        
        const hours = jakartaTime.getHours().toString().padStart(2, '0');
        const minutes = jakartaTime.getMinutes().toString().padStart(2, '0');
        const seconds = jakartaTime.getSeconds().toString().padStart(2, '0');
        
        return {
            time: `${hours}:${minutes}`,
            hours: jakartaTime.getHours(),
            minutes: jakartaTime.getMinutes(),
            seconds: jakartaTime.getSeconds(),
            fullTime: `${hours}:${minutes}:${seconds}`
        };
    }

    enableMaintenanceMode() {
        const data = db.load();
        data.settings.maintenance = true;
        db.save(data);
        
        this.notifyMaintenanceStatus(true);
    }

    disableMaintenanceMode() {
        const data = db.load();
        data.settings.maintenance = false;
        db.save(data);
        
        this.notifyMaintenanceStatus(false);
    }

    async notifyMaintenanceStatus(isStarting) {
        try {
            const jakartaTime = this.getJakartaTime();
            const message = isStarting ?
                `🔧 *MAINTENANCE MODE DIHIDUPKAN OTOMATIS*\n\n` +
                `⏰ Waktu: ${jakartaTime.fullTime} WIB\n` +
                `📅 Jadwal: ${this.maintenanceSchedule.start} - ${this.maintenanceSchedule.end} WIB\n` +
                `🤖 Status: Semua fitur non-admin dinonaktifkan` :
                `✅ *MAINTENANCE MODE DIMATIKAN OTOMATIS*\n\n` +
                `⏰ Waktu: ${jakartaTime.fullTime} WIB\n` +
                `🤖 Status: Semua fitur kembali normal`;
            
            await bot.telegram.sendMessage(config.OWNER_ID, message, { parse_mode: 'Markdown' });
        } catch (error) {
            console.error('❌ Error sending maintenance notification:', error.message);
        }
    }

    getMaintenanceMessage() {
        const jakartaTime = this.getJakartaTime();
        return {
            text: `❤️ *MAINTENANCE SEDANG BERLANGSUNG*\n\n` +
                  `Bot sedang dalam maintenance harian:\n` +
                  `❤️ Waktu: ${this.maintenanceSchedule.start} - ${this.maintenanceSchedule.end} WIB\n\n` +
                  `Silakan lakukan deposit di luar jam tersebut.\n\n` +
                  `⏰ Sekarang: ${jakartaTime.fullTime} WIB`,
            keyboard: Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Cek Status', 'check_maintenance_status')],
                [Markup.button.url('📢 Channel Updates', 'https://t.me/KingStoreReal')]
            ])
        };
    }

    async showMaintenanceScreen(ctx) {
        const maintenanceMsg = this.getMaintenanceMessage();
        try {
            if (ctx.updateType === 'callback_query') {
                await ctx.editMessageText(maintenanceMsg.text, {
                    parse_mode: 'Markdown',
                    reply_markup: maintenanceMsg.keyboard.reply_markup,
                    disable_web_page_preview: true
                });
            } else {
                const sentMsg = await ctx.reply(maintenanceMsg.text, {
                    parse_mode: 'Markdown',
                    reply_markup: maintenanceMsg.keyboard.reply_markup,
                    disable_web_page_preview: true
                });
                this.maintenanceMessageId = sentMsg.message_id;
            }
        } catch (error) {
            console.error('Error showing maintenance screen:', error.message);
        }
    }

    stop() {
        if (this.maintenanceCheckInterval) {
            clearInterval(this.maintenanceCheckInterval);
        }
    }
}

// ==================== AI CUSTOMER SERVICE SYSTEM - GEMINI ====================

class AICustomerService {
    constructor() {
        this.conversationHistory = new Map();
        this.maxHistoryLength = 10;
        this.ai = null;
        this.initialized = false;
        this.initializeGemini();
    }

    async initializeGemini() {
        try {
            if (config.GEMINI_API_KEY && config.GEMINI_API_KEY !== 'AIzaSyD3sng2eEVquVw4zYYsvnnwx11B4P2Vmfg') {
                // Gunakan dynamic import untuk ES modules
                const { GoogleGenAI } = await import('@google/genai');
                this.ai = new GoogleGenAI({ apiKey: config.GEMINI_API_KEY });
                this.initialized = true;
                console.log('✅ Gemini AI Customer Service initialized successfully');
            } else {
                console.log('❌ Gemini API key not found, AI service will use fallback responses');
            }
        } catch (error) {
            console.error('❌ Error initializing Gemini AI:', error.message);
            this.initialized = false;
        }
    }

    async handleCustomerQuery(userId, userMessage, username = 'User') {
        if (!config.AI_ENABLED) {
            return this.getFallbackResponse(userMessage, true);
        }

        try {
            // Jika Gemini belum terinisialisasi, coba inisialisasi ulang
            if (!this.initialized && !this.ai) {
                await this.initializeGemini();
            }

            // Jika Gemini tidak tersedia, gunakan fallback
            if (!this.ai) {
                return this.getFallbackResponse(userMessage, false);
            }

            // Dapatkan riwayat percakapan
            const conversation = this.getConversationHistory(userId);
            
            // Build conversation context
            let conversationContext = "";
            if (conversation.length > 0) {
                conversationContext = "\n\nRiwayat percakapan sebelumnya:\n" + 
                    conversation.slice(-4).map(msg => 
                        `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`
                    ).join('\n');
            }

            const systemPrompt = `Anda adalah AI Customer Service untuk Andin Official - Bot Nomor Virtual (NOKOS). 

INFORMASI BOT:
- Nama Bot: Andin Official
- Layanan: Nomor virtual untuk OTP (WhatsApp, Telegram, Facebook, dll)
- Deposit: Minimal Rp5,000 via QRIS
- Channel: @infoandtesti & @KingStoreReal
- Admin: @KingStoreGanteng
- Website: https://kingstorereal.com

ATURAN RESPON:
1. Jawab dengan ramah, sopan, dan helpful dalam bahasa Indonesia
2. Bantu dengan pertanyaan tentang cara order, deposit, layanan, harga
3. Untuk masalah teknis/komplain, arahkan ke admin @KingStoreGanteng
4. Jangan buat informasi yang tidak pasti
5. Format respon dengan rapi dan mudah dibaca
6. Jika tidak tahu jawaban, jangan mengarang

INFORMASI PENTING:
- Order: Pilih layanan → pilih negara → pilih provider → bayar dengan saldo
- Deposit: Minimal Rp5,000, proses otomatis via QRIS
- Saldo tidak bisa ditarik, hanya untuk order nokos
- Maintenance: Setiap hari 23:00 - 00:10 WIB
- Auto cancel: 5 menit jika tidak dapat OTP
- Refund: Otomatis jika order gagal${conversationContext}

JAWAB PERTANYAAN USER DENGAN BAIK: "${userMessage}"`;

            console.log('🔄 Calling Gemini AI...');
            
            const response = await this.ai.models.generateContent({
                model: config.AI_MODEL || "gemini-2.0-flash",
                contents: systemPrompt,
            });

            console.log('✅ Gemini AI Response received');
            
            const aiResponse = response.text;

            // Simpan ke riwayat
            this.addToConversationHistory(userId, userMessage, aiResponse);

            // Analisis apakah perlu eskalasi ke human
            const requiresHuman = this.checkIfRequiresHuman(aiResponse, userMessage);

            return {
                success: true,
                response: aiResponse,
                requiresHuman: requiresHuman
            };

        } catch (error) {
            console.error('❌ Gemini AI Service Error:', error.message);
            
            // Fallback response yang lebih helpful
            let fallbackResponse = this.getFallbackResponse(userMessage, false);
            
            return {
                success: false,
                response: fallbackResponse,
                requiresHuman: true
            };
        }
    }

    getFallbackResponse(userMessage, aiDisabled = false) {
        const lowerMessage = userMessage.toLowerCase();
        
        if (aiDisabled) {
            return `🤖 *AI CUSTOMER SERVICE SEDANG DINONAKTIFKAN*\n\nSilakan hubungi admin @KingStoreGanteng untuk bantuan.\n\nPertanyaan Anda: "${userMessage}"`;
        }
        
        if (lowerMessage.includes('hallo') || lowerMessage.includes('hai') || lowerMessage.includes('halo') || lowerMessage.includes('hi')) {
            return `Halo! 👋 Selamat datang di *Andin Official*!\n\nSaya AI Assistant siap membantu Anda. Ada yang bisa saya bantu?\n\n📋 *Fitur yang tersedia:*\n• 📱 Order nomor virtual (nokos)\n• 💳 Deposit saldo\n• 📊 Cek riwayat transaksi\n• 🎁 Sistem referral\n• 🤖 Bantuan AI\n\nSilakan pilih menu di bawah atau tanyakan langsung!`;
        } else if (lowerMessage.includes('deposit') || lowerMessage.includes('saldo') || lowerMessage.includes('top up')) {
            return `💳 *CARA DEPOSIT SALDO:*\n\n1. Pilih menu "💳 DEPOSIT"\n2. Pilih nominal (5K, 10K, 20K, 50K, 100K, 200K) atau custom\n3. Scan QR Code yang muncul\n4. Bayar via aplikasi bank/e-wallet\n5. Saldo otomatis masuk dalam 1-2 menit\n\n💰 *Minimal Deposit:* Rp5,000\n⚡ *Proses:* Instant dengan QRIS\n🔧 *Metode:* QRIS (semua bank & e-wallet)\n\n💡 *Tips:* Setelah scan QR, tunggu hingga status berubah menjadi "SUKSES" secara otomatis.`;
        } else if (lowerMessage.includes('order') || lowerMessage.includes('nokos') || lowerMessage.includes('nomor') || lowerMessage.includes('beli')) {
            return `📱 *CARA ORDER NOKOS (NOMOR VIRTUAL):*\n\n1. Pilih "📱 ORDER NOKOS"\n2. Pilih layanan (WhatsApp, Telegram, Facebook, dll)\n3. Pilih negara yang diinginkan\n4. Pilih operator/provider\n5. Konfirmasi dan bayar dengan saldo\n6. Tunggu SMS OTP masuk\n7. Salin kode OTP yang diterima\n\n⏰ *Auto Cancel:* 5 menit jika tidak dapat OTP\n💰 *Refund:* Otomatis jika order gagal\n🌍 *Negara tersedia:* Indonesia, USA, UK, dll\n\n📊 *Layanan populer:*\n• WhatsApp Indonesia: Rp3,000 - Rp8,000\n• Telegram USA: Rp5,000 - Rp15,000\n• Facebook UK: Rp4,000 - Rp12,000`;
        } else if (lowerMessage.includes('layanan') || lowerMessage.includes('service') || lowerMessage.includes('harga') || lowerMessage.includes('price')) {
            return `📊 *LAYANAN YANG TERSEDIA:*\n\n• WhatsApp (berbagai negara)\n• Telegram\n• Facebook\n• Instagram\n• Twitter/X\n• TikTok\n• Google\n• Line\n• Dan lain-lain\n\n💰 *Harga bervariasi tergantung:*\n- Negara\n- Provider\n- Stok\n- Tingkat kesulitan\n\n📱 Silakan cek menu "ORDER NOKOS" untuk melihat daftar lengkap dan harga real-time!`;
        } else if (lowerMessage.includes('referral') || lowerMessage.includes('refferal') || lowerMessage.includes('ajak') || lowerMessage.includes('teman')) {
            return `🎁 *SISTEM REFERRAL*\n\nAjak teman dan dapatkan bonus! 🎉\n\n💰 *Bonus untuk Anda:* Rp5,000 per user\n🎁 *Bonus untuk Teman:* Rp2,000\n\n🔗 *Cara kerja:*\n1. Bagikan link referral Anda\n2. Teman klik link dan mulai bot\n3. Bonus otomatis masuk ke saldo!\n\n📊 *Cek menu "🎁 REFERRAL" untuk link referral Anda!*`;
        } else if (lowerMessage.includes('masalah') || lowerMessage.includes('gagal') || lowerMessage.includes('error') || lowerMessage.includes('masalah') || lowerMessage.includes('kendala')) {
            return `🚨 *BANTUAN TEKNIS*\n\nJika mengalami masalah:\n\n1. *Order gagal?* - Saldo akan direfund otomatis dalam 5 menit\n2. *Deposit tertunda?* - Tunggu 1-2 menit, status update otomatis\n3. *Tidak dapat OTP?* - Coba layanan/negara lain\n4. *Bug/Error?* - Restart bot atau hubungi admin\n\n📞 *Admin Support:* @KingStoreGanteng\n⏰ *Response time:* 1-2 jam\n\n🔧 *Tips:* Pastikan sudah join channel @AllAboutKingStore & @TestiAllBot untuk update terbaru!`;
        } else if (lowerMessage.includes('channel') || lowerMessage.includes('grup') || lowerMessage.includes('group') || lowerMessage.includes('info')) {
            return `📢 *CHANNEL RESMI Andin Official*\n\nBergabung dengan channel kami untuk informasi terbaru:\n\n📢 @infoandtesti\n📢 @KingStoreReal\n\n📋 *Yang didapat:*\n• Update layanan baru\n• Promo dan bonus spesial\n• Info maintenance\n• Testimoni user\n• Tutorial penggunaan\n\n🔔 *Jangan lupa join kedua channel tersebut!*`;
        } else {
            return `🤖 *BANTUAN CUSTOMER SERVICE*\n\nSaya AI Assistant Andin Official! 👋\n\nPertanyaan Anda: *"${userMessage}"*\n\n📋 *Saya bisa bantu dengan:*\n• Cara deposit saldo\n• Cara order nokos\n• Info layanan & harga\n• Sistem referral\n• Masalah teknis\n• Info channel\n\n💬 Silakan tanyakan dengan lebih spesifik, atau hubungi admin @KingStoreGanteng untuk bantuan lebih lanjut!`;
        }
    }

    getConversationHistory(userId) {
        return this.conversationHistory.get(userId.toString()) || [];
    }

    addToConversationHistory(userId, userMessage, aiResponse) {
        const userIdStr = userId.toString();
        let history = this.conversationHistory.get(userIdStr) || [];
        
        history.push(
            { role: "user", content: userMessage },
            { role: "assistant", content: aiResponse }
        );

        // Batasi riwayat
        if (history.length > this.maxHistoryLength * 2) {
            history = history.slice(-this.maxHistoryLength * 2);
        }

        this.conversationHistory.set(userIdStr, history);
    }

    checkIfRequiresHuman(aiResponse, userMessage) {
        const urgentKeywords = [
            'komplain', 'complaint', 'masalah', 'problem', 'error', 'gagal', 'failed',
            'bug', 'hack', 'scam', 'penipuan', 'uang', 'money', 'refund', 'chargeback',
            'salah', 'wrong', 'tidak bekerja', 'not working', 'help', 'bantuan',
            'admin', 'human', 'orang', 'manager', 'pemilik', 'bos', 'owner'
        ];

        const userMessageLower = userMessage.toLowerCase();
        const aiResponseLower = aiResponse.toLowerCase();

        // Cek jika user meminta human
        if (urgentKeywords.some(keyword => userMessageLower.includes(keyword))) {
            return true;
        }

        // Cek jika AI mengarahkan ke human
        if (aiResponseLower.includes('admin') || 
            aiResponseLower.includes('human') || 
            aiResponseLower.includes('@KingStoreGanteng') ||
            aiResponseLower.includes('pemilik') ||
            aiResponseLower.includes('manager') ||
            aiResponseLower.includes('contact admin') ||
            aiResponseLower.includes('hubungi admin')) {
            return true;
        }

        return false;
    }

    clearUserHistory(userId) {
        this.conversationHistory.delete(userId.toString());
    }

    clearAllHistory() {
        this.conversationHistory.clear();
        console.log('✅ All AI conversation history cleared');
    }

    async notifyOwnerAboutAIQuery(userId, userMessage, aiResponse, requiresHuman, username = 'User') {
        try {
            const userInfo = await safeDbOperation(() => db.getUser(userId), 'GET_USER_AI_QUERY');
            const userUsername = userInfo.username ? `@${userInfo.username}` : 'Tidak ada username';
            const fullName = [userInfo.first_name, userInfo.last_name].filter(Boolean).join(' ') || 'Unknown';

            const status = requiresHuman ? '🚨 PERLU ESKALASI KE ADMIN' : '🤖 TELAH DIJAWAB AI';

            const notification = 
                `🤖 *GEMINI AI CUSTOMER SERVICE NOTIFICATION*\n\n` +
                `👤 *User:* ${fullName}\n` +
                `📧 *Username:* ${userUsername}\n` +
                `🆔 *User ID:* ${userId}\n\n` +
                `❓ *Pertanyaan User:*\n${userMessage}\n\n` +
                `💬 *Jawaban AI:*\n${aiResponse}\n\n` +
                `📊 *Status:* ${status}\n` +
                `⏰ *Waktu:* ${utils.getIndonesianTime()}`;

            await notificationQueue.addNotification(async () => {
                await bot.telegram.sendMessage(
                    config.OWNER_ID,
                    notification,
                    { parse_mode: 'Markdown' }
                );
            });

            console.log(`🤖 Gemini AI Query from ${userId}: ${requiresHuman ? 'NEEDS HUMAN' : 'HANDLED BY AI'}`);

        } catch (error) {
            console.error('❌ Error sending Gemini AI notification to owner:', error);
        }
    }

    async restartService() {
        this.ai = null;
        this.initialized = false;
        await this.initializeGemini();
        return this.initialized;
    }
}

// Inisialisasi AI Service
const aiCustomerService = new AICustomerService();

// ==================== AUTO TOP-UP ALERT SYSTEM ====================

class AutoTopupAlert {
    constructor() {
        this.alertInterval = null;
    }

    start() {
        console.log('🚨 Starting auto top-up alert system...');
        this.alertInterval = setInterval(() => {
            this.checkBotBalance();
        }, 600000); // Check every 10 minutes
    }

    async checkBotBalance() {
        try {
            const settings = db.getSettings();
            if (!settings.autoTopupAlert?.enabled) return;

            const balanceResult = await api.rumahotp.getBalance();
            if (!balanceResult || !balanceResult.success) return;

            const botBalance = balanceResult.data.balance || 0;
            const threshold = settings.autoTopupAlert.threshold || 50000;

            if (botBalance < threshold) {
                const now = Date.now();
                const lastAlert = settings.autoTopupAlert.lastAlertSent;
                
                // Only send alert once per hour to avoid spam
                if (!lastAlert || (now - lastAlert) > 3600000) {
                    await bot.telegram.sendMessage(
                        config.OWNER_ID,
                        `🚨 *SALDO BOT HAMPIR HABIS!*\n\n` +
                        `💰 *Saldo Saat Ini:* Rp${utils.formatNumber(botBalance)}\n` +
                        `⚠️ *Threshold:* Rp${utils.formatNumber(threshold)}\n` +
                        `🔴 *Status:* PERLU TOP-UP SEGERA!\n\n` +
                        `Silakan top-up saldo bot untuk menghindari gangguan layanan.`,
                        { parse_mode: 'Markdown' }
                    );

                    // Update last alert time
                    settings.autoTopupAlert.lastAlertSent = now;
                    db.updateSettings(settings);
                }
            }
        } catch (error) {
            console.error('Error checking bot balance:', error);
        }
    }

    stop() {
        if (this.alertInterval) {
            clearInterval(this.alertInterval);
        }
    }
}

// ==================== H2H PAGINATION FUNCTION ====================
function sendH2HPage(bot, chatId, page, messageId = null) {
    const data = global.h2hPages?.[chatId];
    if (!data) return;

    const { keyword, result, pageSize, totalPages } = data;

    const start = (page - 1) * pageSize;
    const sliced = result.slice(start, start + pageSize);

    let text = `📦 *Hasil Pencarian Produk H2H*\n`;
    text += `🔍 Kata kunci: *${keyword}*\n`;
    text += `📊 Total ditemukan: *${result.length}*\n`;
    text += `📄 Halaman: *${page}/${totalPages}*\n`;
    text += `━━━━━━━━━━━━━━━━━━\n`;

    for (const p of sliced) {
        text += `
💠 *${p.name}*
🧩 Code: \`${p.code}\`
🏷️ Brand: *${p.brand}*
📂 Kategori: *${p.category}*
💬 Note: ${p.note}
💰 Harga: Rp${p.price.toLocaleString("id-ID")}
━━━━━━━━━━━━━━`;
    }

    const buttons = [];
    if (page > 1) buttons.push(Markup.button.callback("⬅️ Prev", `h2h_prev_${page}`));
    if (page < totalPages) buttons.push(Markup.button.callback("➡️ Next", `h2h_next_${page}`));

    const keyboard = Markup.inlineKeyboard([buttons]);

    // Jika pertama kali → sendMessage
    if (!messageId) {
        bot.telegram.sendMessage(chatId, text, {
            parse_mode: "Markdown",
            reply_markup: keyboard.reply_markup
        });
    } else {
        // Jika next/prev → editMessageText
        bot.telegram.editMessageText(chatId, messageId, undefined, text, {
            parse_mode: "Markdown",
            reply_markup: keyboard.reply_markup
        }).catch(err => console.log("Edit error:", err.message));
    }
}

// ==================== SAFE HANDLER WRAPPER ====================

function createBulletproofHandler(handlerName, handlerFunction) {
    return async (...args) => {
        const startTime = Date.now();
        let ctx = args[0];
        const errorId = `ERR_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        
        try {
            if (!ctx || !ctx.from || !ctx.from.id) {
                console.error(`❌ [${handlerName}] Invalid context`);
                return;
            }

            const userId = ctx.from.id;
            
            // Enhanced maintenance check with proper message display
            const settings = db.getSettings();
            if ((settings.maintenance || maintenanceManager.isMaintenanceTime) && !utils.isAdmin(userId)) {
                if (ctx.updateType === 'callback_query') {
                    try {
                        await ctx.answerCbQuery('🔧 Bot sedang maintenance!', { show_alert: true });
                        await maintenanceManager.showMaintenanceScreen(ctx);
                    } catch (e) {
                        // If can't edit, send new message
                        await maintenanceManager.showMaintenanceScreen(ctx);
                    }
                } else {
                    await maintenanceManager.showMaintenanceScreen(ctx);
                }
                return;
            }

            if (utils.checkSpam(userId)) {
                try {
                    await ctx.reply('⚠️ Terlalu banyak permintaan. Silakan tunggu beberapa saat.');
                } catch (e) {}
                return;
            }

            console.log(`🔹 [${handlerName}] Start - User: ${userId}`);

            await handlerFunction(...args);
            
            const duration = Date.now() - startTime;
            if (duration > 2000) {
                console.warn(`⚠️ [${handlerName}] Slow: ${duration}ms - User: ${userId}`);
            } else {
                console.log(`✅ [${handlerName}] Success: ${duration}ms - User: ${userId}`);
            }

        } catch (error) {
            const duration = Date.now() - startTime;
            
            console.error(`❌ [${handlerName}] FAILED:`, {
                errorId: errorId,
                userId: ctx?.from?.id,
                duration: duration + 'ms',
                error: error.message,
                stack: error.stack?.substring(0, 200)
            });

            // Don't send error message for old callback queries
            if (error.message.includes('query is too old') || error.message.includes('query ID is invalid')) {
                return;
            }

            try {
                if (ctx.updateType === 'callback_query') {
                    await ctx.answerCbQuery('❌ Terjadi kesalahan sistem.', { show_alert: true });
                } else {
                    await ctx.reply(
                        `❌ Terjadi kesalahan sistem (${errorId}).\n\n` +
                        `Silakan coba lagi atau hubungi admin jika masalah berlanjut.`
                    );
                }
            } catch (replyError) {
                console.error(`❌ [${handlerName}] Failed to send error message to user:`, replyError.message);
            }

            if (!error.message.includes('ETELEGRAM') && 
                !error.message.includes('message to edit not found') &&
                !error.message.includes('query is too old')) {
                try {
                    await bot.telegram.sendMessage(
                        config.OWNER_ID,
                        `⚠️ HANDLER ERROR: ${handlerName}\n\n` +
                        `Error ID: ${errorId}\n` +
                        `User: ${ctx?.from?.id}\n` +
                        `Error: ${error.message}\n` +
                        `Duration: ${duration}ms\n` +
                        `Time: ${new Date().toLocaleString('id-ID')}`
                    );
                } catch (alertError) {
                    console.error('❌ Failed to send handler error to owner:', alertError.message);
                }
            }

            errorHandler.logErrorToFile(`handler_${handlerName}`, error);
        }
    };
}

// ==================== ENHANCED SAFE API CALL WITH QUEUE ====================

const enhancedSafeApiCall = async (apiFunction, operationName, maxRetries = 3, priority = 'normal') => {
    const executeWithRetry = async (attempt = 1) => {
        try {
            const result = await globalQueue.add(apiFunction, priority);
            return result;
        } catch (error) {
            console.error(`❌ API Call Failed [${operationName}] Attempt ${attempt}/${maxRetries}:`, error.message);
            
            if (attempt === maxRetries) {
                if (!error.message.includes('timeout') && !error.message.includes('Network Error')) {
                    bot.telegram.sendMessage(
                        config.OWNER_ID,
                        `🚨 API FAILURE: ${operationName}\n\n` +
                        `Error: ${error.message}\n` +
                        `Attempts: ${maxRetries}\n` +
                        `Queue Status: ${JSON.stringify(globalQueue.getQueueStatus())}\n` +
                        `Time: ${new Date().toLocaleString('id-ID')}`
                    ).catch(console.error);
                }
                throw error;
            }
            
            const backoffTime = Math.min(1000 * Math.pow(2, attempt), 30000);
            console.log(`⏳ Backoff ${backoffTime}ms untuk ${operationName}...`);
            await new Promise(resolve => setTimeout(resolve, backoffTime));
            
            return executeWithRetry(attempt + 1);
        }
    };

    return executeWithRetry();
};

// ==================== SAFE DB WRAPPERS ====================

const safeDbOperation = async (dbFunction, operationName, maxRetries = 2) => {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const result = await dbFunction();
            return result;
        } catch (error) {
            console.error(`❌ DB Operation Failed [${operationName}] Attempt ${attempt}/${maxRetries}:`, error.message);
            
            if (attempt === maxRetries) {
                console.error('🚨 CRITICAL: Database operation failed repeatedly');
                if (!healthManager.isShuttingDown) {
                    healthManager.emergencyRestart();
                }
                throw error;
            }
            
            await new Promise(resolve => setTimeout(resolve, 500 * attempt));
        }
    }
};

// Instantiate system managers
const healthManager = new BotHealthManager();
const errorHandler = new UnkillableErrorHandler();
const globalQueue = new RequestQueue();
const notificationQueue = new NotificationQueue();
const priceAlertManager = new PriceAlertManager();
const maintenanceManager = new DailyMaintenanceManager();
const autoTopupAlert = new AutoTopupAlert();

// Inisialisasi bot
const bot = new Telegraf(config.BOT_TOKEN);

// ==================== USER TRANSACTION LOCK SYSTEM ====================
const userTransactionLocks = new Map();

const lockUtils = {
    acquireUserLock: (userId) => {
        const userIdStr = userId.toString();
        
        const now = Date.now();
        for (const [key, timestamp] of userTransactionLocks.entries()) {
            if (now - timestamp > 10 * 60 * 1000) {
                userTransactionLocks.delete(key);
            }
        }
        
        if (userTransactionLocks.has(userIdStr)) {
            return false;
        }
        
        userTransactionLocks.set(userIdStr, now);
        console.log(`🔒 User ${userIdStr} acquired transaction lock`);
        return true;
    },
    
    releaseUserLock: (userId) => {
        const userIdStr = userId.toString();
        userTransactionLocks.delete(userIdStr);
        console.log(`🔓 User ${userIdStr} released transaction lock`);
    },
    
    isUserLocked: (userId) => {
        const userIdStr = userId.toString();
        return userTransactionLocks.has(userIdStr);
    },
    
    forceReleaseLock: (userId) => {
        const userIdStr = userId.toString();
        if (userTransactionLocks.has(userIdStr)) {
            userTransactionLocks.delete(userIdStr);
            console.log(`⚠️ Force released lock for user ${userIdStr}`);
            return true;
        }
        return false;
    }
};

// Database functions dengan struktur yang konsisten
const db = {
    load: () => {
        try {
            if (fs.existsSync(config.DB_FILE)) {
                const data = JSON.parse(fs.readFileSync(config.DB_FILE, 'utf8'));
                
                if (!data.settings) data.settings = {};
                if (!data.settings.backup) {
                    data.settings.backup = {
                        auto: false,
                        daily: false,
                        time: '18.00'
                    };
                }
                if (!data.settings.referral) {
                    data.settings.referral = {
                        enabled: true,
                        bonus: 200,
                        referrerBonus: 200,
                        referredBonus: 100
                    };
                }
                if (!data.settings.profitPercentage) {
                    data.settings.profitPercentage = config.PROFIT_PERCENTAGE;
                }
                if (!data.settings.depositMethod) {
                    data.settings.depositMethod = config.DEPOSIT_METHOD;
                }
                if (typeof data.settings.maintenance === 'undefined') {
                    data.settings.maintenance = false;
                }
                if (!data.settings.autoTopupAlert) {
                    data.settings.autoTopupAlert = {
                        enabled: true,
                        threshold: 50000,
                        lastAlertSent: null
                    };
                }
                
                // Di dalam db.load() - tambahkan setelah autoTopupAlert
if (!data.settings.priceDropAlert) {
    data.settings.priceDropAlert = {
        enabled: true,
        delayBetweenAlerts: 60000, // 1 menit default (dalam milidetik)
        minDropAmount: 1000, // Minimal turun Rp1,000
        minDropPercentage: 0.10, // Minimal turun 10%
        lastAlertSent: null
    };
}
                
                if (!data.users) data.users = {};
                if (!data.transactions) data.transactions = {};
                if (!data.orders) data.orders = {};
                if (!data.referrals) data.referrals = {};
                if (!data.vouchers) data.vouchers = {};
                
                return data;
            }
        } catch (error) {
            console.error('Error loading database:', error);
        }
        
        return {
            users: {},
            transactions: {},
            orders: {},
            referrals: {},
            vouchers: {},
            settings: {
                profitPercentage: config.PROFIT_PERCENTAGE,
                depositMethod: config.DEPOSIT_METHOD,
                maintenance: false,
                backup: {
                    auto: false,
                    daily: false,
                    time: '18.00'
                },
                referral: {
                    enabled: true,
                    bonus: 200,
                    referrerBonus: 200,
                    referredBonus: 100
                },
                autoTopupAlert: {
                    enabled: true,
                    threshold: 50000,
                    lastAlertSent: null
                }
            }
        };
    },
    
    save: (data) => {
        try {
            fs.writeFileSync(config.DB_FILE, JSON.stringify(data, null, 2));
            return true;
        } catch (error) {
            console.error('Error saving database:', error);
            return false;
        }
    },
    
    getUser: (userId) => {
        const data = db.load();
        const userIdStr = userId.toString();
        if (!data.users[userIdStr]) {
            data.users[userIdStr] = {
                id: userIdStr,
                balance: 0,
                totalOrders: 0,
                totalDeposit: 0,
                createdAt: Date.now(),
                isActive: true,
                username: '',
                first_name: '',
                last_name: '',
                hasBeenNotified: false,
                level: 1,
                referralCode: Math.random().toString(36).substring(2, 10).toUpperCase(),
                referredBy: null,
                referralCount: 0,
                referralEarnings: 0,
                joinDate: new Date().toISOString().split('T')[0]
            };
            db.save(data);
        }
        
        const user = data.users[userIdStr];
        if (!user.referralCode || user.referralCode === '' || user.referralCode.length < 6) {
            user.referralCode = Math.random().toString(36).substring(2, 10).toUpperCase();
            db.save(data);
        }
        
        if (typeof user.referralCount === 'undefined') user.referralCount = 0;
        if (typeof user.referralEarnings === 'undefined') user.referralEarnings = 0;
        if (typeof user.referredBy === 'undefined') user.referredBy = null;
        
        return user;
    },
    
    updateUser: (userId, updates) => {
        const data = db.load();
        const userIdStr = userId.toString();
        if (data.users[userIdStr]) {
            data.users[userIdStr] = { ...data.users[userIdStr], ...updates };
            return db.save(data);
        }
        return false;
    },
    
    addTransaction: (transaction) => {
        const data = db.load();
        const id = `TRX_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        data.transactions[id] = {
            id,
            ...transaction,
            createdAt: Date.now()
        };
        return db.save(data) ? id : null;
    },
    
    addOrder: (order) => {
        const data = db.load();
        const id = `ORD_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        data.orders[id] = {
            id,
            ...order,
            createdAt: Date.now()
        };
        return db.save(data) ? id : null;
    },
    
    getAllUsers: () => {
        const data = db.load();
        return Object.values(data.users);
    },
    
    getActiveOrders: () => {
        const data = db.load();
        return Object.values(data.orders).filter(order => 
            order.status === 'active' || order.status === 'waiting'
        );
    },
    
    updateTransactionStatus: (trxId, status) => {
        const data = db.load();
        const transaction = Object.values(data.transactions).find(t => t.trxId === trxId);
        if (transaction) {
            transaction.status = status;
            return db.save(data);
        }
        return false;
    },
    
    updateOrderStatus: (orderId, status) => {
        const data = db.load();
        const order = Object.values(data.orders).find(o => o.orderId === orderId);
        if (order) {
            order.status = status;
            return db.save(data);
        }
        return false;
    },
    
    refundOrder: (userId, amount, orderId) => {
        const data = db.load();
        const user = data.users[userId.toString()];
        if (user) {
            user.balance += amount;
            const order = Object.values(data.orders).find(o => o.orderId === orderId);
            if (order) {
                order.status = 'refunded';
            }
            return db.save(data);
        }
        return false;
    },

    addReferral: (referrerId, referredId) => {
        const data = db.load();
        const refId = `REF_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        data.referrals[refId] = {
            id: refId,
            referrerId: referrerId.toString(),
            referredId: referredId.toString(),
            createdAt: Date.now(),
            bonusGiven: true
        };
        return db.save(data);
    },

    getUserByReferralCode: (code) => {
        const data = db.load();
        return Object.values(data.users).find(user => user.referralCode === code);
    },

    getSettings: () => {
        const data = db.load();
        return data.settings;
    },

    updateSettings: (updates) => {
        const data = db.load();
        data.settings = { ...data.settings, ...updates };
        return db.save(data);
    },

    addVoucher: (voucher) => {
        const data = db.load();
        data.vouchers[voucher.code] = {
            ...voucher,
            createdAt: Date.now(),
            used: false,
            usedBy: null,
            usedAt: null,
            usedCount: 0
        };
        return db.save(data);
    },

    getVoucher: (code) => {
        const data = db.load();
        return data.vouchers[code];
    },

    useVoucher: (code, userId) => {
        const data = db.load();
        const voucher = data.vouchers[code];
        if (voucher && (!voucher.maxUsage || voucher.usedCount < voucher.maxUsage)) {
            voucher.usedCount = (voucher.usedCount || 0) + 1;
            voucher.used = voucher.maxUsage ? voucher.usedCount >= voucher.maxUsage : false;
            voucher.usedBy = userId.toString();
            voucher.usedAt = Date.now();
            return db.save(data);
        }
        return false;
    }
};

// ==================== UTILITY FUNCTIONS - COMPLETE ====================
const utils = {
    formatNumber: (num) => {
        return new Intl.NumberFormat('id-ID').format(num);
    },

    generateReffId: () => {
        return `BOT_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    },

    isAdmin: (userId) => {
        const userIdStr = userId.toString();
        return config.ADMIN_IDS.includes(userIdStr) || userIdStr === config.OWNER_ID;
    },

    calculatePrice: (basePrice) => {
        const data = db.load();
        const profitPercentage = data.settings.profitPercentage || config.PROFIT_PERCENTAGE;
        return Math.ceil(basePrice * (1 + profitPercentage / 100));
    },

    maskPhone: (phone) => {
        const cleaned = phone.replace(/\D/g, '');
        if (cleaned.length < 8) return '****';
        return cleaned.substring(0, 3) + '****' + cleaned.substring(cleaned.length - 2);
    },

    getDepositMethod: () => {
        const data = db.load();
        return data.settings.depositMethod || config.DEPOSIT_METHOD;
    },

    setDepositMethod: (method) => {
        const data = db.load();
        data.settings.depositMethod = method;
        return db.save(data);
    },

    setProfitPercentage: (percentage) => {
        const data = db.load();
        data.settings.profitPercentage = percentage;
        return db.save(data);
    },

    getIndonesianTime: () => {
        return new Date().toLocaleString('id-ID', {
            timeZone: 'Asia/Jakarta',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    },

    getIndonesianTimeShort: () => {
        return new Date().toLocaleTimeString('id-ID', {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit'
        });
    },

    canCancelOrder: (createdAt) => {
        const fiveMinutesAgo = Date.now() - (5 * 60 * 1000);
        return createdAt > fiveMinutesAgo;
    },

    formatTimeRemaining: (createdAt) => {
        const fiveMinutes = 5 * 60 * 1000;
        const timePassed = Date.now() - createdAt;
        const timeLeft = fiveMinutes - timePassed;
        const minutesLeft = Math.ceil(timeLeft / (60 * 1000));
        return Math.max(0, minutesLeft);
    },

    canCancelDeposit: (createdAt) => {
        const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
        return createdAt > tenMinutesAgo;
    },

    formatDepositTimeRemaining: (createdAt) => {
        const tenMinutes = 10 * 60 * 1000;
        const timePassed = Date.now() - createdAt;
        const timeLeft = tenMinutes - timePassed;
        const minutesLeft = Math.ceil(timeLeft / (60 * 1000));
        return Math.max(0, minutesLeft);
    },

    isUserInChannel: async (userId) => {
        try {
            const member = await bot.telegram.getChatMember(config.LOG_CHANNEL, userId);
            return member.status === 'member' || member.status === 'administrator' || member.status === 'creator';
        } catch (error) {
            console.error('Error checking channel membership:', error);
            return false;
        }
    },

    createBackup: async () => {
        try {
            const backupDir = 'backups';
            if (!fs.existsSync(backupDir)) {
                fs.mkdirSync(backupDir);
            }

            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupFile = path.join(backupDir, `backup-${timestamp}.zip`);
            
            const output = fs.createWriteStream(backupFile);
            const archive = archiver('zip', { zlib: { level: 9 } });

            return new Promise((resolve, reject) => {
                output.on('close', () => {
                    console.log(`Backup created: ${backupFile} (${archive.pointer()} bytes)`);
                    resolve(backupFile);
                });

                archive.on('error', (err) => {
                    reject(err);
                });

                archive.pipe(output);
                
                if (fs.existsSync(config.DB_FILE)) {
                    archive.file(config.DB_FILE, { name: 'database.json' });
                }
                
                if (fs.existsSync('config.js')) {
                    archive.file('config.js', { name: 'config.js' });
                }
                
                if (fs.existsSync('bot.js')) {
                    archive.file('bot.js', { name: 'bot.js' });
                }

                if (fs.existsSync('package.json')) {
                    archive.file('package.json', { name: 'package.json' });
                }

                archive.finalize();
            });
        } catch (error) {
            console.error('Backup error:', error);
            throw error;
        }
    },

    // ==================== CHECK SPAM FUNCTION ====================
    checkSpam: (userId) => {
        const now = Date.now();
        const userKey = `spam_${userId}`;
        
        if (!activeSessions.spam[userKey]) {
            activeSessions.spam[userKey] = {
                count: 1,
                lastActivity: now
            };
            return false;
        }

        const userSpam = activeSessions.spam[userKey];
        const timeDiff = now - userSpam.lastActivity;

        if (timeDiff < 1000) {
            userSpam.count++;
            if (userSpam.count > 5) {
                return true;
            }
        } else {
            userSpam.count = 1;
        }

        userSpam.lastActivity = now;
        return false;
    },

    calculateLevel: (totalOrders) => {
        if (totalOrders >= 100) return 5;
        if (totalOrders >= 50) return 4;
        if (totalOrders >= 25) return 3;
        if (totalOrders >= 10) return 2;
        return 1;
    },

    getLevelBenefits: (level) => {
        const benefits = {
            1: { discount: 0, name: '🥉 Bronze' },
            2: { discount: 5, name: '🥈 Silver' },
            3: { discount: 10, name: '🥇 Gold' },
            4: { discount: 15, name: '💎 Platinum' },
            5: { discount: 20, name: '👑 Diamond' }
        };
        return benefits[level] || benefits[1];
    },

    // New function to format time for countdown
    formatCountdown: (milliseconds) => {
        const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    },

    // Escape Markdown characters to prevent parsing errors
    escapeMarkdown: (text) => {
        if (!text) return '';
        return text.toString()
            .replace(/\_/g, '\\_')
            .replace(/\*/g, '\\*')
            .replace(/\[/g, '\\[')
            .replace(/\]/g, '\\]')
            .replace(/\(/g, '\\(')
            .replace(/\)/g, '\\)')
            .replace(/\~/g, '\\~')
            .replace(/\`/g, '\\`')
            .replace(/\>/g, '\\>')
            .replace(/\#/g, '\\#')
            .replace(/\+/g, '\\+')
            .replace(/\-/g, '\\-')
            .replace(/\=/g, '\\=')
            .replace(/\|/g, '\\|')
            .replace(/\{/g, '\\{')
            .replace(/\}/g, '\\}')
            .replace(/\./g, '\\.')
            .replace(/\!/g, '\\!');
    },

    // Escape HTML characters
    escapeHtml: (text) => {
        if (!text) return '';
        
        const str = text.toString();
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    },

    // Safe text for both HTML and Markdown
    safeText: (text, mode = 'markdown') => {
        if (!text) return '';
        
        const str = text.toString();
        
        if (mode === 'html') {
            return utils.escapeHtml(str);
        } else {
            return utils.escapeMarkdown(str);
        }
    }
};

// Animation utility functions
// ==================== ENHANCED ANIMATION SYSTEM - FIXED VERSION ====================
const animationUtils = {
    createSafeLoadingAnimation: async (ctx, text) => {
        try {
            const loadingMsg = await ctx.reply(text, { 
                parse_mode: 'Markdown' 
            });
            
            const frames = [
                `${text} [▰▱▱▱▱]`,
                `${text} [▰▰▱▱▱]`, 
                `${text} [▰▰▰▱▱]`,
                `${text} [▰▰▰▰▱]`,
                `${text} [▰▰▰▰▰]`
            ];
            
            let frameIndex = 0;
            let isActive = true;
            
            const loadingInterval = setInterval(async () => {
                if (!isActive) {
                    clearInterval(loadingInterval);
                    return;
                }
                
                try {
                    await ctx.telegram.editMessageText(
                        ctx.chat.id,
                        loadingMsg.message_id,
                        undefined,
                        frames[frameIndex],
                        { parse_mode: 'Markdown' }
                    );
                    frameIndex = (frameIndex + 1) % frames.length;
                } catch (error) {
                    // Auto stop untuk semua jenis error edit message
                    isActive = false;
                    clearInterval(loadingInterval);
                }
            }, 500);

            return {
                message: loadingMsg,
                stop: () => {
                    isActive = false;
                    clearInterval(loadingInterval);
                },
                isActive: () => isActive,
                messageId: loadingMsg.message_id
            };
        } catch (error) {
            console.error('❌ Failed to create loading animation:', error.message);
            return null;
        }
    },

    safeDeleteMessage: async (ctx, messageId) => {
        try {
            if (messageId) {
                await ctx.deleteMessage(messageId);
                return true;
            }
        } catch (error) {
            // Ignore semua error delete message
        }
        return false;
    },

    safeEditMessage: async (ctx, messageId, text, keyboard = null) => {
        try {
            if (!messageId) return false;
            
            const options = {
                parse_mode: 'Markdown',
                disable_web_page_preview: true,
                ...(keyboard && { reply_markup: keyboard.reply_markup })
            };
            
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                messageId,
                undefined,
                text,
                options
            );
            return true;
        } catch (error) {
            // Ignore semua error edit message
            return false;
        }
    },

    // FIXED: Better animation failure handler
    handleAnimationFailure: async (ctx, animationData, errorMessage = 'Terjadi kesalahan') => {
        try {
            // Stop animation first
            if (animationData && animationData.stop) {
                animationData.stop();
            }
            
            // Coba edit pesan yang ada
            let editSuccess = false;
            if (animationData && animationData.messageId) {
                editSuccess = await animationUtils.safeEditMessage(
                    ctx,
                    animationData.messageId,
                    `❌ *${errorMessage}*`
                );
            }
            
            // Jika edit gagal, kirim pesan baru
            if (!editSuccess) {
                await ctx.reply(
                    `❌ *${errorMessage}*`,
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: Markup.inlineKeyboard([
                            [Markup.button.callback('🔄 Coba Lagi', 'main_menu')]
                        ]).reply_markup
                    }
                );
            }
            
        } catch (error) {
            // Ultimate fallback - try simple message
            try {
                await ctx.reply('❌ Terjadi kesalahan sistem. Silakan coba lagi.');
            } catch (finalError) {
                console.error('❌ Cannot send any message to user:', finalError.message);
            }
        }
    },

    // FIXED: Safe message cleanup
    safeCleanup: async (ctx, animationData) => {
        try {
            if (animationData && animationData.stop) {
                animationData.stop();
            }
        } catch (error) {
            // Ignore cleanup errors
        }
    },

    // FIXED: Create simple loading without animation
    createSimpleLoading: async (ctx, text) => {
        try {
            const loadingMsg = await ctx.reply(text, { 
                parse_mode: 'Markdown' 
            });
            return {
                message: loadingMsg,
                messageId: loadingMsg.message_id,
                stop: () => {}, // No-op for simple loading
                isActive: () => false
            };
        } catch (error) {
            console.error('❌ Failed to create simple loading:', error.message);
            return null;
        }
    },

    // NEW: Enhanced animation handler dengan timeout
    createEnhancedLoading: async (ctx, text, timeoutMs = 10000) => {
        try {
            const loadingMsg = await ctx.reply(text, { 
                parse_mode: 'Markdown' 
            });
            
            const frames = [
                `${text} [▰▱▱▱▱]`,
                `${text} [▰▰▱▱▱]`, 
                `${text} [▰▰▰▱▱]`,
                `${text} [▰▰▰▰▱]`,
                `${text} [▰▰▰▰▰]`
            ];
            
            let frameIndex = 0;
            let isActive = true;
            let lastEditTime = Date.now();
            
            // Auto timeout
            const timeoutTimer = setTimeout(() => {
                isActive = false;
                clearInterval(loadingInterval);
            }, timeoutMs);
            
            const loadingInterval = setInterval(async () => {
                if (!isActive) {
                    clearInterval(loadingInterval);
                    clearTimeout(timeoutTimer);
                    return;
                }
                
                try {
                    // Cek apakah sudah waktunya untuk update (setiap 500ms)
                    const now = Date.now();
                    if (now - lastEditTime >= 500) {
                        await ctx.telegram.editMessageText(
                            ctx.chat.id,
                            loadingMsg.message_id,
                            undefined,
                            frames[frameIndex],
                            { parse_mode: 'Markdown' }
                        );
                        frameIndex = (frameIndex + 1) % frames.length;
                        lastEditTime = now;
                    }
                } catch (error) {
                    // Auto stop untuk semua error
                    isActive = false;
                    clearInterval(loadingInterval);
                    clearTimeout(timeoutTimer);
                }
            }, 100); // Check lebih sering tapi eksekusi tetap 500ms

            return {
                message: loadingMsg,
                stop: () => {
                    isActive = false;
                    clearInterval(loadingInterval);
                    clearTimeout(timeoutTimer);
                },
                isActive: () => isActive,
                messageId: loadingMsg.message_id
            };
        } catch (error) {
            console.error('❌ Failed to create enhanced loading:', error.message);
            return null;
        }
    }
};

// Format service name untuk tampilan yang lebih rapi
function formatServiceName(name) {
    if (!name || typeof name !== 'string') return 'Unknown';
    
    let cleanName = name.replace(/[^\w\s-]/gi, '').trim();
    
    if (!cleanName) return 'Service';
    
    const words = cleanName.split(/\s+/).slice(0, 2);
    cleanName = words.join(' ');
    
    const maxLength = 12;
    if (cleanName.length > maxLength) {
        return cleanName.substring(0, maxLength - 1) + '.';
    }
    return cleanName;
}

// API Functions dengan queue system
const api = {
    rumahotp: {
        getServices: async () => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(`${config.RUMAHOTP_BASE_URL}/v2/services`, {
                    headers: {
                        'x-apikey': config.RUMAHOTP_API_KEY,
                        'Accept': 'application/json'
                    },
                    timeout: 30000
                });
                return response.data;
            }, 'GET_SERVICES', 3, 'normal');
        },

        getCountries: async (serviceId) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(`${config.RUMAHOTP_BASE_URL}/v2/countries?service_id=${serviceId}`, {
                    headers: {
                        'x-apikey': config.RUMAHOTP_API_KEY,
                        'Accept': 'application/json'
                    },
                    timeout: 30000
                });
                return response.data;
            }, 'GET_COUNTRIES', 3, 'normal');
        },

        getOperators: async (country, providerId) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(`${config.RUMAHOTP_BASE_URL}/v2/operators?country=${encodeURIComponent(country)}&provider_id=${providerId}`, {
                    headers: {
                        'x-apikey': config.RUMAHOTP_API_KEY,
                        'Accept': 'application/json'
                    },
                    timeout: 30000
                });
                return response.data;
            }, 'GET_OPERATORS', 3, 'normal');
        },

        createOrder: async (numberId, providerId, operatorId = 1) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v2/orders?number_id=${numberId}&provider_id=${providerId}&operator_id=${operatorId}`, 
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 35000
                    }
                );
                return response.data;
            }, 'CREATE_ORDER', 3, 'high');
        },

        getOrderStatus: async (orderId) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v1/orders/get_status?order_id=${orderId}`, 
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 25000
                    }
                );
                return response.data;
            }, 'GET_ORDER_STATUS', 2, 'high');
        },

        cancelOrder: async (orderId) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v1/orders/set_status?order_id=${orderId}&status=cancel`,
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 25000
                    }
                );
                return response.data;
            }, 'CANCEL_ORDER', 2, 'high');
        },

        createDeposit: async (reffId, nominal) => {
            return await enhancedSafeApiCall(async () => {
                // Fixed calculation to match QRIS price exactly
                const adminFee = Math.ceil(nominal * config.QRIS_FEE_PERCENTAGE / 100) + config.QRIS_FEE_FLAT;
                const totalAmount = nominal + adminFee;

                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v2/deposit/create?amount=${totalAmount}&payment_id=qris`,
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 30000
                    }
                );

                if (response.data && response.data.success) {
                    return {
                        success: true,
                        data: response.data.data,
                        adminFee: adminFee,
                        totalAmount: totalAmount
                    };
                } else {
                    return {
                        success: false,
                        message: response.data?.error?.message || response.data?.message || "Gagal membuat deposit RumahOTP"
                    };
                }
            }, 'CREATE_DEPOSIT_RUMAHOTP', 3, 'high');
        },

        checkDepositStatus: async (depositId) => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v2/deposit/get_status?deposit_id=${depositId}`,
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 25000
                    }
                );

                if (response.data && response.data.success) {
                    return {
                        success: true,
                        data: response.data.data
                    };
                } else {
                    return {
                        success: false,
                        message: response.data?.error?.message || response.data?.message || 'Unknown error'
                    };
                }
            }, 'CHECK_DEPOSIT_STATUS_RUMAHOTP', 2, 'normal');
        },

        cancelDeposit: async (depositId) => {
            return await enhancedSafeApiCall(async () => {
                console.log(`🔄 Canceling RumahOTP deposit: ${depositId}`);
                const response = await axios.get(
                    `${config.RUMAHOTP_BASE_URL}/v1/deposit/cancel?deposit_id=${depositId}`,
                    {
                        headers: {
                            'x-apikey': config.RUMAHOTP_API_KEY,
                            'Accept': 'application/json'
                        },
                        timeout: 25000
                    }
                );

                console.log('📦 RumahOTP Cancel Deposit Response:', JSON.stringify(response.data, null, 2));

                if (response.data && response.data.success) {
                    return {
                        success: true,
                        data: response.data.data
                    };
                } else {
                    return {
                        success: false,
                        message: response.data?.error?.message || response.data?.message || 'Gagal membatalkan deposit'
                    };
                }
            }, 'CANCEL_DEPOSIT_RUMAHOTP', 2, 'high');
        },

        // ADD THIS: Get bot balance
        getBalance: async () => {
            return await enhancedSafeApiCall(async () => {
                const response = await axios.get(`${config.RUMAHOTP_BASE_URL}/v2/profile`, {
                    headers: {
                        'x-apikey': config.RUMAHOTP_API_KEY,
                        'Accept': 'application/json'
                    },
                    timeout: 30000
                });
                return response.data;
            }, 'GET_BALANCE', 3, 'normal');
        }
    },

    atlantich2h: {
        createDeposit: async (reffId, nominal) => {
            return await enhancedSafeApiCall(async () => {
                // Fixed calculation to match QRIS price exactly
                const adminFee = Math.ceil(nominal * config.QRIS_FEE_PERCENTAGE / 100) + config.QRIS_FEE_FLAT;
                const totalAmount = nominal + adminFee;

                const paymentData = qs.stringify({
                    api_key: config.ATLANTICH2H_API_KEY,
                    reff_id: reffId,
                    nominal: parseInt(totalAmount),
                    type: 'ewallet',
                    metode: 'qrisfast'
                });

                const res = await axios.post(
                    `${config.ATLANTICH2H_BASE_URL}/deposit/create`, 
                    paymentData, 
                    {
                        headers: { 
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Accept': 'application/json',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        },
                        timeout: 30000
                    }
                );

                const data = res.data;

                if (!data.status) {
                    return {
                        success: false,
                        message: data.message || "Gagal membuat pembayaran"
                    };
                }

                const info = data.data;
                
                if (!info.qr_string) {
                    return {
                        success: false,
                        message: "QR code tidak tersedia dari payment gateway"
                    };
                }

                return {
                    success: true,
                    data: info,
                    adminFee: adminFee,
                    totalAmount: totalAmount
                };
            }, 'CREATE_DEPOSIT_ATLANTIC', 3, 'high');
        },

        checkDepositStatus: async (trxId) => {
            return await enhancedSafeApiCall(async () => {
                const checkData = qs.stringify({
                    api_key: config.ATLANTICH2H_API_KEY,
                    id: trxId
                });

                const response = await axios.post(
                    `${config.ATLANTICH2H_BASE_URL}/deposit/status`,
                    checkData,
                    {
                        headers: { 
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Accept': 'application/json',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        },
                        timeout: 25000
                    }
                );

                const data = response.data;
                
                if (data && data.status === true) {
                    return {
                        success: true,
                        data: data.data
                    };
                } else {
                    return {
                        success: false,
                        message: data?.message || 'Unknown error'
                    };
                }
            }, 'CHECK_DEPOSIT_STATUS_ATLANTIC', 2, 'normal');
        },

        cancelDeposit: async (trxId) => {
            return await enhancedSafeApiCall(async () => {
                console.log(`🔄 Canceling Atlantic deposit: ${trxId}`);
                const cancelData = qs.stringify({
                    api_key: config.ATLANTICH2H_API_KEY,
                    id: trxId
                });

                const response = await axios.post(
                    `${config.ATLANTICH2H_BASE_URL}/deposit/cancel`,
                    cancelData,
                    {
                        headers: { 
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Accept': 'application/json',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        },
                        timeout: 25000
                    }
                );

                const data = response.data;
                console.log('📦 Atlantic Cancel Deposit Response:', JSON.stringify(data, null, 2));

                if (data && data.status === true) {
                    return {
                        success: true,
                        data: data.data
                    };
                } else {
                    return {
                        success: false,
                        message: data?.message || 'Gagal membatalkan deposit'
                    };
                }
            }, 'CANCEL_DEPOSIT_ATLANTIC', 2, 'high');
        }
    }
};

// Active sessions storage
const activeSessions = {
    services: {},
    countries: {},
    providers: {},
    deposits: {},
    lastCallback: {},
    broadcast: null,
    spam: {},
    analytics: {
        dailyOrders: {},
        dailyDeposits: {}
    }
};

// ==================== ENHANCED AUTO CANCEL ORDER SYSTEM WITH COUNTDOWN ====================
const autoCancelTimers = new Map();
const countdownTimers = new Map();
const countdownLastCheck = new Map();
const countdownLastUpdate = new Map();

// Add refund locks tracking - FIX FOR AUTO REFUND
const refundLocks = new Set();

const autoCancelUtils = {
    refundLocks: refundLocks,
    
    setupAutoCancel: (orderId, userId, dbOrderId, ctx) => {
        const startTime = Date.now();
        const expiryTime = startTime + (5 * 60 * 1000); // 5 minutes
        
        console.log(`⏰ Setting up auto cancel for order: ${orderId}, user: ${userId}`);
        
        // Setup countdown display
        const countdownInterval = setInterval(async () => {
            try {
                const timeLeft = expiryTime - Date.now();
                if (timeLeft <= 0) {
                    clearInterval(countdownInterval);
                    countdownTimers.delete(orderId);
                    countdownLastCheck.delete(orderId);
                    countdownLastUpdate.delete(orderId);
                    return;
                }
                
                // Update countdown setiap 10 detik
                const now = Date.now();
                const lastUpdate = countdownLastUpdate.get(orderId) || 0;
                
                if (now - lastUpdate >= 10000) {
                    countdownLastUpdate.set(orderId, now);
                    
                    const totalSeconds = Math.max(0, Math.floor(timeLeft / 1000));
                    const minutes = Math.floor(totalSeconds / 60);
                    const seconds = totalSeconds % 60;
                    const countdownText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    
                    const data = await safeDbOperation(() => db.load(), 'LOAD_COUNTDOWN_DATA');
                    const order = Object.values(data.orders).find(o => o.orderId === orderId);
                    
                    if (order) {
                        const messageText = `✅ *ORDER BERHASIL DIBUAT*\n\n` +
                            `📱 *Nomor:* \`${order.phoneNumber}\`\n` +
                            `🛍️ *Layanan:* ${order.service}\n` +
                            `🌍 *Negara:* ${order.country}\n` +
                            `💰 *Harga:* Rp${utils.formatNumber(order.finalPrice)}\n` +
                            `⏰ *Kadaluarsa dalam:* ${countdownText}\n\n` +
                            `🆔 *Order ID:* ${orderId}\n\n` +
                            `📞 *Tunggu SMS OTP masuk...*\n` +
                            `🔄 *Status dipantau otomatis*`;
                        
                        try {
                            await ctx.telegram.editMessageText(
                                ctx.chat.id,
                                ctx.update.callback_query?.message?.message_id,
                                undefined,
                                messageText,
                                { parse_mode: 'Markdown' }
                            );
                        } catch (error) {
                            // Ignore edit errors
                        }
                    }
                }
                
                // Check OTP status setiap 10 detik
                const lastStatusCheck = countdownLastCheck.get(orderId) || 0;
                if (now - lastStatusCheck >= 10000) {
                    countdownLastCheck.set(orderId, now);
                    
                    try {
                        const statusResult = await api.rumahotp.getOrderStatus(orderId);
                        const hasOTP = statusResult?.success && statusResult.data?.otp_code && 
                                      statusResult.data.otp_code !== '-' && statusResult.data.otp_code !== '';
                        
                        if (hasOTP) {
                            clearInterval(countdownInterval);
                            countdownTimers.delete(orderId);
                            countdownLastCheck.delete(orderId);
                            countdownLastUpdate.delete(orderId);
                            return;
                        }
                    } catch (statusError) {
                        console.error(`❌ Error checking OTP status for order ${orderId}:`, statusError.message);
                    }
                }
            } catch (error) {
                console.error(`❌ Error in countdown for order ${orderId}:`, error.message);
            }
        }, 3000);
        
        countdownTimers.set(orderId, countdownInterval);

        // Setup auto cancel timer (5 menit)
        const timer = setTimeout(async () => {
            console.log(`⏰ Auto cancel triggered for order: ${orderId}`);
            
            // Cleanup timers
            clearInterval(countdownInterval);
            countdownTimers.delete(orderId);
            countdownLastCheck.delete(orderId);
            countdownLastUpdate.delete(orderId);
            
            try {
                // Check final status sebelum refund
                const statusResult = await api.rumahotp.getOrderStatus(orderId);
                const hasOTP = statusResult?.success && statusResult.data?.otp_code && 
                              statusResult.data.otp_code !== '-' && statusResult.data.otp_code !== '';
                
                if (!hasOTP) {
                    console.log(`🔄 Auto canceling order ${orderId} - No OTP received`);
                    
                    // Execute refund menggunakan fungsi yang sudah diperbaiki
                    const refundSuccess = await processAutoRefund(orderId, dbOrderId, userId, 'Auto cancel - No OTP received');
                    
                    if (refundSuccess) {
                        console.log(`✅ Auto refund completed for order ${orderId}`);
                    } else {
                        console.error(`❌ Auto refund failed for order ${orderId}`);
                        
                        // Retry mechanism
                        setTimeout(async () => {
                            console.log(`🔄 Retrying refund for order ${orderId}`);
                            await processAutoRefund(orderId, dbOrderId, userId, 'Retry - Auto cancel');
                        }, 3000);
                    }
                } else {
                    console.log(`✅ Order ${orderId} has OTP, skip auto cancel`);
                }
                
            } catch (error) {
                console.error(`❌ Error in auto cancel for order ${orderId}:`, error.message);
                
                // Emergency refund on error
                setTimeout(async () => {
                    console.log(`🚨 Emergency refund for order ${orderId} after error`);
                    await processAutoRefund(orderId, dbOrderId, userId, 'Emergency - System error');
                }, 2000);
                
            } finally {
                autoCancelTimers.delete(orderId);
            }
        }, 5 * 60 * 1000);
        
        autoCancelTimers.set(orderId, timer);
        console.log(`⏰ Auto cancel timer set for order ${orderId} (5 minutes)`);
    },
    
    cancelAutoCancel: (orderId) => {
        const timer = autoCancelTimers.get(orderId);
        if (timer) {
            clearTimeout(timer);
            autoCancelTimers.delete(orderId);
        }
        
        const countdown = countdownTimers.get(orderId);
        if (countdown) {
            clearInterval(countdown);
            countdownTimers.delete(orderId);
        }
        
        countdownLastCheck.delete(orderId);
        countdownLastUpdate.delete(orderId);
        
        console.log(`✅ Auto cancel canceled for order ${orderId}`);
    },
    
    cleanupTimers: () => {
        for (const [orderId, timer] of autoCancelTimers.entries()) {
            clearTimeout(timer);
        }
        autoCancelTimers.clear();
        
        for (const [orderId, countdown] of countdownTimers.entries()) {
            clearInterval(countdown);
        }
        countdownTimers.clear();
        
        countdownLastCheck.clear();
        countdownLastUpdate.clear();
        refundLocks.clear();
        
        console.log('🧹 Cleaned up all auto cancel timers and refund locks');
    },
    
    // New function untuk force refund manual
    forceRefund: async (orderId, userId, reason = 'Manual force refund') => {
        console.log(`🔄 Manual force refund for order: ${orderId}`);
        
        const data = await safeDbOperation(() => db.load(), 'LOAD_FORCE_REFUND');
        const order = Object.values(data.orders).find(o => o.orderId === orderId);
        
        if (!order) {
            console.error(`❌ Order ${orderId} not found for force refund`);
            return false;
        }
        
        const dbOrderId = Object.keys(data.orders).find(key => data.orders[key].orderId === orderId);
        return await processAutoRefund(orderId, dbOrderId, userId, reason);
    }
};

// ==================== ENHANCED DEPOSIT COUNTDOWN SYSTEM ====================
const depositCountdownTimers = new Map();
const depositLastCheck = new Map();   // UNTUK TRACK LAST API CHECK DEPOSIT
const depositLastUpdate = new Map();   // UNTUK TRACK LAST COUNTDOWN UPDATE DEPOSIT

const depositCountdownUtils = {
    setupDepositCountdown: (trxId, session, ctx) => {
        const startTime = Date.now();
        const expiryTime = startTime + (10 * 60 * 1000); // 10 minutes
        
        const countdownInterval = setInterval(async () => {
            try {
                const timeLeft = expiryTime - Date.now();
                if (timeLeft <= 0) {
                    clearInterval(countdownInterval);
                    depositCountdownTimers.delete(trxId);
                    depositLastCheck.delete(trxId);
                    depositLastUpdate.delete(trxId);
                    
                    // Auto expire deposit
                    await depositCountdownUtils.handleDepositExpiry(trxId, session, ctx);
                    return;
                }
                
                // UPDATE COUNTDOWN SETIAP 10 DETIK SAJA - HINDARI RATE LIMIT
                const now = Date.now();
                const lastUpdate = depositLastUpdate.get(trxId) || 0;
                
                if (now - lastUpdate >= 10000) { // Update setiap 10 detik
                    depositLastUpdate.set(trxId, now);
                    
                    const countdownText = utils.formatCountdown(timeLeft);
                    const minutesLeft = Math.ceil(timeLeft / (60 * 1000));
                    
                    // CEK STATUS DEPOSIT HANYA SETIAP 10 DETIK - HINDARI RATE LIMIT
                    const lastStatusCheck = depositLastCheck.get(trxId) || 0;
                    
                    let status = 'pending';
                    let statusData = {};
                    
                    if (now - lastStatusCheck >= 10000) { // Cek setiap 10 detik saja
                        depositLastCheck.set(trxId, now);
                        
                        let statusResult;
                        try {
                            if (session.method === 'atlantic') {
                                statusResult = await api.atlantich2h.checkDepositStatus(trxId);
                            } else {
                                statusResult = await api.rumahotp.checkDepositStatus(session.depositId || trxId);
                            }
                            
                            if (statusResult?.success) {
                                statusData = statusResult.data || {};
                                status = statusData.status || 'pending';
                            }
                        } catch (statusError) {
                            console.error(`❌ Error checking deposit status for ${trxId}:`, statusError.message);
                            // Continue countdown even if status check fails
                        }
                    }
                    
                    if (status === 'success' || status === 'paid' || status === 'completed') {
                        clearInterval(countdownInterval);
                        depositCountdownTimers.delete(trxId);
                        depositLastCheck.delete(trxId);
                        depositLastUpdate.delete(trxId);
                        return;
                    }
                    
                    const caption = 
                        `💳 *DETAIL PEMBAYARAN*\n\n` +
                        `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
                        `📦 *Biaya Admin:* Rp${utils.formatNumber(session.adminFee)}\n` +
                        `💠 *Total Bayar:* Rp${utils.formatNumber(session.totalAmount)}\n` +
                        `📊 *Status:* ${status.toUpperCase()}\n` +
                        `🆔 *Ref ID:* ${session.reffId}\n` +
                        `📲 *Scan QR Code di bawah ini:*\n` +
                        `⏰ *Kadaluarsa dalam:* ${countdownText}\n` +
                        `⏳ *Bisa dibatalkan dalam ${minutesLeft} menit*\n\n` +
                        `🔄 *Status akan diperiksa otomatis*`;

                    try {
                        await ctx.telegram.editMessageCaption(
                            ctx.chat.id,
                            ctx.update.callback_query?.message?.message_id,
                            undefined,
                            caption,
                            {
                                parse_mode: 'Markdown',
                                reply_markup: Markup.inlineKeyboard([
                                    [
                                        Markup.button.callback('🔄 Cek Status', `check_deposit_${trxId}`),
                                        Markup.button.callback('❌ Batalkan', `cancel_deposit_${trxId}`)
                                    ],
                                    [Markup.button.callback('🔙 Menu', 'main_menu')]
                                ]).reply_markup
                            }
                        );
                    } catch (error) {
                        // Message might not be editable anymore
                        if (error.message.includes('message to edit not found') || 
                            error.message.includes('message is not modified')) {
                            // Ignore these errors
                        } else {
                            console.error(`❌ Error updating deposit countdown for ${trxId}:`, error.message);
                            clearInterval(countdownInterval);
                            depositCountdownTimers.delete(trxId);
                            depositLastCheck.delete(trxId);
                            depositLastUpdate.delete(trxId);
                        }
                    }
                }
            } catch (error) {
                console.error(`❌ Error in deposit countdown for ${trxId}:`, error.message);
            }
        }, 3000); // Check interval 3 detik, tapi eksekusi hanya setiap 10 detik
        
        depositCountdownTimers.set(trxId, countdownInterval);
    },
    
    cancelDepositCountdown: (trxId) => {
        const countdown = depositCountdownTimers.get(trxId);
        if (countdown) {
            clearInterval(countdown);
            depositCountdownTimers.delete(trxId);
        }
        
        depositLastCheck.delete(trxId); // CLEANUP LAST CHECK
        depositLastUpdate.delete(trxId); // CLEANUP LAST UPDATE
        
        console.log(`✅ Deposit countdown canceled for ${trxId}`);
    },
    
    async handleDepositExpiry(trxId, session, ctx) {
        try {
            await safeDbOperation(() => db.updateTransactionStatus(trxId, 'expired'), 'UPDATE_TRANSACTION_EXPIRED');
            lockUtils.releaseUserLock(session.userId);
            delete activeSessions.deposits[trxId];
            
            await ctx.reply(
                `⏰ *WAKTU PEMBAYARAN HABIS*\n\n` +
                `Deposit telah kadaluarsa.\n` +
                `Ref ID: ${session.reffId}\n\n` +
                `Silakan buat deposit baru jika masih ingin melanjutkan.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('💳 Deposit Lagi', 'deposit_menu')],
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
        } catch (error) {
            console.error('❌ Error handling deposit expiry:', error.message);
        }
    },
    
    cleanupTimers: () => {
        for (const [trxId, countdown] of depositCountdownTimers.entries()) {
            clearInterval(countdown);
        }
        depositCountdownTimers.clear();
        
        depositLastCheck.clear(); // CLEANUP ALL LAST CHECKS
        depositLastUpdate.clear(); // CLEANUP ALL LAST UPDATES
        
        console.log('🧹 Cleaned up all deposit countdown timers');
    }
};

// ==================== FIXED MAIN MENU WITH OWNER BUTTON ====================
const showMainMenu = async (ctx, edit = false) => {
    // Check maintenance mode first
    const settings = db.getSettings();
    if ((settings.maintenance || maintenanceManager.isMaintenanceTime) && !utils.isAdmin(ctx.from.id)) {
        await maintenanceManager.showMaintenanceScreen(ctx);
        return;
    }

    const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_MAIN_MENU');
    const userCount = await safeDbOperation(() => db.getAllUsers().length, 'GET_USER_COUNT');
    let levelInfo = utils.getLevelBenefits(user.level);
    
    const newLevel = utils.calculateLevel(user.totalOrders);
    if (newLevel !== user.level) {
        await safeDbOperation(() => db.updateUser(ctx.from.id, { level: newLevel }), 'UPDATE_USER_LEVEL');
        user.level = newLevel;
        levelInfo = utils.getLevelBenefits(newLevel);
    }

    const referralBonus = settings.referral?.bonus || 200;
    const botUsername = bot.botInfo?.username || 'rumahOtpV1_Bot';
    const referralLink = `https://t.me/${botUsername}?start=ref_${user.referralCode}`;
    
    const menuText = `📊 *DASHBOARD UTAMA*\n\n` +
                   `💰 *Saldo Kamu:* Rp${utils.formatNumber(user.balance)}\n` +
                   `📦 *Total Order Kamu:* ${user.totalOrders}\n` +
                   `💳 *Total Deposit Kamu:* ${user.totalDeposit}\n` +
                   `${levelInfo.name} *Level ${user.level}* (Diskon ${levelInfo.discount || 0}%)\n` +
                   `👥 *Total Pengguna Bot:* ${userCount}\n\n` +
                   `🔗 *Link Referral:*\n<code>${referralLink}</code>\n\n` +
                   `Ajak teman dan dapatkan bonus Rp${utils.formatNumber(referralBonus)} per user!\n\n` +
                   `Pilih menu di bawah untuk mulai\n` +
                   `${utils.getIndonesianTimeShort()}`;

    // Di dalam fungsi showMainMenu - tambahkan ini:
// Buat keyboard berdasarkan apakah user admin atau tidak
let keyboardRows = [
    [
        Markup.button.callback('📱 ORDER NOKOS', 'order_nokos'),
        Markup.button.callback('💳 DEPOSIT', 'deposit_menu')
    ],
    [
        Markup.button.callback('💰 CEK SALDO', 'check_balance'),
        Markup.button.callback('📋 RIWAYAT NOKOS', 'order_history')
    ],
    [
        Markup.button.callback('📊 RIWAYAT DEPOSIT', 'deposit_history'),
        Markup.button.callback('🏆 TOP USER', 'top_users')
    ],
    [
        Markup.button.callback('🎁 REFERRAL', 'referral_menu'),
        Markup.button.callback('🎫 VOUCHER', 'voucher_menu')
    ],
    [
        Markup.button.callback('🤖 CS AI', 'ai_customer_service'),
        Markup.button.callback('❓ BANTUAN', 'help_menu')
    ]
];

// Tambahkan owner menu button untuk admin
if (utils.isAdmin(ctx.from.id)) {
    keyboardRows.push([
        Markup.button.callback('👑 OWNER MENU', 'owner_menu_button')
    ]);
}

keyboardRows.push([
    Markup.button.callback('📢 CHANNEL', 'channel_menu')
]);

    const keyboard = Markup.inlineKeyboard(keyboardRows);

    // Gunakan utility untuk edit/reply
    await messageUtils.replyWithEdit(ctx, menuText, keyboard, 'HTML');
};

// ==================== FIXED MAIN MENU HANDLER ====================
bot.action('main_menu', createBulletproofHandler('MAIN_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    // Langsung tampilkan menu tanpa animasi loading yang kompleks
    await showMainMenu(ctx);
}));

// Handler untuk restart AI service
bot.action('restart_ai_service', createBulletproofHandler('RESTART_AI_SERVICE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery('🔄 Restarting AI Service...');
    
    // Reinitialize Gemini dengan async
    const success = await aiCustomerService.restartService();
    
    const geminiStatus = success ? '🟢 CONNECTED' : '🔴 DISCONNECTED';
    
    await ctx.reply(
        `🔄 *AI SERVICE RESTARTED*\n\n` +
        `Status: ${geminiStatus}\n` +
        `Model: ${config.AI_MODEL || 'gemini-2.0-flash'}\n` +
        `API Key: ${config.GEMINI_API_KEY ? 'SET' : 'NOT SET'}\n\n` +
        `AI Service telah di-restart!`,
        { parse_mode: 'Markdown' }
    );
}));

// Handler untuk AI Customer Service dengan animasi loading berputar
bot.action('ai_customer_service', createBulletproofHandler('AI_CUSTOMER_SERVICE', async (ctx) => {
    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('🤖 *Memuat AI Customer Service...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "🤖 Memuat AI Customer Service [▰▱▱▱▱]",
        "🧠 Inisialisasi AI [▰▰▱▱▱]", 
        "💭 Menyiapkan sistem [▰▰▰▱▱]",
        "📚 Loading pengetahuan [▰▰▰▰▱]",
        "✅ Siap membantu [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 500);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        
        await ctx.reply(
            `🤖 *AI CUSTOMER SERVICE*\n\n` +
            `Halo! Saya AI Assistant Andin Official 🤖\n\n` +
            `Saya bisa membantu Anda dengan:\n` +
            `• Cara menggunakan bot\n` +
            `• Informasi layanan\n` +
            `• Masalah teknis umum\n` +
            `• Pertanyaan tentang deposit\n` +
            `• Dan lain-lain...\n\n` +
            `*Contoh pertanyaan:*\n` +
            `• "Bagaimana cara deposit?"\n` +
            `• "Apa saja layanan yang tersedia?"\n` +
            `• "Kenapa order saya gagal?"\n` +
            `• "Berapa harga nomor WhatsApp?"\n\n` +
            `Silakan ketik pertanyaan Anda di sini:\n` +
            `_(Saya akan menjawab dan admin akan mendapat notifikasi)_`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🗑️ Hapus Riwayat Chat', 'clear_ai_history')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
        
        activeSessions.lastCallback[ctx.from.id] = 'ai_customer_service';
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                '❌ *Gagal memuat AI Customer Service.*',
                { parse_mode: 'Markdown' }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// Handler untuk clear AI history dengan animasi loading berputar
bot.action('clear_ai_history', createBulletproofHandler('CLEAR_AI_HISTORY', async (ctx) => {
    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('🗑️ *Menghapus riwayat chat...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "🗑️ Menghapus riwayat chat [▰▱▱▱▱]",
        "🧹 Membersihkan data [▰▰▱▱▱]", 
        "🔍 Mencari riwayat [▰▰▰▱▱]",
        "📝 Memproses penghapusan [▰▰▰▰▱]",
        "✅ Berhasil dihapus [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 400);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        
        aiCustomerService.clearUserHistory(ctx.from.id);
        
        await ctx.reply(
            `✅ *Riwayat percakapan AI telah dihapus!*\n\n` +
            `Percakapan sebelumnya telah dibersihkan. Silakan mulai pertanyaan baru.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🤖 Tanya AI', 'ai_customer_service')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                '❌ *Gagal menghapus riwayat chat.*',
                { parse_mode: 'Markdown' }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// ==================== FIXED OWNER MENU BUTTON - COMPLETE ====================
bot.action('owner_menu_button', createBulletproofHandler('OWNER_MENU_BUTTON', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const totalUsers = await safeDbOperation(() => db.getAllUsers().length, 'GET_TOTAL_USERS');
    const totalOrders = await safeDbOperation(() => db.getAllUsers().reduce((sum, user) => sum + user.totalOrders, 0), 'GET_TOTAL_ORDERS');
    const totalDeposit = await safeDbOperation(() => db.getAllUsers().reduce((sum, user) => sum + user.totalDeposit, 0), 'GET_TOTAL_DEPOSIT');
    const activeOrders = await safeDbOperation(() => db.getActiveOrders().length, 'GET_ACTIVE_ORDERS');
    const currentDepositMethod = utils.getDepositMethod();
    const currentProfitPercentage = db.load().settings.profitPercentage || config.PROFIT_PERCENTAGE;
    const settings = db.getSettings();

    const ownerMenuText = `👑 *OWNER MENU - Andin Official*\n\n` +
                         `📊 *STATISTIK BOT:*\n` +
                         `👥 Total User: ${totalUsers}\n` +
                         `📦 Total Order: ${totalOrders}\n` +
                         `💳 Total Deposit: ${totalDeposit}\n` +
                         `🔄 Active Orders: ${activeOrders}\n` +
                         `🔧 Deposit Method: ${currentDepositMethod.toUpperCase()}\n` +
                         `💰 Profit Percentage: ${currentProfitPercentage}%\n` +
                         `⚙️ Maintenance: ${settings.maintenance ? 'ON' : 'OFF'}\n` +
                         `📦 Auto Backup: ${settings.backup?.auto ? 'ON' : 'OFF'}\n\n` +
                         `⚙️ *FITUR ADMIN:*`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('📢 BROADCAST', 'owner_broadcast')],
        [Markup.button.callback('📊 STATISTIK DETAIL', 'owner_stats')],
        [Markup.button.callback('🛒 H2H PRODUCTS', 'owner_h2h_products')],
        [Markup.button.callback('💳 H2H ORDER', 'owner_h2h_order')],
        [Markup.button.callback('💰 CAIRKAN SALDO', 'owner_cairkan')],
        [Markup.button.callback('💰 SET HARGA', 'owner_set_price')],
        [Markup.button.callback('🔧 SET DEPOSIT METHOD', 'owner_set_deposit_method')],
        [Markup.button.callback('👥 LIST USER', 'owner_list_users')],
        [Markup.button.callback('⚙️ SETTING BACKUP', 'owner_backup_settings')],
        [Markup.button.callback('🔧 MAINTENANCE', 'owner_maintenance')],
        [Markup.button.callback('🎯 REFERRAL SETTINGS', 'owner_referral_settings')],
        [Markup.button.callback('🎫 BUAT VOUCHER', 'owner_create_voucher')],
        [Markup.button.callback('🚨 AUTO TOP-UP ALERT', 'owner_auto_topup_settings')],
        [Markup.button.callback('💰 PRICE DROP ALERT', 'owner_price_drop_settings')],
        [Markup.button.callback('🤖 AI SETTINGS', 'owner_ai_settings')],
        [Markup.button.callback('🔙 MENU UTAMA', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, ownerMenuText, keyboard);
}));

// Handler untuk kembali ke owner menu dengan animasi loading berputar
// ==================== FIXED OWNERMENU BACK HANDLER ====================
bot.action('ownermenu_back', createBulletproofHandler('OWNERMENU_BACK', async (ctx) => {
    await ctx.answerCbQuery();
    
    // Langsung tampilkan owner menu menggunakan button handler
    await bot.action('owner_menu_button', ctx);
}));

// ==================== OWNER BROADCAST HANDLER ====================
bot.action('owner_broadcast', createBulletproofHandler('OWNER_BROADCAST', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const broadcastText = 
        `📢 *BROADCAST MESSAGE*\n\n` +
        `Silakan kirim pesan broadcast yang ingin dikirim ke semua user:`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 KEMBALI', 'owner_menu_button')]
    ]);

    await messageUtils.replyWithEdit(ctx, broadcastText, keyboard);
    activeSessions.broadcast = ctx.from.id;
}));

// ==================== OWNER STATS DETAIL HANDLER ====================
bot.action('owner_stats', createBulletproofHandler('OWNER_STATS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const allUsers = await safeDbOperation(() => db.getAllUsers(), 'GET_ALL_USERS_STATS');
    const totalOrders = allUsers.reduce((sum, user) => sum + user.totalOrders, 0);
    const totalDeposit = allUsers.reduce((sum, user) => sum + user.totalDeposit, 0);
    const activeUsers = allUsers.filter(user => user.totalOrders > 0).length;
    
    // User dengan deposit tertinggi
    const topDepositors = allUsers
        .sort((a, b) => b.totalDeposit - a.totalDeposit)
        .slice(0, 5);
    
    // User dengan order terbanyak
    const topOrderers = allUsers
        .sort((a, b) => b.totalOrders - a.totalOrders)
        .slice(0, 5);

    let statsText = `📊 *STATISTIK DETAIL BOT*\n\n`;
    statsText += `👥 *Total Users:* ${allUsers.length}\n`;
    statsText += `📦 *Total Orders:* ${totalOrders}\n`;
    statsText += `💰 *Total Deposit:* Rp${utils.formatNumber(totalDeposit)}\n`;
    statsText += `🎯 *Active Users:* ${activeUsers}\n`;
    statsText += `📅 *Tanggal:* ${new Date().toLocaleDateString('id-ID')}\n\n`;
    
    statsText += `🏆 *TOP 5 DEPOSIT:*\n`;
    topDepositors.forEach((user, index) => {
        const name = user.username ? `@${user.username}` : user.first_name || `User ${user.id.substring(0, 6)}`;
        statsText += `${index + 1}. ${name}: Rp${utils.formatNumber(user.totalDeposit)}\n`;
    });
    
    statsText += `\n📦 *TOP 5 ORDER:*\n`;
    topOrderers.forEach((user, index) => {
        const name = user.username ? `@${user.username}` : user.first_name || `User ${user.id.substring(0, 6)}`;
        statsText += `${index + 1}. ${name}: ${user.totalOrders} order\n`;
    });

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔄 Refresh', 'owner_stats')],
        [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
    ]);

    await messageUtils.replyWithEdit(ctx, statsText, keyboard);
}));

// ==================== OWNER LIST USERS HANDLER ====================
bot.action('owner_list_users', createBulletproofHandler('OWNER_LIST_USERS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const usersList = await showUsersList(ctx, 0);
    
    if (!usersList) {
        await messageUtils.replyWithEdit(
            ctx,
            '❌ Gagal memuat daftar user.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}));

// ==================== SHOW USERS LIST FUNCTION ====================
async function showUsersList(ctx, page) {
    try {
        const allUsers = await safeDbOperation(() => db.getAllUsers(), 'GET_ALL_USERS_LIST');
        
        if (allUsers.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ Belum ada user yang terdaftar.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return false;
        }

        const usersPerPage = 8;
        const totalPages = Math.ceil(allUsers.length / usersPerPage);
        const startIndex = page * usersPerPage;
        const endIndex = startIndex + usersPerPage;
        const currentUsers = allUsers.slice(startIndex, endIndex);

        let usersText = `👥 *DAFTAR USER*\n\n`;
        usersText += `Total: ${allUsers.length} user\n`;
        usersText += `Halaman: ${page + 1}/${totalPages}\n\n`;

        currentUsers.forEach((user, index) => {
            const userIndex = startIndex + index + 1;
            const username = user.username ? `@${user.username}` : user.first_name || 'No Name';
            const joinDate = new Date(user.joinDate || user.createdAt).toLocaleDateString('id-ID');
            
            usersText += `*${userIndex}. ${username}*\n`;
            usersText += `🆔 ID: ${user.id}\n`;
            usersText += `💰 Saldo: Rp${utils.formatNumber(user.balance)}\n`;
            usersText += `📦 Orders: ${user.totalOrders}\n`;
            usersText += `💳 Deposit: Rp${utils.formatNumber(user.totalDeposit)}\n`;
            usersText += `📅 Join: ${joinDate}\n`;
            usersText += `━━━━━━━━━━━━━━━━━━\n`;
        });

        const keyboard = [];
        
        // Tombol pagination
        const navRow = [];
        if (page > 0) {
            navRow.push(Markup.button.callback('⬅️ Sebelumnya', `users_page_${page - 1}`));
        }
        if (page < totalPages - 1) {
            navRow.push(Markup.button.callback('Selanjutnya ➡️', `users_page_${page + 1}`));
        }
        if (navRow.length > 0) {
            keyboard.push(navRow);
        }

        keyboard.push([
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]);

        await messageUtils.replyWithEdit(
            ctx,
            usersText,
            Markup.inlineKeyboard(keyboard)
        );
        
        return true;
        
    } catch (error) {
        console.error('Error showing users list:', error);
        return false;
    }
}

// ==================== USERS PAGINATION HANDLER ====================
bot.action(/users_page_(\d+)/, createBulletproofHandler('USERS_PAGE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    const page = parseInt(ctx.match[1]);
    await showUsersList(ctx, page);
}));

// ==================== OWNER SET PRICE HANDLER ====================
bot.action('owner_set_price', createBulletproofHandler('OWNER_SET_PRICE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }
    
    await ctx.answerCbQuery();
    
    const currentPercentage = db.getSettings().profitPercentage || config.PROFIT_PERCENTAGE;
    
    const setPriceText = 
        `💰 *SET HARGA KEUNTUNGAN*\n\n` +
        `Silakan kirim persentase keuntungan (0-100):\n` +
        `Contoh: \`20\` untuk 20% keuntungan\n\n` +
        `Persentase saat ini: ${currentPercentage}%`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 KEMBALI', 'owner_menu_button')]
    ]);

    await messageUtils.replyWithEdit(ctx, setPriceText, keyboard);
    
    activeSessions.lastCallback[ctx.from.id] = 'set_price';
}));

// ==================== OWNER SET DEPOSIT METHOD HANDLER ====================
bot.action('owner_set_deposit_method', createBulletproofHandler('OWNER_SET_DEPOSIT_METHOD', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const currentMethod = utils.getDepositMethod();
    
    const depositMethodText = 
        `🔧 *SET DEPOSIT METHOD*\n\n` +
        `Pilih metode deposit yang ingin digunakan:\n\n` +
        `Metode saat ini: ${currentMethod.toUpperCase()}`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(`🏠 RUMAHOTP ${currentMethod === 'rumahotp' ? '✅' : ''}`, 'set_method_rumahotp'),
            Markup.button.callback(`🌊 ATLANTIC ${currentMethod === 'atlantic' ? '✅' : ''}`, 'set_method_atlantic')
        ],
        [Markup.button.callback('🔙 KEMBALI', 'owner_menu_button')]
    ]);

    await messageUtils.replyWithEdit(ctx, depositMethodText, keyboard);
}));

// ==================== SET METHOD RUMAHOTP HANDLER ====================
bot.action('set_method_rumahotp', createBulletproofHandler('SET_METHOD_RUMAHOTP', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    utils.setDepositMethod('rumahotp');
    await ctx.answerCbQuery('✅ Deposit method diubah ke RUMAHOTP!');
    
    const successText = 
        `✅ *DEPOSIT METHOD DIUBAH!*\n\n` +
        `Metode deposit sekarang: RUMAHOTP\n\n` +
        `Semua transaksi deposit baru akan menggunakan RumahOTP.`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 KEMBALI', 'owner_set_deposit_method')]
    ]);

    await messageUtils.replyWithEdit(ctx, successText, keyboard);
}));

// ==================== SET METHOD ATLANTIC HANDLER ====================
bot.action('set_method_atlantic', createBulletproofHandler('SET_METHOD_ATLANTIC', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    utils.setDepositMethod('atlantic');
    await ctx.answerCbQuery('✅ Deposit method diubah ke ATLANTIC!');
    
    const successText = 
        `✅ *DEPOSIT METHOD DIUBAH!*\n\n` +
        `Metode deposit sekarang: ATLANTIC\n\n` +
        `Semua transaksi deposit baru akan menggunakan Atlantic H2H.`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 KEMBALI', 'owner_set_deposit_method')]
    ]);

    await messageUtils.replyWithEdit(ctx, successText, keyboard);
}));

// ==================== OWNER BACKUP SETTINGS HANDLER ====================
bot.action('owner_backup_settings', createBulletproofHandler('OWNER_BACKUP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const backupSettings = settings.backup || {
        auto: false,
        daily: false,
        time: '18.00'
    };
    
    const backupText = 
        `📦 *BACKUP SETTINGS*\n\n` +
        `🔄 Auto Backup: ${backupSettings.auto ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `📅 Daily Backup: ${backupSettings.daily ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Backup Time: ${backupSettings.time}\n\n` +
        `Pilih pengaturan:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(backupSettings.auto ? '🔴 Matikan Auto' : '🟢 Hidupkan Auto', 
                                 `toggle_backup_${backupSettings.auto ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback(backupSettings.daily ? '🔴 Matikan Daily' : '🟢 Hidupkan Daily', 
                                 `toggle_daily_backup_${backupSettings.daily ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback('⏰ Ubah Waktu', 'change_backup_time'),
            Markup.button.callback('💾 Backup Sekarang', 'backup_now')
        ],
        [
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, backupText, keyboard);
}));

// ==================== OWNER MAINTENANCE HANDLER ====================
bot.action('owner_maintenance', createBulletproofHandler('OWNER_MAINTENANCE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const maintenanceStatus = settings.maintenance ? 'ON 🔴' : 'OFF 🟢';
    const autoMaintenance = maintenanceManager.maintenanceSchedule.enabled ? 'ON 🟢' : 'OFF 🔴';
    const schedule = `${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB`;

    const maintenanceText = 
        `🔧 *MAINTENANCE SETTINGS*\n\n` +
        `🔄 Status Manual: ${maintenanceStatus}\n` +
        `⏰ Auto Maintenance: ${autoMaintenance}\n` +
        `📅 Jadwal: ${schedule}\n\n` +
        `Pilih aksi:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(settings.maintenance ? '✅ Matikan Maintenance' : '🔴 Hidupkan Maintenance', 
                                 `toggle_maintenance_${settings.maintenance ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback('⏰ Ubah Jadwal', 'change_maintenance_schedule'),
            Markup.button.callback('🔄 Toggle Auto', 'toggle_auto_maintenance')
        ],
        [
            Markup.button.callback('📊 Status', 'check_maintenance_status'),
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, maintenanceText, keyboard);
}));

// ==================== OWNER REFERRAL SETTINGS HANDLER ====================
bot.action('owner_referral_settings', createBulletproofHandler('OWNER_REFERRAL_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const referralSettings = settings.referral || {
        enabled: true,
        bonus: 200,
        referrerBonus: 200,
        referredBonus: 100
    };
    
    const referralText = 
        `🎯 *REFERRAL SETTINGS*\n\n` +
        `🔄 Status: ${referralSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `💰 Bonus Referrer: Rp${utils.formatNumber(referralSettings.bonus)}\n` +
        `🎁 Bonus Referred: Rp${utils.formatNumber(referralSettings.referredBonus || 100)}\n\n` +
        `Pilih pengaturan:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(referralSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                 `toggle_referral_${referralSettings.enabled ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback('💰 Ubah Bonus', 'change_referral_bonus'),
            Markup.button.callback('🎁 Ubah Bonus Referred', 'change_referred_bonus')
        ],
        [
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, referralText, keyboard);
}));

// ==================== OWNER CREATE VOUCHER HANDLER ====================
bot.action('owner_create_voucher', createBulletproofHandler('OWNER_CREATE_VOUCHER', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const voucherText = 
        `🎫 *BUAT VOUCHER*\n\n` +
        `Silakan kirim data voucher dengan format:\n\n` +
        `\`KODE_NOMINAL_BATAS_PAKAI\`\n\n` +
        `📋 *Contoh:*\n` +
        `• WELCOME10000_1 (Voucher Rp10.000, bisa dipakai 1x)\n` +
        `• DISKON5000_5 (Voucher Rp5.000, bisa dipakai 5x)\n` +
        `• BONUS2000_unlimited (Voucher Rp2.000, unlimited)\n\n` +
        `Ketik langsung di chat:`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
    ]);

    await messageUtils.replyWithEdit(ctx, voucherText, keyboard);
    
    activeSessions.lastCallback[ctx.from.id] = 'create_voucher';
}));

// ==================== HANDLE CREATE VOUCHER FUNCTION ====================
async function handleCreateVoucher(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        // Parse voucher data dari format: KODE_NOMINAL_BATAS_PAKAI
        const parts = messageText.split('_');
        
        if (parts.length < 2) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *FORMAT SALAH!*\n\n' +
                'Format yang benar: `KODE_NOMINAL_BATAS_PAKAI`\n\n' +
                'Contoh:\n' +
                '• WELCOME10000_1\n' +
                '• DISKON5000_5\n' +
                '• BONUS2000_unlimited',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        const voucherCode = parts[0].toUpperCase();
        const nominal = parseInt(parts[1]);
        
        if (isNaN(nominal) || nominal <= 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *NOMINAL TIDAK VALID!*\n\n' +
                'Nominal harus angka positif.\n' +
                'Contoh: 10000, 5000, 2000',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        let maxUsage = 1; // Default 1 kali pakai
        if (parts.length >= 3) {
            if (parts[2].toLowerCase() === 'unlimited') {
                maxUsage = null; // Unlimited
            } else {
                maxUsage = parseInt(parts[2]) || 1;
            }
        }
        
        // Cek apakah voucher sudah ada
        const existingVoucher = await safeDbOperation(() => db.getVoucher(voucherCode), 'GET_VOUCHER_CHECK');
        
        if (existingVoucher) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *VOUCHER SUDAH ADA!*\n\n` +
                `Kode voucher "${voucherCode}" sudah terdaftar.\n` +
                `Silakan gunakan kode yang berbeda.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        // Buat voucher baru
        const voucherData = {
            code: voucherCode,
            amount: nominal,
            maxUsage: maxUsage,
            used: false,
            usedBy: null,
            usedAt: null,
            usedCount: 0,
            createdAt: Date.now(),
            createdBy: userId
        };
        
        const success = await safeDbOperation(() => db.addVoucher(voucherData), 'ADD_VOUCHER');
        
        if (success) {
            const usageText = maxUsage ? `Batas pakai: ${maxUsage} kali` : 'Unlimited usage';
            
            await messageUtils.replyWithEdit(
                ctx,
                `✅ *VOUCHER BERHASIL DIBUAT!*\n\n` +
                `🎫 *Kode:* ${voucherCode}\n` +
                `💰 *Nominal:* Rp${utils.formatNumber(nominal)}\n` +
                `📊 ${usageText}\n` +
                `📅 *Dibuat pada:* ${new Date().toLocaleString('id-ID')}\n\n` +
                `Voucher siap digunakan oleh user!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🎫 Buat Lagi', 'owner_create_voucher')],
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            
            // Kirim notifikasi ke channel
            try {
                await bot.telegram.sendMessage(
                    config.CHANNEL_ID,
                    `🎉 *VOUCHER BARU TERSEDIA!*\n\n` +
                    `🎫 Kode: *${voucherCode}*\n` +
                    `💰 Nilai: Rp${utils.formatNumber(nominal)}\n` +
                    `📊 ${usageText}\n\n` +
                    `Gunakan voucher ini untuk mendapatkan bonus saldo!\n\n` +
                    `*Cara pakai:*\n` +
                    `1. Pilih menu "🎫 VOUCHER"\n` +
                    `2. Pilih "GUNAKAN VOUCHER"\n` +
                    `3. Masukkan kode *${voucherCode}*\n\n` +
                    `⏰ *Segera gunakan sebelum habis!*`,
                    { parse_mode: 'Markdown' }
                );
            } catch (error) {
                console.error('Error sending voucher notification to channel:', error);
            }
            
        } else {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *GAGAL MEMBUAT VOUCHER!*\n\n' +
                'Terjadi kesalahan saat menyimpan voucher.\n' +
                'Silakan coba lagi.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
        }
        
    } catch (error) {
        console.error('Error handling create voucher:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *TERJADI KESALAHAN!*\n\n' +
            'Gagal memproses pembuatan voucher.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}

// ==================== OWNER AUTO TOPUP SETTINGS HANDLER ====================
bot.action('owner_auto_topup_settings', createBulletproofHandler('OWNER_AUTO_TOPUP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const autoTopupSettings = settings.autoTopupAlert || {
        enabled: true,
        threshold: 50000,
        lastAlertSent: null
    };
    
    const lastAlert = autoTopupSettings.lastAlertSent 
        ? new Date(autoTopupSettings.lastAlertSent).toLocaleString('id-ID') 
        : 'Belum pernah';
    
    const autoTopupText = 
        `🚨 *AUTO TOP-UP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${autoTopupSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `💰 Threshold: Rp${utils.formatNumber(autoTopupSettings.threshold)}\n` +
        `⏰ Terakhir Alert: ${lastAlert}\n\n` +
        `Pilih pengaturan:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(autoTopupSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                 `toggle_auto_topup_${autoTopupSettings.enabled ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback('💰 Ubah Threshold', 'change_auto_topup_threshold'),
            Markup.button.callback('🔍 Test Alert', 'test_auto_topup_alert')
        ],
        [
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, autoTopupText, keyboard);
}));

// ==================== OWNER PRICE DROP SETTINGS HANDLER ====================
bot.action('owner_price_drop_settings', createBulletproofHandler('OWNER_PRICE_DROP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const priceDropSettings = settings.priceDropAlert || {
        enabled: true,
        delayBetweenAlerts: 60000,
        minDropAmount: 1000,
        minDropPercentage: 0.10,
        lastAlertSent: null
    };

    const delayInMinutes = Math.floor(priceDropSettings.delayBetweenAlerts / 60000);
    const minDropPercentageDisplay = (priceDropSettings.minDropPercentage * 100).toFixed(0);
    const lastAlert = priceDropSettings.lastAlertSent 
        ? new Date(priceDropSettings.lastAlertSent).toLocaleString('id-ID') 
        : 'Belum pernah';

    const priceDropText = 
        `💰 *PRICE DROP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${priceDropSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Delay Antar Alert: ${delayInMinutes} menit\n` +
        `📉 Minimal Turun: Rp${utils.formatNumber(priceDropSettings.minDropAmount)} atau ${minDropPercentageDisplay}%\n` +
        `⏰ Terakhir Alert: ${lastAlert}\n\n` +
        `Pilih pengaturan:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback(priceDropSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                 `toggle_price_drop_${priceDropSettings.enabled ? 'off' : 'on'}`)
        ],
        [
            Markup.button.callback('⏰ Ubah Delay', 'change_price_drop_delay'),
            Markup.button.callback('📉 Ubah Minimum', 'change_price_drop_minimum')
        ],
        [
            Markup.button.callback('🔄 Reset Cooldown', 'reset_price_drop_cooldown'),
            Markup.button.callback('🔍 Test Alert', 'test_price_drop_alert')
        ],
        [
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, priceDropText, keyboard);
}));

// ==================== OWNER AI SETTINGS HANDLER ====================
bot.action('owner_ai_settings', createBulletproofHandler('OWNER_AI_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const aiStatus = config.AI_ENABLED ? 'ON 🟢' : 'OFF 🔴';
    const geminiStatus = aiCustomerService.initialized ? '🟢 CONNECTED' : '🔴 DISCONNECTED';
    const conversationCount = aiCustomerService.conversationHistory.size;
    
    const aiText = 
        `🤖 *AI CUSTOMER SERVICE SETTINGS*\n\n` +
        `🔄 Status: ${aiStatus}\n` +
        `🔗 Gemini Status: ${geminiStatus}\n` +
        `🧠 Model: ${config.AI_MODEL || 'gemini-2.0-flash'}\n` +
        `👥 Active Conversations: ${conversationCount}\n\n` +
        `Pilih aksi:`;

    const keyboard = Markup.inlineKeyboard([
        [
            Markup.button.callback('🔄 Restart AI', 'restart_ai_service'),
            Markup.button.callback('🧹 Clear All History', 'clear_all_ai_history')
        ],
        [
            Markup.button.callback('🔍 Test AI', 'test_ai_service'),
            Markup.button.callback('📊 Stats', 'ai_stats')
        ],
        [
            Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')
        ]
    ]);

    await messageUtils.replyWithEdit(ctx, aiText, keyboard);
}));

// ==================== RESTART AI SERVICE HANDLER ====================
bot.action('restart_ai_service', createBulletproofHandler('RESTART_AI_SERVICE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery('🔄 Restarting AI Service...');
    
    // Reinitialize Gemini dengan async
    const success = await aiCustomerService.restartService();
    
    const geminiStatus = success ? '🟢 CONNECTED' : '🔴 DISCONNECTED';
    
    const restartText = 
        `🔄 *AI SERVICE RESTARTED*\n\n` +
        `Status: ${geminiStatus}\n` +
        `Model: ${config.AI_MODEL || 'gemini-2.0-flash'}\n` +
        `API Key: ${config.GEMINI_API_KEY ? 'SET' : 'NOT SET'}\n\n` +
        `AI Service telah di-restart!`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'owner_ai_settings')]
    ]);

    await messageUtils.replyWithEdit(ctx, restartText, keyboard);
}));

// ==================== CLEAR ALL AI HISTORY HANDLER ====================
bot.action('clear_all_ai_history', createBulletproofHandler('CLEAR_ALL_AI_HISTORY', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    aiCustomerService.clearAllHistory();
    await ctx.answerCbQuery('✅ Semua riwayat AI telah dihapus!');
    
    const clearText = 
        `🧹 *SEMUA RIWAYAT AI DIHAPUS!*\n\n` +
        `Semua percakapan AI telah dibersihkan.\n` +
        `User akan mulai percakapan baru dari awal.`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'owner_ai_settings')]
    ]);

    await messageUtils.replyWithEdit(ctx, clearText, keyboard);
}));

// ==================== TEST AI SERVICE HANDLER ====================
bot.action('test_ai_service', createBulletproofHandler('TEST_AI_SERVICE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery('🤖 Testing AI Service...');
    
    try {
        const testQuestion = "Apa saja layanan yang tersedia di bot ini?";
        const aiResponse = await aiCustomerService.handleCustomerQuery(ctx.from.id, testQuestion, 'Admin Test');
        
        const testText = 
            `🤖 *AI SERVICE TEST*\n\n` +
            `❓ *Pertanyaan Test:*\n${testQuestion}\n\n` +
            `💬 *Jawaban AI:*\n${aiResponse.response || 'No response'}\n\n` +
            `📊 *Status:* ${aiResponse.success ? 'BERHASIL ✅' : 'GAGAL ❌'}\n` +
            `👤 *Requires Human:* ${aiResponse.requiresHuman ? 'YA' : 'TIDAK'}`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🔙 Kembali', 'owner_ai_settings')]
        ]);

        await messageUtils.replyWithEdit(ctx, testText, keyboard);
        
    } catch (error) {
        const errorText = 
            `❌ *AI SERVICE TEST GAGAL*\n\n` +
            `Error: ${error.message}\n\n` +
            `AI Service mungkin sedang offline.`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🔙 Kembali', 'owner_ai_settings')]
        ]);

        await messageUtils.replyWithEdit(ctx, errorText, keyboard);
    }
}));

// ==================== AI STATS HANDLER ====================
bot.action('ai_stats', createBulletproofHandler('AI_STATS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    const conversationCount = aiCustomerService.conversationHistory.size;
    const usersWithHistory = Array.from(aiCustomerService.conversationHistory.keys());
    
    let statsText = `📊 *AI SERVICE STATISTICS*\n\n`;
    statsText += `💬 Active Conversations: ${conversationCount}\n`;
    statsText += `👥 Unique Users: ${usersWithHistory.length}\n`;
    statsText += `🔗 Gemini Status: ${aiCustomerService.initialized ? 'CONNECTED 🟢' : 'DISCONNECTED 🔴'}\n\n`;
    
    if (usersWithHistory.length > 0) {
        statsText += `👤 *Users with AI History:*\n`;
        usersWithHistory.slice(0, 10).forEach(userId => {
            const history = aiCustomerService.getConversationHistory(userId);
            statsText += `• User ${userId.substring(0, 8)}... (${history.length/2} messages)\n`;
        });
        
        if (usersWithHistory.length > 10) {
            statsText += `• ...dan ${usersWithHistory.length - 10} user lainnya\n`;
        }
    }

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔄 Refresh', 'ai_stats')],
        [Markup.button.callback('🔙 Kembali', 'owner_ai_settings')]
    ]);

    await messageUtils.replyWithEdit(ctx, statsText, keyboard);
}));

/// Handler untuk deposit menu - FIXED VERSION (NO DELETE)
bot.action('deposit_menu', createBulletproofHandler('DEPOSIT_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    if (lockUtils.isUserLocked(ctx.from.id)) {
        await ctx.answerCbQuery('⚠️ Anda sedang memiliki transaksi aktif. Selesaikan dulu.', { show_alert: true });
        return;
    }
    
    try {
        // Langsung tampilkan menu deposit tanpa menghapus pesan sebelumnya
        await showDepositMenu(ctx);
        
    } catch (error) {
        console.error('❌ Error in DEPOSIT_MENU:', error.message);
        
        // Kirim pesan error sebagai pesan baru
        await ctx.reply(
            '❌ *Gagal memuat menu deposit.*\n\nSilakan coba lagi.',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
    }
}));
// Handler untuk cek saldo dengan animasi loading berputar
// ==================== FIXED CHECK BALANCE HANDLER ====================
bot.action('check_balance', createBulletproofHandler('CHECK_BALANCE', async (ctx) => {
    await ctx.answerCbQuery();
    
    const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_BALANCE');
    
    const balanceText = 
        `💰 *SALDO ANDA*\n\n` +
        `💵 *Saldo Saat Ini:* Rp${utils.formatNumber(user.balance)}\n` +
        `📦 *Total Order:* ${user.totalOrders}\n` +
        `💳 *Total Deposit:* ${user.totalDeposit}\n\n` +
        `Gunakan saldo untuk order nokos atau tarik saldo.`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('📱 Order Nokos', 'order_nokos')],
        [Markup.button.callback('💳 Deposit', 'deposit_menu')],
        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, balanceText, keyboard);
}));

// ==================== FIXED ORDER NOKOS HANDLER ====================
bot.action('order_nokos', createBulletproofHandler('ORDER_NOKOS', async (ctx) => {
    await ctx.answerCbQuery();
    
    if (lockUtils.isUserLocked(ctx.from.id)) {
        await ctx.answerCbQuery('⚠️ Anda sedang memiliki transaksi aktif. Selesaikan dulu.', { show_alert: true });
        return;
    }
    
    // Langsung tampilkan menu services tanpa animasi loading
    await showServicesMenu(ctx);
}));

// Handler untuk riwayat order dengan animasi loading berputar - FIXED VERSION
bot.action('order_history', createBulletproofHandler('ORDER_HISTORY', async (ctx) => {
    await ctx.answerCbQuery();
    await showOrderHistory(ctx);
}));

// Handler untuk riwayat deposit dengan animasi loading berputar
bot.action('deposit_history', createBulletproofHandler('DEPOSIT_HISTORY', async (ctx) => {
    await ctx.answerCbQuery();
    await showDepositHistory(ctx);
}));

// Handler untuk top users dengan animasi loading berputar
bot.action('top_users', createBulletproofHandler('TOP_USERS', async (ctx) => {
    await ctx.answerCbQuery();
    await showTopUsers(ctx);
}));

// Handler untuk bantuan dengan animasi loading berputar
// ==================== FIXED HELP MENU HANDLER ====================
bot.action('help_menu', createBulletproofHandler('HELP_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    const settings = db.getSettings();
    const referralBonus = settings.referral?.bonus || 500;
    
    const helpText = 
        `❓ *BANTUAN & PANDUAN*\n\n` +
        `📱 *Cara Order Nokos:*\n` +
        `1. Pilih "ORDER NOKOS"\n` +
        `2. Pilih layanan (WhatsApp, Telegram, dll)\n` +
        `3. Pilih negara\n` +
        `4. Pilih operator\n` +
        `5. Konfirmasi order\n\n` +
        `💳 *Cara Deposit:*\n` +
        `1. Pilih "DEPOSIT"\n` +
        `2. Pilih nominal atau custom\n` +
        `3. Scan QR Code\n` +
        `4. Tunggu konfirmasi otomatis\n\n` +
        `🎁 *Sistem Referral:*\n` +
        `Dapatkan bonus Rp${utils.formatNumber(referralBonus)} per user yang bergabung melalui link referral Anda!\n\n` +
        `📞 *Butuh Bantuan?*\n` +
        `Hubungi: @KingStoreGanteng`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, helpText, keyboard);
}));

// Handler untuk channel dengan animasi loading berputar
// ==================== FIXED CHANNEL MENU HANDLER ====================
bot.action('channel_menu', createBulletproofHandler('CHANNEL_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    const channelText = 
        `📢 *CHANNEL RESMI*\n\n` +
        `Bergabung dengan channel kami untuk informasi terbaru:\n\n` +
        `📢 @testiandinoffc\n` +
        `📢 @testiandinoffc\n` +
        `Dapatkan update tentang:\n` +
        `• Layanan baru\n` +
        `• Promo dan bonus spesial\n` +
        `• Info maintenance\n` +
        `• Testimoni user\n` +
        `• Tutorial penggunaan\n\n` +
        `🔔 *Jangan lupa join kedua channel tersebut!*`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.url('📢 Join Channel', 'https://t.me/testiandinoffc')],
        [Markup.button.url('📢 Join Channel', 'https://t.me/testiandinoffc')],
        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, channelText, keyboard);
}));
// ==================== UPDATED START COMMAND ====================
bot.start(createBulletproofHandler('START_COMMAND', async (ctx) => {
    const userId = ctx.from.id;
    
    const isMember = await utils.isUserInChannel(userId);
    if (!isMember) {
        // Gunakan safeText untuk mencegah parsing error
        const firstName = utils.safeText(ctx.from.first_name || '', 'html');
        
        const channelMessage = 
            `👋 Hai <b>${firstName}</b>!\n\n` +
            `Untuk menggunakan bot ini, kamu harus bergabung dengan channel official kami terlebih dahulu.\n\n` +
            `📢 <b>Channel Official:</b> @${config.LOG_CHANNEL.replace('@', '')}\n\n` +
            `Setelah bergabung, klik tombol <b>"Cek Lagi"</b> di bawah.`;
        
        await ctx.reply(channelMessage, {
            parse_mode: 'HTML',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.url('📢 Join Channel', `https://t.me/${config.LOG_CHANNEL.replace('@', '')}`)],
                [Markup.button.callback('✅ Cek Lagi', 'check_membership')]
            ]).reply_markup
        });
        return;
    }

    const user = await safeDbOperation(() => db.getUser(userId), 'GET_USER_START');
    
    const updates = {
        username: ctx.from.username || user.username,
        first_name: ctx.from.first_name || user.first_name,
        last_name: ctx.from.last_name || user.last_name
    };
    
    await safeDbOperation(() => db.updateUser(userId, updates), 'UPDATE_USER_START');

    // Enhanced referral system
    const startPayload = ctx.startPayload;
    if (startPayload && startPayload.startsWith('ref_')) {
        const referralCode = startPayload.replace('ref_', '');
        
        if (!user.referredBy && referralCode && referralCode.length >= 6) {
            const referrer = await safeDbOperation(() => db.getUserByReferralCode(referralCode), 'GET_REFERRER');
            
            if (referrer && referrer.id !== userId.toString()) {
                const settings = db.getSettings();
                
                if (settings.referral?.enabled !== false) {
                    const referrerBonus = settings.referral?.referrerBonus || settings.referral?.bonus || 200;
                    const referredBonus = settings.referral?.referredBonus || 100;
                    
                    // Update referrer
                    referrer.balance += referrerBonus;
                    referrer.referralCount = (referrer.referralCount || 0) + 1;
                    referrer.referralEarnings = (referrer.referralEarnings || 0) + referrerBonus;
                    await safeDbOperation(() => db.updateUser(referrer.id, referrer), 'UPDATE_REFERRER');
                    
                    // Update referred user
                    user.balance += referredBonus;
                    user.referredBy = referrer.id;
                    await safeDbOperation(() => db.updateUser(userId, user), 'UPDATE_REFERRED_USER');
                    
                    // Add referral record
                    await safeDbOperation(() => db.addReferral(referrer.id, userId), 'ADD_REFERRAL');
                    
                    await ctx.reply(
                        `🎉 *SELAMAT! BONUS REFERRAL*\n\n` +
                        `Kamu bergabung melalui referral dari user lain! 🌟\n` +
                        `Kamu mendapatkan bonus sebesar *Rp${utils.formatNumber(referredBonus)}*!\n\n` +
                        `Sekarang kamu juga bisa dapatkan bonus dengan mengajak teman!`,
                        { parse_mode: 'Markdown' }
                    );
                    
                    try {
                        await bot.telegram.sendMessage(
                            referrer.id,
                            `🎉 *BONUS REFERRAL DITERIMA!*\n\n` +
                            `🥳 User baru bergabung menggunakan link referral kamu!\n\n` +
                            `💰 *Bonus Referrer:* Rp${utils.formatNumber(referrerBonus)}\n` +
                            `🎁 *Bonus Referred:* Rp${utils.formatNumber(referredBonus)}\n` +
                            `📊 *Total Referral:* ${referrer.referralCount}\n` +
                            `💎 *Total Earnings:* Rp${utils.formatNumber(referrer.referralEarnings)}\n\n` +
                            `Terus ajak teman untuk mendapatkan bonus lebih banyak! 🚀`,
                            { parse_mode: 'Markdown' }
                        );
                    } catch (error) {
                        console.error('Error sending referral notification:', error);
                    }
                }
            }
        }
    }

    // Di dalam start command, perbaiki bagian notifikasi new users:
if (config.NOTIFY_NEW_USERS && !user.hasBeenNotified) {
    try {
        // Gunakan safeText untuk semua teks
        const escapedFirstName = utils.safeText(ctx.from.first_name || '', 'markdown');
        const escapedLastName = utils.safeText(ctx.from.last_name || '', 'markdown');
        const escapedUsername = ctx.from.username ? utils.safeText(ctx.from.username, 'markdown') : 'Tidak ada';
        const fullName = [escapedFirstName, escapedLastName].filter(Boolean).join(' ') || 'Unknown';
        
        await ctx.telegram.sendMessage(
            config.CHANNEL_ID,
            `👤 *USER BARU MEMULAI BOT*\n\n` +
            `🆔 *ID:* ${userId}\n` +
            `👤 *Nama:* ${fullName}\n` +
            `📧 *Username:* ${ctx.from.username ? '@' + escapedUsername : 'Tidak ada'}\n` +
            `📅 *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `🤖 *Bot:* Andin Official`,
            { parse_mode: 'Markdown' }
        );
            
        await safeDbOperation(() => db.updateUser(userId, { hasBeenNotified: true }), 'UPDATE_USER_NOTIFIED');
            
    } catch (error) {
        console.error('Error sending new user notification to owner:', error);
    }
}

    await showMainMenu(ctx);
}));

// ==================== H2H COMMAND HANDLERS ====================

// 🛒 /listh2h — Cari Produk H2H RumahOTP
bot.command('listh2h', createBulletproofHandler('LIST_H2H', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.reply("🚫 *Akses ditolak!*\nHanya owner yang dapat menggunakan perintah ini.", {
            parse_mode: "Markdown"
        });
        return;
    }

    const keyword = (ctx.message.text.split(' ').slice(1).join(' ') || "").toLowerCase().trim();

    if (!keyword) {
        await ctx.reply(
`❗ *Cara pakai:*
Gunakan perintah:
\`/listh2h <kata kunci>\`

Contoh:
• /listh2h dana  
• /listh2h ff  
• /listh2h mlbb 86  
• /listh2h pulsa`,
        { parse_mode: "Markdown" }
        );
        return;
    }

    try {
        const res = await axios.get("https://www.rumahotp.com/api/v1/h2h/product", {
            headers: { "x-apikey": config.RUMAHOTP_API_KEY }
        });

        let list = res.data.data || [];

        // 🔥 Urutkan harga termurah → termahal
        list = list.sort((a, b) => a.price - b.price);

        const result = list.filter(p =>
            p.name.toLowerCase().includes(keyword) ||
            p.brand.toLowerCase().includes(keyword) ||
            p.note.toLowerCase().includes(keyword) ||
            p.code.toLowerCase().includes(keyword)
        );

        if (result.length === 0) {
            await ctx.reply(`⚠️ Tidak ada produk ditemukan untuk kata kunci *${keyword}*`, { 
                parse_mode: "Markdown" 
            });
            return;
        }

        // simpan data ke memory
        const pageSize = 5;
        const totalPages = Math.ceil(result.length / pageSize);

        const state = {
            keyword,
            result,
            pageSize,
            totalPages
        };

        global.h2hPages[ctx.chat.id] = state;

        sendH2HPage(bot, ctx.chat.id, 1);

    } catch (err) {
        console.error(err);
        await ctx.reply("❌ Terjadi kesalahan saat mengambil produk.");
    }
}));

// 💳 /orderh2h — Order Produk H2H
bot.command('orderh2h', createBulletproofHandler('ORDER_H2H', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.reply("🚫 *Akses ditolak!*\nHanya owner yang dapat menggunakan perintah ini.", {
            parse_mode: "Markdown"
        });
        return;
    }

    const args = ctx.message.text.split(' ').slice(1);
    const code = args[0];
    const target = args[1];

    // ❗ Jika tanpa argumen → kasih tutorial
    if (!code || !target) {
        await ctx.reply(
`❗ *Format salah!*

Gunakan perintah:
*/orderh2h <kode> <target>*

Contoh:
\`/orderh2h pln 1234567890\`
\`/orderh2h pulsa 08951234xxxx\`

📌 *kode* = kode produk (cek daftar produk)
📌 *target* = nomor / tujuan pembelian

Silakan coba lagi.`,
            { parse_mode: "Markdown" }
        );
        return;
    }

    const loadingMsg = await ctx.reply("⏳ *Memproses transaksi...*", {
        parse_mode: "Markdown"
    });

    try {
        // 🔥 Buat transaksi
        const url = `https://www.rumahotp.com/api/v1/h2h/transaksi/create?id=${code}&target=${target}`;
        const res = await axios.get(url, {
            headers: {
                "x-apikey": config.RUMAHOTP_API_KEY,
                "Accept": "application/json"
            }
        });

        if (!res.data.success) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                `❌ *Transaksi gagal!*\nPesan: ${res.data.message || "Tidak diketahui."}`,
                { parse_mode: "Markdown" }
            );
            return;
        }

        const d = res.data.data;

        // 🟦 TEXT HASIL PEMBUATAN ORDER
        const initialText = 
`✅ *Transaksi Berhasil Dibuat!*

🛒 *Produk:* ${d.product?.name || "-"}
🏷️ Brand: ${d.product?.brand || "-"}
🧩 Code: \`${d.product?.code || "-"}\`
📂 Kategori: ${d.product?.category || "-"}

🎯 *Tujuan:* ${d.tujuan}

📌 *Status Awal:* ${d.status}
🆔 *ID Transaksi:* \`${d.id}\`

⏳ *Sedang memantau status transaksi...*`;

        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            initialText,
            { parse_mode: "Markdown" }
        );

        // 🔥 AUTO CHECK STATUS TIAP 5 DETIK
        const orderId = d.id;
        await monitorH2HOrder(ctx, loadingMsg.message_id, orderId);

    } catch (err) {
        console.error("ORDER H2H ERROR:", err);
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Terjadi kesalahan saat memproses transaksi.`,
            { parse_mode: "Markdown" }
        );
    }
}));

// 💰 /cairkan — Pencairan Otomatis ke E-wallet
bot.command('cairkan', createBulletproofHandler('CAIRKAN', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.reply("🚫 *Akses ditolak!*\nHanya owner yang dapat menggunakan perintah ini.", {
            parse_mode: "Markdown"
        });
        return;
    }

    const args = ctx.message.text.split(' ').slice(1);
    const code = args[0];
    const target = args[1];

    // ❗ Jika tanpa argumen → TAMPILKAN TUTORIAL
    if (!code) {
        await ctx.reply(
`❗ *Format salah!*

Gunakan perintah:
*/cairkan <nominal>*

Contoh:
\`/cairkan 2000\`
\`/cairkan 5000\`
\`/cairkan 10000\`

📌 *nominal* = nominal pencairan yang akan dilakukan ke e-wallet (otomatis ke nomor di config).`,
            { parse_mode: "Markdown" }
        );
        return;
    }

    const loadingMsg = await ctx.reply("⏳ *Memproses transaksi...*", {
        parse_mode: "Markdown"
    });

    try {
        let finalCode = code;
        let finalTarget = target;

        // AUTO MAP NOMINAL → CODE DARI CONFIG
        if (!isNaN(code)) {
            const nominalUser = Number(code);
            
            // ❌ VALIDASI KELIPATAN 1000
            if (nominalUser % 1000 !== 0) {
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    loadingMsg.message_id,
                    undefined,
                    `❌ Nominal *${code}* tidak valid!\nNominal harus kelipatan *1000*.\n\nContoh valid:\n• 1000\n• 2000\n• 5000\n• 10000`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            // Mapping prefix H2H sesuai layanan
            const prefixMap = {
                dana: "D",
                gopay: "GPY",
                ovo: "OVO",
                shopeepay: "SHOPE",
                linkaja: "LINK"
            };

            const ewallet = config.type_ewallet_RUMAHOTP?.toLowerCase();
            const prefix = prefixMap[ewallet];

            if (!prefix) {
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    loadingMsg.message_id,
                    undefined,
                    `❌ Prefix untuk ewallet *${config.type_ewallet_RUMAHOTP}* tidak ditemukan!`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            const productRes = await axios.get("https://www.rumahotp.com/api/v1/h2h/product", {
                headers: { "x-apikey": config.RUMAHOTP_API_KEY }
            });

            const all = productRes.data.data || [];
            const filtered = all.filter(x => x.code.startsWith(prefix));

            // Cari produk berdasarkan angka murni
            const found = filtered.find(x => {
                const angkaName = Number(String(x.name).replace(/\D/g, ""));
                const angkaNote = Number(String(x.note).replace(/\D/g, ""));
                return angkaName === nominalUser || angkaNote === nominalUser;
            });

            if (!found) {
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    loadingMsg.message_id,
                    undefined,
                    `❌ Produk dengan nominal *${code}* tidak ditemukan untuk *${config.type_ewallet_RUMAHOTP}*`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            finalCode = found.code; 
            finalTarget = config.nomor_pencairan_RUMAHOTP;
        }

        if (!finalTarget) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                "⚠️ Format salah!\nContoh:\n• /cairkan 2000\n• /cairkan D1 08123xxxx",
                { parse_mode: "Markdown" }
            );
            return;
        }

        // 🔥 CREATE TRANSAKSI
        const url = `https://www.rumahotp.com/api/v1/h2h/transaksi/create?id=${finalCode}&target=${finalTarget}`;
        const res = await axios.get(url, {
            headers: {
                "x-apikey": config.RUMAHOTP_API_KEY,
                "Accept": "application/json"
            }
        });

        if (!res.data.success) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                `❌ *Transaksi gagal!*\nPesan: ${res.data.message || "Tidak diketahui."}`,
                { parse_mode: "Markdown" }
            );
            return;
        }

        const d = res.data.data;

        const initialText =
`✅ *Transaksi Berhasil Dibuat!*

🛒 *Produk:* ${d.product?.name || "-"}
🏷️ Brand: ${d.product?.brand || "-"}
🧩 Code: \`${d.product?.code || "-"}\`
📂 Kategori: ${d.product?.category || "-"}

🎯 *Tujuan:* ${d.tujuan}

📌 *Status Awal:* ${d.status}
🆔 *ID Transaksi:* \`${d.id}\`

⏳ *Sedang memantau status transaksi...*`;

        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            initialText,
            { parse_mode: "Markdown" }
        );

        // 🔥 AUTO CHECK STATUS
        await monitorH2HOrder(ctx, loadingMsg.message_id, d.id);

    } catch (err) {
        console.error("CAIRKAN ERROR:", err);
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Terjadi kesalahan saat memproses transaksi.`,
            { parse_mode: "Markdown" }
        );
    }
}));

// ==================== OWNER MENU COMMAND ====================

bot.command('ownermenu', createBulletproofHandler('OWNERMENU_COMMAND', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.reply('❌ Anda bukan admin!');
        return;
    }

    const totalUsers = await safeDbOperation(() => db.getAllUsers().length, 'GET_TOTAL_USERS');
    const totalOrders = await safeDbOperation(() => db.getAllUsers().reduce((sum, user) => sum + user.totalOrders, 0), 'GET_TOTAL_ORDERS');
    const totalDeposit = await safeDbOperation(() => db.getAllUsers().reduce((sum, user) => sum + user.totalDeposit, 0), 'GET_TOTAL_DEPOSIT');
    const activeOrders = await safeDbOperation(() => db.getActiveOrders().length, 'GET_ACTIVE_ORDERS');
    const currentDepositMethod = utils.getDepositMethod();
    const currentProfitPercentage = db.load().settings.profitPercentage || config.PROFIT_PERCENTAGE;
    const settings = db.getSettings();

    const ownerMenuText = `👑 *OWNER MENU - Andin Official*\n\n` +
                         `📊 *STATISTIK BOT:*\n` +
                         `👥 Total User: ${totalUsers}\n` +
                         `📦 Total Order: ${totalOrders}\n` +
                         `💳 Total Deposit: ${totalDeposit}\n` +
                         `🔄 Active Orders: ${activeOrders}\n` +
                         `🔧 Deposit Method: ${currentDepositMethod.toUpperCase()}\n` +
                         `💰 Profit Percentage: ${currentProfitPercentage}%\n` +
                         `⚙️ Maintenance: ${settings.maintenance ? 'ON' : 'OFF'}\n` +
                         `📦 Auto Backup: ${settings.backup?.auto ? 'ON' : 'OFF'}\n\n` +
                         `⚙️ *FITUR ADMIN:*`;

    // Di dalam bot.action('ownermenu') - tambahkan di keyboard array:
const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📢 BROADCAST', 'owner_broadcast')],
    [Markup.button.callback('📊 STATISTIK DETAIL', 'owner_stats')],
    [Markup.button.callback('🛒 H2H PRODUCTS', 'owner_h2h_products')],
    [Markup.button.callback('💳 H2H ORDER', 'owner_h2h_order')],
    [Markup.button.callback('💰 CAIRKAN SALDO', 'owner_cairkan')],
    // TAMBAH INI ↑
    [Markup.button.callback('💰 SET HARGA', 'owner_set_price')],
    [Markup.button.callback('💰 SET HARGA', 'owner_set_price')],
    [Markup.button.callback('🔧 SET DEPOSIT METHOD', 'owner_set_deposit_method')],
    [Markup.button.callback('👥 LIST USER', 'owner_list_users')],
    [Markup.button.callback('⚙️ SETTING BACKUP', 'owner_backup_settings')],
    [Markup.button.callback('🔧 MAINTENANCE', 'owner_maintenance')],
    [Markup.button.callback('🎯 REFERRAL SETTINGS', 'owner_referral_settings')],
    [Markup.button.callback('🎫 BUAT VOUCHER', 'owner_create_voucher')],
    [Markup.button.callback('🚨 AUTO TOP-UP ALERT', 'owner_auto_topup_settings')],
    [Markup.button.callback('💰 PRICE DROP ALERT', 'owner_price_drop_settings')], // TAMBAH INI
    [Markup.button.callback('🤖 AI SETTINGS', 'owner_ai_settings')],
    [Markup.button.callback('🔙 MENU UTAMA', 'main_menu')]
]);

    await ctx.reply(ownerMenuText, {
        parse_mode: 'Markdown',
        reply_markup: keyboard.reply_markup
    });
}));

// ==================== H2H OWNER MENU CALLBACK HANDLERS ====================

// Handler untuk H2H Products - Langsung tampilkan daftar produk populer
bot.action('owner_h2h_products', createBulletproofHandler('OWNER_H2H_PRODUCTS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('🛒 *Mengambil daftar produk populer...*', { 
        parse_mode: 'Markdown' 
    });
    
    try {
        // Ambil data produk dari API
        const res = await axios.get("https://www.rumahotp.com/api/v1/h2h/product", {
            headers: { "x-apikey": config.RUMAHOTP_API_KEY }
        });

        let products = res.data.data || [];
        
        // Urutkan harga termurah
        products = products.sort((a, b) => a.price - b.price);
        
        // Kategorikan produk
        const categories = {
            pulsa: products.filter(p => p.category.toLowerCase().includes('pulsa') || p.name.toLowerCase().includes('pulsa')),
            data: products.filter(p => p.category.toLowerCase().includes('data') || p.name.toLowerCase().includes('data')),
            game: products.filter(p => p.category.toLowerCase().includes('game') || p.name.toLowerCase().includes('game')),
            emoney: products.filter(p => p.category.toLowerCase().includes('e-money') || p.category.toLowerCase().includes('ewallet') || p.name.toLowerCase().includes('dana') || p.name.toLowerCase().includes('gopay') || p.name.toLowerCase().includes('ovo')),
            pln: products.filter(p => p.name.toLowerCase().includes('pln') || p.category.toLowerCase().includes('pln')),
            voucher: products.filter(p => p.category.toLowerCase().includes('voucher'))
        };

        await ctx.deleteMessage(loadingMsg.message_id);

        // Tampilkan menu kategori
        await ctx.reply(
            `🛒 *H2H PRODUCTS - PILIH KATEGORI*\n\n` +
            `📊 Total Produk: ${products.length}\n` +
            `💰 Harga mulai dari: Rp${products[0]?.price?.toLocaleString('id-ID') || '0'}\n\n` +
            `Pilih kategori produk:`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [
                        Markup.button.callback(`📱 Pulsa (${categories.pulsa.length})`, 'h2h_category_pulsa'),
                        Markup.button.callback(`📶 Data (${categories.data.length})`, 'h2h_category_data')
                    ],
                    [
                        Markup.button.callback(`🎮 Game (${categories.game.length})`, 'h2h_category_game'),
                        Markup.button.callback(`💳 E-Money (${categories.emoney.length})`, 'h2h_category_emoney')
                    ],
                    [
                        Markup.button.callback(`⚡ PLN (${categories.pln.length})`, 'h2h_category_pln'),
                        Markup.button.callback(`🎫 Voucher (${categories.voucher.length})`, 'h2h_category_voucher')
                    ],
                    [
                        Markup.button.callback('🔍 Cari Manual', 'h2h_search_manual'),
                        Markup.button.callback('📋 Semua Produk', 'h2h_all_products')
                    ],
                    [
                        Markup.button.callback('🔙 Owner Menu', 'ownermenu_back')
                    ]
                ]).reply_markup
            }
        );

        // Simpan data produk untuk callback selanjutnya
        global.h2hProducts = products;
        global.h2hCategories = categories;

    } catch (error) {
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ *Gagal mengambil data produk!*\n\nError: ${error.message}`,
            { parse_mode: 'Markdown' }
        );
    }
}));

// Handler untuk kategori produk
bot.action(/h2h_category_(.+)/, createBulletproofHandler('H2H_CATEGORY', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const category = ctx.match[1];
    const categoryNames = {
        'pulsa': 'Pulsa & Telpon',
        'data': 'Paket Data',
        'game': 'Game Voucher',
        'emoney': 'E-Money',
        'pln': 'Listrik PLN',
        'voucher': 'Voucher Lainnya'
    };

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    const products = global.h2hCategories?.[category] || [];
    
    if (products.length === 0) {
        await ctx.reply(
            `❌ *Tidak ada produk dalam kategori ${categoryNames[category]}*`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_h2h_products')]
                ]).reply_markup
            }
        );
        return;
    }

    // Tampilkan 5 produk pertama dengan pagination
    const pageSize = 5;
    const totalPages = Math.ceil(products.length / pageSize);
    const currentPage = 1;
    const currentProducts = products.slice(0, pageSize);

    let message = `📦 *${categoryNames[category]}*\n\n`;
    message += `📊 Total: ${products.length} produk\n`;
    message += `📄 Halaman: ${currentPage}/${totalPages}\n\n`;

    currentProducts.forEach((product, index) => {
        message += `💠 *${product.name}*\n`;
        message += `🧩 Kode: \`${product.code}\`\n`;
        message += `🏷️ Brand: ${product.brand}\n`;
        message += `💰 Harga: Rp${product.price.toLocaleString('id-ID')}\n`;
        message += `📝 ${product.note || 'Tidak ada keterangan'}\n`;
        message += `🔹 [ORDER](${`/orderh2h ${product.code} NOMOR_TUJUAN`})\n\n`;
    });

    const keyboard = [];
    
    // Tombol order cepat untuk produk pertama
    if (currentProducts.length > 0) {
        keyboard.push([
            Markup.button.callback('🚀 Order Cepat', `h2h_quick_order_${currentProducts[0].code}`)
        ]);
    }

    // Tombol pagination
    const navButtons = [];
    if (totalPages > 1) {
        if (currentPage > 1) {
            navButtons.push(Markup.button.callback('⬅️ Sebelumnya', `h2h_category_${category}_page_${currentPage - 1}`));
        }
        if (currentPage < totalPages) {
            navButtons.push(Markup.button.callback('Selanjutnya ➡️', `h2h_category_${category}_page_${currentPage + 1}`));
        }
        if (navButtons.length > 0) {
            keyboard.push(navButtons);
        }
    }

    keyboard.push([
        Markup.button.callback('🔍 Cari Produk Lain', 'owner_h2h_products'),
        Markup.button.callback('🔙 Kategori', 'owner_h2h_products')
    ]);

    await ctx.reply(message, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard(keyboard).reply_markup,
        disable_web_page_preview: true
    });

    // Simpan state untuk pagination
    global.h2hCurrentCategory = {
        category: category,
        products: products,
        pageSize: pageSize,
        totalPages: totalPages
    };
}));

// Handler untuk order cepat
bot.action(/h2h_quick_order_(.+)/, createBulletproofHandler('H2H_QUICK_ORDER', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const productCode = ctx.match[1];
    await ctx.answerCbQuery(`🚀 Memulai order ${productCode}...`);
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    await ctx.reply(
        `🚀 *ORDER CEPAT - ${productCode}*\n\n` +
        `Masukkan nomor tujuan untuk produk ini:\n\n` +
        `📋 *Contoh:*\n` +
        `• 081234567890\n` +
        `• 628123456789\n` +
        `• 123456789012\n\n` +
        `Ketik nomor tujuan langsung di chat:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Batalkan', 'owner_h2h_products')]
            ]).reply_markup
        }
    );

    // Simpan product code untuk proses selanjutnya
    activeSessions.lastCallback[ctx.from.id] = `quick_order_${productCode}`;
}));

// Handler untuk pagination kategori (FIXED)
bot.action(/h2h_category_(.+)_page_(\d+)/, createBulletproofHandler('H2H_CATEGORY_PAGE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const category = ctx.match[1];
    const page = parseInt(ctx.match[2]);
    
    await ctx.answerCbQuery();
    
    const categoryData = global.h2hCurrentCategory;
    if (!categoryData || categoryData.category !== category) {
        await ctx.reply('❌ Data kategori tidak ditemukan!');
        return;
    }

    const products = categoryData.products;
    const pageSize = categoryData.pageSize;
    const totalPages = categoryData.totalPages;
    
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const currentProducts = products.slice(startIndex, endIndex);

    if (currentProducts.length === 0) {
        await ctx.reply('❌ Tidak ada produk di halaman ini!');
        return;
    }

    const categoryNames = {
        'pulsa': 'Pulsa & Telpon',
        'data': 'Paket Data', 
        'game': 'Game Voucher',
        'emoney': 'E-Money',
        'pln': 'Listrik PLN',
        'voucher': 'Voucher Lainnya'
    };

    let message = `📦 *${categoryNames[category]}*\n\n`;
    message += `📊 Total: ${products.length} produk\n`;
    message += `📄 Halaman: ${page}/${totalPages}\n\n`;

    currentProducts.forEach((product, index) => {
        message += `💠 *${product.name}*\n`;
        message += `🧩 Kode: \`${product.code}\`\n`;
        message += `🏷️ Brand: ${product.brand}\n`;
        message += `💰 Harga: Rp${product.price.toLocaleString('id-ID')}\n`;
        message += `📝 ${product.note || 'Tidak ada keterangan'}\n`;
        message += `🔹 Order: /orderh2h ${product.code} NOMOR_TUJUAN\n\n`;
    });

    const keyboard = [];
    
    // Tombol order cepat untuk produk pertama di halaman
    if (currentProducts.length > 0) {
        keyboard.push([
            Markup.button.callback('🚀 Order Cepat', `h2h_quick_order_${currentProducts[0].code}`)
        ]);
    }

    // Tombol pagination
    const navButtons = [];
    if (page > 1) {
        navButtons.push(Markup.button.callback('⬅️ Sebelumnya', `h2h_category_${category}_page_${page - 1}`));
    }
    navButtons.push(Markup.button.callback(`📄 ${page}/${totalPages}`, `h2h_category_info`));
    if (page < totalPages) {
        navButtons.push(Markup.button.callback('Selanjutnya ➡️', `h2h_category_${category}_page_${page + 1}`));
    }
    
    if (navButtons.length > 0) {
        keyboard.push(navButtons);
    }

    keyboard.push([
        Markup.button.callback('🔍 Cari Produk Lain', 'owner_h2h_products'),
        Markup.button.callback('🔙 Kategori', 'owner_h2h_products')
    ]);

    try {
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard).reply_markup,
            disable_web_page_preview: true
        });
    } catch (error) {
        await ctx.reply(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard).reply_markup,
            disable_web_page_preview: true
        });
    }
}));

// Handler untuk pencarian manual
bot.action('h2h_search_manual', createBulletproofHandler('H2H_SEARCH_MANUAL', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    await ctx.reply(
        `🔍 *PENCARIAN PRODUK MANUAL*\n\n` +
        `Silakan ketik nama produk yang ingin dicari:\n\n` +
        `📋 *Contoh:*\n` +
        `• pulsa telkomsel\n` +
        `• dana 5000\n` +
        `• free fire\n` +
        `• pln 20k\n\n` +
        `Ketik langsung di chat:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_h2h_products')]
            ]).reply_markup
        }
    );

    // Set callback untuk menangani input pencarian
    activeSessions.lastCallback[ctx.from.id] = 'h2h_search_products';
}));

// Handler untuk semua produk
bot.action('h2h_all_products', createBulletproofHandler('H2H_ALL_PRODUCTS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    await ctx.reply(
        `📋 *SEMUA PRODUK H2H*\n\n` +
        `Gunakan perintah:\n\n` +
        `\`/listh2h <kata kunci>\`\n\n` +
        `📝 *Contoh:*\n` +
        `• /listh2h pulsa\n` +
        `• /listh2h dana\n` +
        `• /listh2h game\n` +
        `• /listh2h pln\n\n` +
        `Atau ketik langsung di chat untuk pencarian cepat.`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_h2h_products')]
            ]).reply_markup
        }
    );
}));

// Handler untuk Cairkan Saldo - Langsung proses tanpa input manual
bot.action('owner_cairkan', createBulletproofHandler('OWNER_CAIRKAN', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    // Ambil info e-wallet dari config
    const ewallet = config.type_ewallet_RUMAHOTP || 'DANA';
    const nomorTujuan = config.nomor_pencairan_RUMAHOTP || 'Belum diatur';

    await ctx.reply(
        `💰 *PENCAIRAN SALDO KE E-WALLET*\n\n` +
        `🏷️ *E-Wallet:* ${ewallet.toUpperCase()}\n` +
        `📱 *Nomor Tujuan:* ${nomorTujuan}\n\n` +
        `💵 *Pilih nominal yang ingin dicairkan:*\n\n` +
        `💰 *Minimal:* Rp1.000\n` +
        `🔢 *Kelipatan:* Rp1.000`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback('💰 1K', 'cairkan_now_1000'),
                    Markup.button.callback('💰 2K', 'cairkan_now_2000'), 
                    Markup.button.callback('💰 5K', 'cairkan_now_5000')
                ],
                [
                    Markup.button.callback('💰 10K', 'cairkan_now_10000'),
                    Markup.button.callback('💰 20K', 'cairkan_now_20000'),
                    Markup.button.callback('💰 50K', 'cairkan_now_50000')
                ],
                [
                    Markup.button.callback('💰 100K', 'cairkan_now_100000'),
                    Markup.button.callback('💰 200K', 'cairkan_now_200000'),
                    Markup.button.callback('💰 500K', 'cairkan_now_500000')
                ],
                [
                    Markup.button.callback('🔢 Custom', 'cairkan_custom'),
                    Markup.button.callback('🔙 Owner Menu', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk cairkan langsung (tanpa input manual)
bot.action(/cairkan_now_(\d+)/, createBulletproofHandler('CAIRKAN_NOW', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const nominal = ctx.match[1];
    await ctx.answerCbQuery(`💰 Memproses pencairan Rp${nominal}...`);
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    // Langsung proses pencairan
    await processCairkanInstant(ctx, nominal);
}));

// Handler untuk custom nominal
bot.action('cairkan_custom', createBulletproofHandler('CAIRKAN_CUSTOM', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    await ctx.reply(
        `💰 *PENCAIRAN CUSTOM*\n\n` +
        `Masukkan nominal custom yang ingin dicairkan:\n\n` +
        `📋 *Contoh:*\n` +
        `• 15000\n` +
        `• 25000\n` +
        `• 75000\n\n` +
        `💰 *Minimal:* Rp1.000\n` +
        `🔢 *Kelipatan:* Rp1.000\n\n` +
        `Ketik nominal langsung di chat:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_cairkan')]
            ]).reply_markup
        }
    );

    activeSessions.lastCallback[ctx.from.id] = 'cairkan_custom';
}));

// Handler untuk tombol cepat cairkan
bot.action(/cairkan_quick_(\d+)/, createBulletproofHandler('CAIRKAN_QUICK', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const nominal = ctx.match[1];
    await ctx.answerCbQuery(`💰 Memproses pencairan Rp${nominal}...`);
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    // Langsung proses pencairan dengan nominal yang dipilih
    await processCairkanSaldo(ctx, nominal);
}));

// Handler untuk H2H Order - Langsung minta input
bot.action('owner_h2h_order', createBulletproofHandler('OWNER_H2H_ORDER', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery();
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }

    await ctx.reply(
        `💳 *ORDER PRODUK H2H*\n\n` +
        `Silakan masukkan data order dengan format:\n\n` +
        `\`KODE_PRODUK NOMOR_TUJUAN\`\n\n` +
        `📋 *Contoh:*\n` +
        `• D1 081234567890\n` +
        `• P1 628123456789\n` +
        `• G1 123456789012\n\n` +
        `🔍 *Cara mendapatkan KODE_PRODUK:*\n` +
        `Gunakan menu "H2H Products" untuk melihat daftar kode produk\n\n` +
        `Ketik langsung di chat:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🛒 Lihat Produk', 'owner_h2h_products')],
                [Markup.button.callback('🔙 Owner Menu', 'ownermenu_back')]
            ]).reply_markup
        }
    );

    // Set callback untuk menangani input order
    activeSessions.lastCallback[ctx.from.id] = 'process_h2h_order';
}));

// Handler untuk price drop alert settings
bot.action('owner_price_drop_settings', createBulletproofHandler('OWNER_PRICE_DROP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const settings = db.getSettings();
    const priceDropSettings = settings.priceDropAlert || {
        enabled: true,
        delayBetweenAlerts: 60000,
        minDropAmount: 1000,
        minDropPercentage: 0.10,
        lastAlertSent: null
    };

    const delayInMinutes = Math.floor(priceDropSettings.delayBetweenAlerts / 60000);
    const minDropPercentageDisplay = (priceDropSettings.minDropPercentage * 100).toFixed(0);

    await ctx.editMessageText(
        `💰 *PRICE DROP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${priceDropSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Delay Antar Alert: ${delayInMinutes} menit\n` +
        `📉 Minimal Turun: Rp${utils.formatNumber(priceDropSettings.minDropAmount)} atau ${minDropPercentageDisplay}%\n` +
        `⏰ Terakhir Alert: ${priceDropSettings.lastAlertSent ? new Date(priceDropSettings.lastAlertSent).toLocaleString('id-ID') : 'Belum pernah'}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(priceDropSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_price_drop_${priceDropSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Delay', 'change_price_drop_delay'),
                    Markup.button.callback('📉 Ubah Minimum', 'change_price_drop_minimum')
                ],
                [
                    Markup.button.callback('🔄 Reset Cooldown', 'reset_price_drop_cooldown'),
                    Markup.button.callback('🔍 Test Alert', 'test_price_drop_alert')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk toggle price drop alert
bot.action(/toggle_price_drop_(on|off)/, createBulletproofHandler('TOGGLE_PRICE_DROP', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const action = ctx.match[1];
    const shouldEnable = action === 'on';
    
    const settings = db.getSettings();
    settings.priceDropAlert.enabled = shouldEnable;
    db.updateSettings(settings);

    await ctx.answerCbQuery(`✅ Price drop alert ${shouldEnable ? 'dihidupkan' : 'dimatikan'}!`);
    
    // Refresh menu
    const updatedSettings = db.getSettings();
    const priceDropSettings = updatedSettings.priceDropAlert;
    const delayInMinutes = Math.floor(priceDropSettings.delayBetweenAlerts / 60000);
    const minDropPercentageDisplay = (priceDropSettings.minDropPercentage * 100).toFixed(0);

    await ctx.editMessageText(
        `💰 *PRICE DROP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${priceDropSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Delay Antar Alert: ${delayInMinutes} menit\n` +
        `📉 Minimal Turun: Rp${utils.formatNumber(priceDropSettings.minDropAmount)} atau ${minDropPercentageDisplay}%\n` +
        `⏰ Terakhir Alert: ${priceDropSettings.lastAlertSent ? new Date(priceDropSettings.lastAlertSent).toLocaleString('id-ID') : 'Belum pernah'}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(priceDropSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_price_drop_${priceDropSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Delay', 'change_price_drop_delay'),
                    Markup.button.callback('📉 Ubah Minimum', 'change_price_drop_minimum')
                ],
                [
                    Markup.button.callback('🔄 Reset Cooldown', 'reset_price_drop_cooldown'),
                    Markup.button.callback('🔍 Test Alert', 'test_price_drop_alert')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk ubah delay
bot.action('change_price_drop_delay', createBulletproofHandler('CHANGE_PRICE_DROP_DELAY', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.editMessageText(
        `⏰ *UBAH DELAY ALERT HARGA TURUN*\n\n` +
        `Silakan kirim delay dalam menit:\n\n` +
        `Contoh: \`5\` untuk 5 menit\n` +
        `Saat ini: ${Math.floor(db.getSettings().priceDropAlert.delayBetweenAlerts / 60000)} menit\n\n` +
        `*Catatan:* Delay ini mengatur berapa lama menunggu antara alert harga turun.`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
            ]).reply_markup
        }
    );

    activeSessions.lastCallback[ctx.from.id] = 'change_price_drop_delay';
}));

// Handler untuk reset cooldown
bot.action('reset_price_drop_cooldown', createBulletproofHandler('RESET_PRICE_DROP_COOLDOWN', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    priceAlertManager.resetCooldown();
    await ctx.answerCbQuery('✅ Cooldown alert harga turun direset!');
    
    // Refresh menu
    const settings = db.getSettings();
    const priceDropSettings = settings.priceDropAlert;
    const delayInMinutes = Math.floor(priceDropSettings.delayBetweenAlerts / 60000);
    const minDropPercentageDisplay = (priceDropSettings.minDropPercentage * 100).toFixed(0);

    await ctx.editMessageText(
        `💰 *PRICE DROP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${priceDropSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Delay Antar Alert: ${delayInMinutes} menit\n` +
        `📉 Minimal Turun: Rp${utils.formatNumber(priceDropSettings.minDropAmount)} atau ${minDropPercentageDisplay}%\n` +
        `⏰ Terakhir Alert: ${priceDropSettings.lastAlertSent ? new Date(priceDropSettings.lastAlertSent).toLocaleString('id-ID') : 'Belum pernah'}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(priceDropSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_price_drop_${priceDropSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Delay', 'change_price_drop_delay'),
                    Markup.button.callback('📉 Ubah Minimum', 'change_price_drop_minimum')
                ],
                [
                    Markup.button.callback('🔄 Reset Cooldown', 'reset_price_drop_cooldown'),
                    Markup.button.callback('🔍 Test Alert', 'test_price_drop_alert')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk test alert
bot.action('test_price_drop_alert', createBulletproofHandler('TEST_PRICE_DROP_ALERT', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery('🔄 Mengirim test alert...');
    
    const testMessage = 
        `🎉 *HARGA TURUN!* (TEST)\n\n` +
        `📱 *Layanan:* WhatsApp\n` +
        `🇺🇳 *Negara:* Egypt\n` +
        `💰 Harga Lama: Rp6.546\n` +
        `💰 *Harga Baru:* Rp3.906\n` +
        `📉 *Turun:* Rp2.640\n\n` +
        `⚡ *Segera pesan sebelum harga naik lagi!*`;

    try {
        await bot.telegram.sendMessage(
            config.OWNER_ID,
            testMessage,
            { parse_mode: 'Markdown' }
        );
        await ctx.answerCbQuery('✅ Test alert berhasil dikirim!', { show_alert: true });
    } catch (error) {
        await ctx.answerCbQuery('❌ Gagal mengirim test alert!', { show_alert: true });
    }
}));

// ==================== CHANNEL MEMBERSHIP CHECK HANDLER ====================
bot.action('check_membership', createBulletproofHandler('CHECK_MEMBERSHIP', async (ctx) => {
    await ctx.answerCbQuery('🔄 Mengecek keanggotaan...');
    const userId = ctx.from.id;
    const isMember = await utils.isUserInChannel(userId);
    
    if (!isMember) {
        await messageUtils.replyWithEdit(
            ctx,
            `❌ *BELUM BERGABUNG*\n\n` +
            `Kamu belum bergabung dengan channel official kami.\n` +
            `Silakan bergabung terlebih dahulu di @${config.LOG_CHANNEL.replace('@', '')}\n\n` +
            `Setelah bergabung, klik tombol "Cek Lagi" di bawah.`,
            Markup.inlineKeyboard([
                [Markup.button.url('📢 Join Channel', `https://t.me/${config.LOG_CHANNEL.replace('@', '')}`)],
                [Markup.button.callback('✅ Cek Lagi', 'check_membership')]
            ])
        );
        return;
    }
    
    await showMainMenu(ctx);
}));

// ==================== ADD SALDO COMMAND ====================

bot.command('addsaldo', createBulletproofHandler('ADDSALDO_COMMAND', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.reply('❌ Anda bukan admin!');
        return;
    }

    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
        await ctx.reply(
            '❌ *Format salah!*\n\n' +
            'Gunakan: `/addsaldo <user_id> <jumlah>`\n' +
            'Contoh: `/addsaldo 123456789 50000`',
            { parse_mode: 'Markdown' }
        );
        return;
    }

    const targetUserId = args[1];
    const amount = parseInt(args[2]);

    if (isNaN(amount) || amount <= 0) {
        await ctx.reply('❌ Jumlah saldo harus angka positif!');
        return;
    }

    const targetUser = await safeDbOperation(() => db.getUser(targetUserId), 'GET_TARGET_USER');
    if (!targetUser) {
        await ctx.reply('❌ User tidak ditemukan!');
        return;
    }

    targetUser.balance += amount;
    await safeDbOperation(() => db.updateUser(targetUserId, targetUser), 'UPDATE_TARGET_USER_BALANCE');

    try {
        await bot.telegram.sendMessage(
            targetUserId,
            `💰 *SALDO ANDA TELAH DITAMBAHKAN!*\n\n` +
            `🔄 *Oleh:* Admin\n` +
            `💵 *Jumlah:* Rp${utils.formatNumber(amount)}\n` +
            `💰 *Saldo Sekarang:* Rp${utils.formatNumber(targetUser.balance)}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `Terima kasih telah menggunakan layanan kami! 🎉`,
            { parse_mode: 'Markdown' }
        );
    } catch (error) {
        console.error('Error notifying user:', error);
    }

    await ctx.reply(
        `✅ *SALDO BERHASIL DITAMBAHKAN!*\n\n` +
        `👤 *User:* ${targetUserId}\n` +
        `💵 *Jumlah:* Rp${utils.formatNumber(amount)}\n` +
        `💰 *Saldo Baru:* Rp${utils.formatNumber(targetUser.balance)}\n` +
        `⏰ *Waktu:* ${utils.getIndonesianTime()}`,
        { parse_mode: 'Markdown' }
    );
}));

// ==================== MONITOR H2H ORDER FUNCTION ====================
async function monitorH2HOrder(ctx, messageId, orderId) {
    const maxChecks = 60; // Maksimal 5 menit (60 x 5 detik)
    let checkCount = 0;

    const interval = setInterval(async () => {
        try {
            if (checkCount >= maxChecks) {
                clearInterval(interval);
                await messageUtils.replyWithEdit(
                    ctx,
                    `❌ *Monitoring dihentikan!*\nTransaksi belum selesai setelah 5 menit.\n\n🆔 ID: \`${orderId}\``,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            checkCount++;

            const statusURL = `https://www.rumahotp.com/api/v1/h2h/transaksi/status?transaksi_id=${orderId}`;
            const statusRes = await axios.get(statusURL, {
                headers: {
                    "x-apikey": config.RUMAHOTP_API_KEY,
                    "Accept": "application/json"
                }
            });

            if (!statusRes.data.success) return;

            const statusData = statusRes.data.data;

            // Jika masih proses
            if (statusData.status === "processing") {
                await messageUtils.replyWithEdit(
                    ctx,
                    `⏳ *Transaksi Diproses...*\n\n` +
                    `🆔 ID: \`${statusData.id}\`\n` +
                    `🎯 Tujuan: ${statusData.tujuan}\n` +
                    `📦 Status: *processing*\n` +
                    `🔢 Cek ke: ${checkCount}/${maxChecks}\n\n` +
                    `⏳ Sistem sedang menunggu respon provider...`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            // Jika sukses
            if (statusData.status === "success") {
                clearInterval(interval);
                await messageUtils.replyWithEdit(
                    ctx,
                    `🎉 *TRANSAKSI BERHASIL!*\n\n` +
                    `🆔 ID: \`${statusData.id}\`\n` +
                    `🎯 Tujuan: ${statusData.tujuan}\n` +
                    `📦 Status: *SUCCESS*\n\n` +
                    `🧾 Produk: ${statusData.product?.name}\n` +
                    `🏷 Brand: ${statusData.product?.brand}\n` +
                    `💰 Harga: Rp${statusData.price?.toLocaleString("id-ID")}\n\n` +
                    `🔐 *SN:* \`${statusData.response?.sn || "-"}\`\n` +
                    `🕒 Waktu Provider: ${statusData.response?.time || "-"}\n\n` +
                    `✅ Transaksi telah selesai.`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

            // Jika gagal
            if (statusData.status === "failed" || statusData.status === "canceled") {
                clearInterval(interval);
                await messageUtils.replyWithEdit(
                    ctx,
                    `❌ *TRANSAKSI GAGAL!*\n\n` +
                    `🆔 ID: \`${statusData.id}\`\n` +
                    `🎯 Tujuan: ${statusData.tujuan}\n\n` +
                    `📦 Status: *${statusData.status.toUpperCase()}*\n` +
                    `💬 Provider Message: ${statusData.response?.status || "-"}\n\n` +
                    `🔁 Refund: ${statusData.refund ? "✔️ Iya" : "❌ Tidak"}`,
                    { parse_mode: "Markdown" }
                );
                return;
            }

        } catch (error) {
            console.log("ERROR AUTO CHECK:", error);
        }
    }, 5000); // Cek status tiap 5 detik
}

// ==================== DEPOSIT MENU ====================

async function showDepositMenu(ctx) {
    try {
        const depositText = 
            `💳 *MENU DEPOSIT*\n\n` +
            `Pilih nominal deposit atau masukkan custom:\n\n` +
            `💰 *Minimal Deposit:* Rp${utils.formatNumber(config.MIN_DEPOSIT)}\n` +
            `⚡ *Proses:* Instant dengan QRIS\n` +
            `Pilih nominal cepat:`;

        const keyboard = Markup.inlineKeyboard([
            [
                Markup.button.callback('💰 5K', 'deposit_5000'),
                Markup.button.callback('💰 10K', 'deposit_10000'),
                Markup.button.callback('💰 20K', 'deposit_20000')
            ],
            [
                Markup.button.callback('💰 50K', 'deposit_50000'),
                Markup.button.callback('💰 100K', 'deposit_100000'),
                Markup.button.callback('💰 200K', 'deposit_200000')
            ],
            [
                Markup.button.callback('🔢 CUSTOM', 'deposit_custom_btn')
            ],
            [
                Markup.button.callback('🔙 Menu Utama', 'main_menu')
            ]
        ]);

        // Gunakan editMessageText jika ini callback query, jika tidak kirim pesan baru
        if (ctx.updateType === 'callback_query') {
            await ctx.editMessageText(depositText, {
                parse_mode: 'Markdown',
                reply_markup: keyboard.reply_markup
            });
        } else {
            await ctx.reply(depositText, {
                parse_mode: 'Markdown',
                reply_markup: keyboard.reply_markup
            });
        }
        
    } catch (error) {
        console.error('❌ Error in showDepositMenu:', error.message);
        throw error; // Lempar error ke handler utama
    }
}

// ==================== H2H PAGINATION CALLBACKS ====================

// Handler untuk next/prev H2H
bot.action(/h2h_(next|prev)_(\d+)/, createBulletproofHandler('H2H_PAGINATION', async (ctx) => {
    const action = ctx.match[1];
    let page = parseInt(ctx.match[2]);
    
    if (action === 'next') {
        page += 1;
    } else if (action === 'prev') {
        page -= 1;
    }

    await ctx.answerCbQuery();
    sendH2HPage(bot, ctx.chat.id, page, ctx.callbackQuery.message.message_id);
}));

// Handler untuk deposit custom dengan animasi loading berputar
bot.action('deposit_custom_btn', createBulletproofHandler('DEPOSIT_CUSTOM_BTN', async (ctx) => {
    await ctx.answerCbQuery();
    
    if (lockUtils.isUserLocked(ctx.from.id)) {
        await ctx.answerCbQuery('⚠️ Anda sedang memiliki transaksi aktif. Selesaikan dulu.', { show_alert: true });
        return;
    }
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('🔢 *Membuka menu custom...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "🔢 Membuka menu custom [▰▱▱▱▱]",
        "💰 Menyiapkan input [▰▰▱▱▱]", 
        "📝 Konfigurasi sistem [▰▰▰▱▱]",
        "💳 Loading form [▰▰▰▰▱]",
        "✅ Siap digunakan [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 500);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        
        await ctx.reply(
            `🔢 *DEPOSIT CUSTOM*\n\n` +
            `Silakan kirim nominal deposit yang diinginkan:\n\n` +
            `💡 Contoh: \`5000\` untuk deposit Rp5,000\n` +
            `💰 Minimal: Rp${utils.formatNumber(config.MIN_DEPOSIT)}\n\n` +
            `Ketik nominal dan kirim pesan:`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
                ]).reply_markup
            }
        );
        activeSessions.lastCallback[ctx.from.id] = 'deposit_custom';
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                '❌ *Gagal membuka menu custom.*',
                { parse_mode: 'Markdown' }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// Handler untuk nominal deposit dengan animasi loading berputar
bot.action(/deposit_(\d+)/, createBulletproofHandler('DEPOSIT_NOMINAL', async (ctx) => {
    await ctx.answerCbQuery();
    
    if (lockUtils.isUserLocked(ctx.from.id)) {
        await ctx.answerCbQuery('⚠️ Anda sedang memiliki transaksi aktif. Selesaikan dulu.', { show_alert: true });
        return;
    }
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const nominal = parseInt(ctx.match[1]);
    const loadingMsg = await ctx.reply('💳 *Mempersiapkan deposit...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "💳 Mempersiapkan deposit [▰▱▱▱▱]",
        "💰 Verifikasi nominal [▰▰▱▱▱]", 
        "🔗 Menghubungi payment [▰▰▰▱▱]",
        "📊 Membuat transaksi [▰▰▰▰▱]",
        "✅ Siap digunakan [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 500);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        await processDeposit(ctx, nominal);
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                '❌ *Gagal memproses deposit.*',
                { parse_mode: 'Markdown' }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// ==================== ENHANCED DEPOSIT PROCESS WITH COUNTDOWN ====================

async function processDeposit(ctx, nominal) {
    const userId = ctx.from.id;
    
    if (!lockUtils.acquireUserLock(userId)) {
        await ctx.reply(
            `⚠️ *TRANSAKSI SEDANG BERLANGSUNG*\n\n` +
            `Anda sudah memiliki transaksi aktif.\n` +
            `Silakan selesaikan transaksi sebelumnya terlebih dahulu.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔄 Cek Status', 'check_balance')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
        return;
    }

    const loadingMsg = await ctx.reply('🔄 *Memproses deposit...*', {
        parse_mode: 'Markdown'
    });

    try {
        const reffId = utils.generateReffId();
        const depositMethod = utils.getDepositMethod();
        
        let depositResult;
        
        if (depositMethod === 'atlantic') {
            depositResult = await api.atlantich2h.createDeposit(reffId, nominal);
        } else {
            depositResult = await api.rumahotp.createDeposit(reffId, nominal);
        }

        if (!depositResult || !depositResult.success) {
            const errorMsg = depositResult?.message || 'Unknown error';
            lockUtils.releaseUserLock(userId);
            await ctx.reply(
                `❌ *Gagal membuat permintaan deposit.*\n\nError: ${errorMsg}\n\nSilakan coba lagi beberapa saat.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
                    ]).reply_markup
                }
            );
            return;
        }

        const trxData = depositResult.data;
        const adminFee = depositResult.adminFee || 0;
        const totalAmount = depositResult.totalAmount || nominal;
        
        let qrImage;
        try {
            const qrString = trxData.qr_string || trxData.qr || trxData.qr_image;
            if (qrString) {
                qrImage = await QRCode.toBuffer(qrString, {
                    width: 300,
                    height: 300,
                    margin: 2,
                    color: {
                        dark: '#000000',
                        light: '#FFFFFF'
                    }
                });
            }
        } catch (error) {
            console.error('Error generating QR code:', error);
            qrImage = null;
        }

        const trxId = await safeDbOperation(() => db.addTransaction({
            userId: ctx.from.id,
            type: 'deposit',
            amount: nominal,
            adminFee: adminFee,
            totalAmount: totalAmount,
            status: 'pending',
            reffId: reffId,
            trxId: trxData.id || reffId,
            method: depositMethod,
            createdAt: Date.now()
        }), 'ADD_DEPOSIT_TRANSACTION');

        const session = {
            ctx: ctx,
            nominal: nominal,
            adminFee: adminFee,
            totalAmount: totalAmount,
            userId: ctx.from.id,
            reffId: reffId,
            method: depositMethod,
            startTime: Date.now(),
            depositId: trxData.id,
            trxId: trxData.id || reffId
        };

        activeSessions.deposits[trxData.id || reffId] = session;

        const caption = 
            `💳 *DETAIL PEMBAYARAN*\n\n` +
            `💵 *Nominal:* Rp${utils.formatNumber(nominal)}\n` +
            `📦 *Biaya Admin:* Rp${utils.formatNumber(adminFee)}\n` +
            `💠 *Total Bayar:* Rp${utils.formatNumber(totalAmount)}\n` +
            `📊 *Status:* ${trxData.status?.toUpperCase() || 'PENDING'}\n` +
            `🆔 *Ref ID:* ${reffId}\n` +
            `📲 *Scan QR Code di bawah ini:*\n` +
            `⏰ *Kadaluarsa dalam:* 10:00\n` +
            `⏳ *Bisa dibatalkan dalam 10 menit*\n\n` +
            `🔄 *Status akan diperiksa otomatis*`;

        try {
            await ctx.deleteMessage(loadingMsg.message_id);
        } catch (deleteError) {
            console.log('⚠️ Cannot delete loading message, continuing...');
        }

        if (qrImage) {
            const sentMsg = await ctx.replyWithPhoto(
                { source: qrImage },
                {
                    caption: caption,
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [
                            Markup.button.callback('🔄 Cek Status', `check_deposit_${trxData.id || reffId}`),
                            Markup.button.callback('❌ Batalkan', `cancel_deposit_${trxData.id || reffId}`)
                        ],
                        [Markup.button.callback('🔙 Menu', 'main_menu')]
                    ]).reply_markup
                }
            );
            session.messageId = sentMsg.message_id;
        } else {
            const sentMsg = await ctx.reply(
                caption,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [
                            Markup.button.callback('🔄 Cek Status', `check_deposit_${trxData.id || reffId}`),
                            Markup.button.callback('❌ Batalkan', `cancel_deposit_${trxData.id || reffId}`)
                        ],
                        [Markup.button.callback('🔙 Menu', 'main_menu')]
                    ]).reply_markup
                }
            );
            session.messageId = sentMsg.message_id;
        }

        // Start countdown
        depositCountdownUtils.setupDepositCountdown(trxData.id || reffId, session, ctx);
        monitorDepositStatus(trxData.id || reffId);

    } catch (error) {
        console.error('❌ ERROR PROCESS DEPOSIT:', error);
        lockUtils.releaseUserLock(userId);
        try {
            await ctx.deleteMessage(loadingMsg.message_id);
        } catch (deleteError) {}
        await ctx.reply(
            `❌ *TERJADI KESALAHAN SAAT MEMPROSES DEPOSIT*\n\n` +
            `Error: ${error.message}\n\n` +
            `Silakan coba lagi beberapa saat.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
                ]).reply_markup
            }
        );
    }
}

// Handler untuk cancel deposit dengan animasi loading berputar
bot.action(/cancel_deposit_(.+)/, createBulletproofHandler('CANCEL_DEPOSIT', async (ctx) => {
    await ctx.answerCbQuery();
    const trxId = ctx.match[1];
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('🔄 *Memproses pembatalan...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "🔄 Memproses pembatalan [▰▱▱▱▱]",
        "❌ Verifikasi transaksi [▰▰▱▱▱]", 
        "💳 Menghubungi payment [▰▰▰▱▱]",
        "📊 Memproses pembatalan [▰▰▰▰▱]",
        "✅ Siap menampilkan [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 500);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        
        const session = activeSessions.deposits[trxId];
        if (!session) {
            await ctx.reply('❌ Transaksi tidak ditemukan atau sudah selesai.');
            return;
        }

        if (!utils.canCancelDeposit(session.startTime)) {
            const minutesPassed = Math.floor((Date.now() - session.startTime) / (60 * 1000));
            await ctx.reply(
                `❌ *TIDAK BISA MEMBATALKAN DEPOSIT*\n\n` +
                `Deposit sudah berjalan ${minutesPassed} menit.\n` +
                `Pembatalan hanya bisa dilakukan dalam 10 menit pertama.`,
                { parse_mode: 'Markdown' }
            );
            return;
        }

        let cancelResult;
        if (session.method === 'atlantic') {
            cancelResult = await api.atlantich2h.cancelDeposit(trxId);
        } else {
            cancelResult = await api.rumahotp.cancelDeposit(session.depositId || trxId);
        }

        if (cancelResult && cancelResult.success) {
            await safeDbOperation(() => db.updateTransactionStatus(trxId, 'canceled'), 'UPDATE_TRANSACTION_STATUS');
            delete activeSessions.deposits[trxId];
            lockUtils.releaseUserLock(session.userId);
            depositCountdownUtils.cancelDepositCountdown(trxId);
            
            await ctx.reply(
                `✅ *DEPOSIT BERHASIL DIBATALKAN*\n\n` +
                `🆔 *Ref ID:* ${session.reffId}\n` +
                `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
                `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
                `Deposit telah dibatalkan. QR Code tidak lagi valid.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('💳 Deposit Lagi', 'deposit_menu')],
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
            
            await notifyOwnerDepositCanceled(session, ctx.from);
            
        } else {
            const errorMsg = cancelResult?.message || 'Unknown error';
            await ctx.reply(
                `❌ *GAGAL MEMBATALKAN DEPOSIT*\n\n` +
                `Error: ${errorMsg}\n\n` +
                `Silakan tunggu sistem otomatis atau hubungi admin.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
        }
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                '❌ *Gagal memproses pembatalan.*',
                { parse_mode: 'Markdown' }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// ==================== NOTIFICATION FUNCTIONS ====================

async function notifyOwnerDepositSuccess(session, user) {
    try {
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const fullName = [user.first_name, user.last_name].filter(Boolean).join(' ') || 'Unknown';
        
        const message = 
            `💰 *DEPOSIT BERHASIL - NOTIFIKASI OWNER*\n\n` +
            `👤 *User ID:* ${user.id}\n` +
            `📧 *Username:* ${username}\n` +
            `👤 *Nama:* ${fullName}\n` +
            `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
            `📦 *Biaya Admin:* Rp${utils.formatNumber(session.adminFee)}\n` +
            `💠 *Total Bayar:* Rp${utils.formatNumber(session.totalAmount)}\n` +
            `🆔 *Ref ID:* ${session.reffId}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `✅ *Status:* Deposit berhasil dan saldo telah ditambahkan`;

        await bot.telegram.sendMessage(
            config.CHANNEL_ID,
            message,
            { parse_mode: 'Markdown' }
        );
        
    } catch (error) {
        console.error('❌ Error sending deposit success notification to owner:', error);
    }
}

async function notifyOwnerDepositCanceled(session, user) {
    try {
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const fullName = [user.first_name, user.last_name].filter(Boolean).join(' ') || 'Unknown';
        
        const message = 
            `❌ *DEPOSIT DIBATALKAN*\n\n` +
            `👤 *User ID:* ${user.id}\n` +
            `📧 *Username:* ${username}\n` +
            `👤 *Nama:* ${fullName}\n` +
            `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
            `🆔 *Ref ID:* ${session.reffId}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `📊 *Status:* Deposit dibatalkan oleh user`;

        await bot.telegram.sendMessage(
            config.CHANNEL_ID,
            message,
            { parse_mode: 'Markdown' }
        );
        
    } catch (error) {
        console.error('❌ Error sending deposit cancel notification to owner:', error);
    }
}

// ==================== FIXED SERVICES MENU FUNCTION ====================
async function showServicesMenu(ctx) {
    try {
        // Tampilkan pesan loading sederhana
        await messageUtils.replyWithEdit(
            ctx,
            '📱 *Mengambil daftar layanan...*',
            Markup.inlineKeyboard([]) // Keyboard kosong
        );

        const services = await api.rumahotp.getServices();
        
        if (!services || !services.success) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *Gagal mengambil daftar layanan. Silakan coba lagi.*',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔄 Coba Lagi', 'order_nokos')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            return;
        }

        activeSessions.services[ctx.from.id] = services.data;
        await showServicesPage(ctx, 0);
        
    } catch (error) {
        console.error('Error loading services:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Terjadi kesalahan saat memuat layanan.*\n\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Coba Lagi', 'order_nokos')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// ==================== FIXED SERVICES PAGINATION HANDLER ====================
bot.action(/services_page_(\d+)/, createBulletproofHandler('SERVICES_PAGE', async (ctx) => {
    await ctx.answerCbQuery();
    const page = parseInt(ctx.match[1]);
    
    // Langsung tampilkan halaman tanpa loading
    await showServicesPage(ctx, page);
}));

// ==================== FIXED SERVICES PAGE FUNCTION ====================
async function showServicesPage(ctx, page) {
    try {
        const services = activeSessions.services[ctx.from.id];
        if (!services || services.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *Tidak ada layanan yang tersedia.*\nSilakan coba lagi.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔄 Coba Lagi', 'order_nokos')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            return;
        }

        const servicesPerPage = 12;
        const totalPages = Math.ceil(services.length / servicesPerPage);
        const startIndex = page * servicesPerPage;
        const endIndex = startIndex + servicesPerPage;
        const currentServices = services.slice(startIndex, endIndex);

        let keyboard = [];
        
        for (let i = 0; i < currentServices.length; i += 2) {
            const row = [];
            if (currentServices[i]) {
                row.push(Markup.button.callback(
                    `📱 ${formatServiceName(currentServices[i].service_name)}`,
                    `service_${currentServices[i].service_code}`
                ));
            }
            if (currentServices[i + 1]) {
                row.push(Markup.button.callback(
                    `📱 ${formatServiceName(currentServices[i + 1].service_name)}`,
                    `service_${currentServices[i + 1].service_code}`
                ));
            }
            keyboard.push(row);
        }

        const navRow = [];
        if (page > 0) {
            navRow.push(Markup.button.callback('⬅️ Sebelumnya', `services_page_${page - 1}`));
        }
        navRow.push(Markup.button.callback('🔙 Menu', 'main_menu'));
        if (page < totalPages - 1) {
            navRow.push(Markup.button.callback('Selanjutnya ➡️', `services_page_${page + 1}`));
        }
        if (navRow.length > 0) {
            keyboard.push(navRow);
        }

        const messageText = `📱 *PILIH LAYANAN*\n\nSilakan pilih layanan yang diinginkan:\nHalaman ${page + 1} dari ${totalPages}`;

        await messageUtils.replyWithEdit(
            ctx,
            messageText,
            Markup.inlineKeyboard(keyboard)
        );
        
    } catch (error) {
        console.error('Error showing services page:', error);
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Terjadi kesalahan saat menampilkan layanan.*\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Coba Lagi', 'order_nokos')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// Handle service selection dengan animasi loading berputar - FIXED VERSION
// ==================== FIXED SERVICE SELECT HANDLER ====================
bot.action(/service_(\d+)/, createBulletproofHandler('SERVICE_SELECT', async (ctx) => {
    await ctx.answerCbQuery();
    const serviceId = ctx.match[1];
    
    try {
        await messageUtils.replyWithEdit(
            ctx,
            '🔄 *Mengambil daftar harga...*',
            Markup.inlineKeyboard([])
        );

        const services = activeSessions.services[ctx.from.id];
        const service = services.find(s => s.service_code.toString() === serviceId);
        
        if (!service) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ Layanan tidak ditemukan.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'order_nokos')]
                ])
            );
            return;
        }

        const countries = await api.rumahotp.getCountries(serviceId);
        
        if (!countries || !countries.success || !countries.data || countries.data.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *Tidak ada negara yang tersedia untuk layanan ini.*\nSilakan pilih layanan lain.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'order_nokos')]
                ])
            );
            return;
        }

        activeSessions.countries[ctx.from.id] = {
            service: service,
            countries: countries.data
        };

        await showCountriesPage(ctx, 0);
        
    } catch (error) {
        console.error('❌ Error in SERVICE_SELECT:', error.message);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Gagal mengambil daftar harga.*',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'order_nokos')]
            ])
        );
    }
}));

// ==================== FIXED COUNTRIES PAGINATION ====================
async function showCountriesPage(ctx, page) {
    try {
        const session = activeSessions.countries[ctx.from.id];
        if (!session) {
            await ctx.reply('❌ Session tidak ditemukan. Silakan mulai dari menu utama.');
            return;
        }

        const countries = session.countries;
        const service = session.service;
        
        if (!countries || countries.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *Tidak ada negara yang tersedia.*\nSilakan pilih layanan lain.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'order_nokos')]
                ])
            );
            return;
        }

        const countriesPerPage = 8;
        const totalPages = Math.ceil(countries.length / countriesPerPage);
        const startIndex = page * countriesPerPage;
        const endIndex = startIndex + countriesPerPage;
        const currentCountries = countries.slice(startIndex, endIndex);

        let keyboard = [];
        
        currentCountries.forEach(country => {
            if (country.pricelist && country.pricelist.length > 0) {
                const lowestPrice = Math.min(...country.pricelist.map(p => p.price));
                const finalPrice = utils.calculatePrice(lowestPrice);
                
                keyboard.push([
                    Markup.button.callback(
                        `🇺🇳 ${country.name} - Rp${utils.formatNumber(finalPrice)}`,
                        `country_${country.number_id}`
                    )
                ]);
            }
        });

        const navRow = [];
        if (page > 0) {
            navRow.push(Markup.button.callback('⬅️ Sebelumnya', `countries_page_${page - 1}`));
        }
        
        // Tombol untuk kembali ke pilih layanan
        navRow.push(Markup.button.callback('🔙 Layanan', `service_${service.service_code}`));
        
        if (page < totalPages - 1) {
            navRow.push(Markup.button.callback('Selanjutnya ➡️', `countries_page_${page + 1}`));
        }
        
        if (navRow.length > 0) {
            keyboard.push(navRow);
        }

        const messageText = `🇺🇳 *PILIH NEGARA - ${service.service_name}*\n\n` +
                          `Silakan pilih negara:\nHalaman ${page + 1} dari ${totalPages}`;

        await messageUtils.replyWithEdit(ctx, messageText, Markup.inlineKeyboard(keyboard));
        
    } catch (error) {
        console.error('Error showing countries page:', error);
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Terjadi kesalahan saat menampilkan negara.*\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'order_nokos')]
            ])
        );
    }
}

// Handler untuk countries pagination - FIXED
bot.action(/countries_page_(\d+)/, createBulletproofHandler('COUNTRIES_PAGE', async (ctx) => {
    await ctx.answerCbQuery();
    const page = parseInt(ctx.match[1]);
    
    // Tidak perlu hapus message, langsung edit
    await showCountriesPage(ctx, page);
}));

// Handle country selection
// ==================== FIXED COUNTRY SELECT HANDLER ====================
bot.action(/country_(\d+)/, createBulletproofHandler('COUNTRY_SELECT', async (ctx) => {
    await ctx.answerCbQuery();
    const numberId = ctx.match[1];
    const session = activeSessions.countries[ctx.from.id];
    const country = session.countries.find(c => c.number_id.toString() === numberId);
    
    if (!country || !country.pricelist || country.pricelist.length === 0) {
        await messageUtils.replyWithEdit(
            ctx,
            '❌ Data negara tidak valid.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'order_nokos')]
            ])
        );
        return;
    }

    await showProvidersPage(ctx, country, 0);
}));

// TAMPILKAN LIST PROVIDER/PRICE
// ==================== FIXED PROVIDERS PAGE FUNCTION ====================
async function showProvidersPage(ctx, country, page) {
    const providers = country.pricelist;
    const providersPerPage = 6;
    const totalPages = Math.ceil(providers.length / providersPerPage);
    const startIndex = page * providersPerPage;
    const endIndex = startIndex + providersPerPage;
    const currentProviders = providers.slice(startIndex, endIndex);

    let keyboard = [];
    
    currentProviders.forEach(provider => {
        const basePrice = provider.price;
        const finalPrice = utils.calculatePrice(basePrice);
        
        keyboard.push([
            Markup.button.callback(
                `💎 Server ${provider.server_id} | ${provider.stock} stock | ${provider.rate}% | Rp${utils.formatNumber(finalPrice)}`,
                `provider_${country.number_id}_${provider.provider_id}`
            )
        ]);
    });

    const navRow = [];
    if (page > 0) {
        navRow.push(Markup.button.callback('⬅️ Sebelumnya', `providers_page_${country.number_id}_${page - 1}`));
    }
    navRow.push(Markup.button.callback('🔙 Kembali', `service_${activeSessions.countries[ctx.from.id].service.service_code}`));
    if (page < totalPages - 1) {
        navRow.push(Markup.button.callback('Selanjutnya ➡️', `providers_page_${country.number_id}_${page + 1}`));
    }
    if (navRow.length > 0) {
        keyboard.push(navRow);
    }

    const messageText = 
        `💎 *PILIH PROVIDER - ${country.name}*\n\n` +
        `📊 *Detail Harga:*\n` +
        `• Harga: Rp${utils.formatNumber(utils.calculatePrice(providers[0].price))}\n\n` +
        `Silakan pilih provider:\nHalaman ${page + 1} dari ${totalPages}`;

    await messageUtils.replyWithEdit(
        ctx,
        messageText,
        Markup.inlineKeyboard(keyboard)
    );
}

// Handle providers pagination
// ==================== FIXED PROVIDERS PAGINATION HANDLER ====================
bot.action(/providers_page_(\d+)_(\d+)/, createBulletproofHandler('PROVIDERS_PAGE', async (ctx) => {
    await ctx.answerCbQuery();
    const numberId = ctx.match[1];
    const page = parseInt(ctx.match[2]);
    const session = activeSessions.countries[ctx.from.id];
    const country = session.countries.find(c => c.number_id.toString() === numberId);
    
    if (country) {
        await showProvidersPage(ctx, country, page);
    }
}));

// Handle provider selection
// ==================== FIXED PROVIDER SELECT HANDLER ====================
bot.action(/provider_(\d+)_(.+)/, createBulletproofHandler('PROVIDER_SELECT', async (ctx) => {
    await ctx.answerCbQuery();
    const numberId = ctx.match[1];
    const providerId = ctx.match[2];
    
    const session = activeSessions.countries[ctx.from.id];
    const country = session.countries.find(c => c.number_id.toString() === numberId);
    const provider = country.pricelist.find(p => p.provider_id.toString() === providerId);
    
    if (!country || !provider) {
        await messageUtils.replyWithEdit(
            ctx,
            '❌ Data provider tidak valid.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'order_nokos')]
            ])
        );
        return;
    }

    await messageUtils.replyWithEdit(
        ctx,
        `🔄 *Mengambil daftar operator untuk ${country.name}...*`,
        Markup.inlineKeyboard([])
    );

    const operators = await api.rumahotp.getOperators(country.name, providerId);
    
    if (!operators || !operators.status || !operators.data || operators.data.length === 0) {
        await processFinalOrder(ctx, country, provider, 1);
        return;
    }

    activeSessions.providers[ctx.from.id] = {
        country: country,
        provider: provider,
        operators: operators.data
    };

    await showOperatorsPage(ctx, 0);
}));

// TAMPILKAN LIST OPERATOR
// ==================== FIXED OPERATORS PAGE FUNCTION ====================
async function showOperatorsPage(ctx, page) {
    const session = activeSessions.providers[ctx.from.id];
    const operators = session.operators;
    const country = session.country;
    const provider = session.provider;
    
    const operatorsPerPage = 6;
    const totalPages = Math.ceil(operators.length / operatorsPerPage);
    const startIndex = page * operatorsPerPage;
    const endIndex = startIndex + operatorsPerPage;
    const currentOperators = operators.slice(startIndex, endIndex);

    let keyboard = [];
    
    currentOperators.forEach(operator => {
        keyboard.push([
            Markup.button.callback(
                `📱 ${operator.name}`,
                `operator_${operator.id}`
            )
        ]);
    });

    const navRow = [];
    if (page > 0) {
        navRow.push(Markup.button.callback('⬅️ Sebelumnya', `operators_page_${page - 1}`));
    }
    navRow.push(Markup.button.callback('🔙 Kembali', `country_${country.number_id}`));
    if (page < totalPages - 1) {
        navRow.push(Markup.button.callback('Selanjutnya ➡️', `operators_page_${page + 1}`));
    }
    if (navRow.length > 0) {
        keyboard.push(navRow);
    }

    const messageText = 
        `📱 *PILIH OPERATOR - ${country.name}*\n\n` +
        `💰 Harga: Rp${utils.formatNumber(utils.calculatePrice(provider.price))}\n` +
        `📊 Stock: ${provider.stock}\n` +
        `⭐ Rate: ${provider.rate}%\n\n` +
        `Silakan pilih operator:\nHalaman ${page + 1} dari ${totalPages}`;

    await messageUtils.replyWithEdit(
        ctx,
        messageText,
        Markup.inlineKeyboard(keyboard)
    );
}

// Handle operators pagination
// ==================== FIXED OPERATORS PAGINATION HANDLER ====================
bot.action(/operators_page_(\d+)/, createBulletproofHandler('OPERATORS_PAGE', async (ctx) => {
    await ctx.answerCbQuery();
    const page = parseInt(ctx.match[1]);
    await showOperatorsPage(ctx, page);
}));

// Handle operator selection
// ==================== FIXED OPERATOR SELECT HANDLER ====================
bot.action(/operator_(\d+)/, createBulletproofHandler('OPERATOR_SELECT', async (ctx) => {
    await ctx.answerCbQuery();
    const operatorId = parseInt(ctx.match[1]);
    const session = activeSessions.providers[ctx.from.id];
    const country = session.country;
    const provider = session.provider;
    
    await processFinalOrder(ctx, country, provider, operatorId);
}));

// ==================== ENHANCED ORDER PROCESSING WITH COUNTDOWN ====================

async function processFinalOrder(ctx, country, provider, operatorId) {
    const userId = ctx.from.id;
    
    if (!lockUtils.acquireUserLock(userId)) {
        await messageUtils.replyWithEdit(
            ctx,
            `⚠️ *TRANSAKSI SEDANG BERLANGSUNG*\n\n` +
            `Anda sudah memiliki transaksi aktif.\n` +
            `Silakan selesaikan transaksi sebelumnya terlebih dahulu.`,
            Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Cek Status', 'check_balance')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
        return;
    }

    await messageUtils.replyWithEdit(
        ctx,
        '🔄 *Membuat order...*',
        Markup.inlineKeyboard([])
    );

    const user = await safeDbOperation(() => db.getUser(userId), 'GET_USER_ORDER');
    const finalPrice = utils.calculatePrice(provider.price);

    if (user.balance < finalPrice) {
        lockUtils.releaseUserLock(userId);
        await messageUtils.replyWithEdit(
            ctx,
            `❌ *SALDO TIDAK CUKUP*\n\n` +
            `💰 Saldo Anda: Rp${utils.formatNumber(user.balance)}\n` +
            `💳 Diperlukan: Rp${utils.formatNumber(finalPrice)}\n\n` +
            `Silakan deposit terlebih dahulu.`,
            Markup.inlineKeyboard([
                [Markup.button.callback('💳 DEPOSIT', 'deposit_menu')],
                [Markup.button.callback('🔙 Menu', 'main_menu')]
            ])
        );
        return;
    }

    await ctx.editMessageText('🔄 *Membuat order...*', {
        parse_mode: 'Markdown'
    });

    const orderResult = await api.rumahotp.createOrder(
        country.number_id,
        provider.provider_id,
        operatorId
    );

    if (!orderResult || !orderResult.success) {
        const errorMsg = orderResult?.error?.message || orderResult?.message || 'Unknown error';
        lockUtils.releaseUserLock(userId);
        
        if (errorMsg.includes('balance') || errorMsg.includes('saldo')) {
            await ctx.editMessageText(
                `❌ *SALDO BOT SEDANG HABIS*\n\n` +
                `Mohon maaf, saldo bot sedang habis.\n` +
                `Silakan hubungi admin: @KingStoreGanteng\n\n` +
                `Error: ${errorMsg}`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Menu', 'main_menu')]
                    ]).reply_markup
                }
            );
            return;
        }
        
        await ctx.editMessageText(
            `❌ *Gagal membuat order.*\n\nError: ${errorMsg}\n\nSilakan coba lagi atau pilih layanan lain.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Menu', 'main_menu')]
                ]).reply_markup
            }
        );
        return;
    }

    user.balance -= finalPrice;
    user.totalOrders += 1;
    await safeDbOperation(() => db.updateUser(ctx.from.id, user), 'UPDATE_USER_ORDER');

    const orderDbId = await safeDbOperation(() => db.addOrder({
        userId: ctx.from.id,
        orderId: orderResult.data.order_id,
        phoneNumber: orderResult.data.phone_number,
        service: activeSessions.countries[ctx.from.id].service.service_name,
        country: country.name,
        operator: orderResult.data.operator || 'any',
        basePrice: provider.price,
        finalPrice: finalPrice,
        status: 'active',
        createdAt: Date.now(),
        expiresAt: Date.now() + (orderResult.data.expires_in_minute * 60 * 1000)
    }), 'ADD_ORDER');

    const phoneNumber = orderResult.data.phone_number;
    const displayPhone = phoneNumber;

    const orderText = 
        `✅ *ORDER BERHASIL DIBUAT*\n\n` +
        `📱 *Nomor:* ${displayPhone}\n` +
        `🛍️ *Layanan:* ${activeSessions.countries[ctx.from.id].service.service_name}\n` +
        `🌍 *Negara:* ${country.name}\n` +
        `📊 *Operator:* ${orderResult.data.operator || 'any'}\n` +
        `💰 *Harga:* Rp${utils.formatNumber(finalPrice)}\n` +
        `⏰ *Kadaluarsa dalam:* 05:00\n\n` +
        `🆔 *Order ID:* ${orderResult.data.order_id}\n\n` +
        `📞 *Tunggu SMS OTP masuk...*\n` +
        `🔄 *Status dipantau otomatis*`;

    await messageUtils.replyWithEdit(
        ctx,
        orderText,
        Markup.inlineKeyboard([])
    );

    // Setup auto cancel dan monitoring
    autoCancelUtils.setupAutoCancel(orderResult.data.order_id, userId, orderDbId, ctx);
    setTimeout(() => {
        monitorOrderStatus(ctx, orderResult.data.order_id, orderDbId);
    }, 10000);
}

// ===================== AI CS ======================

// Handler untuk AI Settings
bot.action('owner_ai_settings', createBulletproofHandler('OWNER_AI_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const aiStatus = config.AI_ENABLED ? 'ON 🟢' : 'OFF 🔴';
    const apiKeyStatus = config.OPENAI_API_KEY && config.OPENAI_API_KEY !== 'your-openai-api-key-here' ? '✅ SET' : '❌ NOT SET';

    await ctx.editMessageText(
        `🤖 *AI CUSTOMER SERVICE SETTINGS*\n\n` +
        `🔄 Status: ${aiStatus}\n` +
        `🔑 API Key: ${apiKeyStatus}\n` +
        `🧠 Model: ${config.AI_MODEL || 'gpt-3.5-turbo'}\n` +
        `👥 Active Conversations: ${aiCustomerService.conversationHistory.size}\n\n` +
        `Pilih aksi:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(config.AI_ENABLED ? '🔴 Matikan AI' : '🟢 Hidupkan AI', 
                                         `toggle_ai_${config.AI_ENABLED ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('🧹 Clear All History', 'clear_all_ai_history'),
                    Markup.button.callback('🔍 Test AI', 'test_ai_service')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk toggle AI
bot.action(/toggle_ai_(on|off)/, createBulletproofHandler('TOGGLE_AI', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    // Ini perlu modifikasi config.js secara runtime atau menggunakan database
    // Untuk sementara, kita beri pesan saja
    await ctx.answerCbQuery('⚠️ Untuk mengubah setting AI, edit config.js manual', { show_alert: true });
}));

// Handler untuk clear all AI history
bot.action('clear_all_ai_history', createBulletproofHandler('CLEAR_ALL_AI_HISTORY', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    aiCustomerService.conversationHistory.clear();
    await ctx.answerCbQuery('✅ Semua riwayat AI telah dihapus!');
    
    // Refresh menu
    const aiStatus = config.AI_ENABLED ? 'ON 🟢' : 'OFF 🔴';
    const apiKeyStatus = config.OPENAI_API_KEY && config.OPENAI_API_KEY !== 'your-openai-api-key-here' ? '✅ SET' : '❌ NOT SET';

    await ctx.editMessageText(
        `🤖 *AI CUSTOMER SERVICE SETTINGS*\n\n` +
        `🔄 Status: ${aiStatus}\n` +
        `🔑 API Key: ${apiKeyStatus}\n` +
        `🧠 Model: ${config.AI_MODEL || 'gpt-3.5-turbo'}\n` +
        `👥 Active Conversations: 0 (dihapus)\n\n` +
        `Pilih aksi:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(config.AI_ENABLED ? '🔴 Matikan AI' : '🟢 Hidupkan AI', 
                                         `toggle_ai_${config.AI_ENABLED ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('🧹 Clear All History', 'clear_all_ai_history'),
                    Markup.button.callback('🔍 Test AI', 'test_ai_service')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// ==================== FIXED OWNER ACTION HANDLERS ====================

bot.action('owner_broadcast', createBulletproofHandler('OWNER_BROADCAST', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }
    await ctx.editMessageText(
        `📢 *BROADCAST MESSAGE*\n\n` +
        `Silakan kirim pesan broadcast yang ingin dikirim ke semua user:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 KEMBALI', 'ownermenu_back')]
            ]).reply_markup
        }
    );
    activeSessions.broadcast = ctx.from.id;
}));

bot.action('owner_set_price', createBulletproofHandler('OWNER_SET_PRICE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }
    
    await ctx.editMessageText(
        `💰 *SET HARGA KEUNTUNGAN*\n\n` +
        `Silakan kirim persentase keuntungan (0-100):\n` +
        `Contoh: \`20\` untuk 20% keuntungan\n\n` +
        `Persentase saat ini: ${db.getSettings().profitPercentage}%`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 KEMBALI', 'ownermenu_back')]
            ]).reply_markup
        }
    );
    
    activeSessions.lastCallback[ctx.from.id] = 'set_price';
}));

bot.action('owner_set_deposit_method', createBulletproofHandler('OWNER_SET_DEPOSIT_METHOD', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const currentMethod = utils.getDepositMethod();
    
    await ctx.editMessageText(
        `🔧 *SET DEPOSIT METHOD*\n\n` +
        `Pilih metode deposit yang ingin digunakan:\n\n` +
        `Metode saat ini: ${currentMethod.toUpperCase()}`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(`🏠 RUMAHOTP ${currentMethod === 'rumahotp' ? '✅' : ''}`, 'set_method_rumahotp'),
                    Markup.button.callback(`🌊 ATLANTIC ${currentMethod === 'atlantic' ? '✅' : ''}`, 'set_method_atlantic')
                ],
                [Markup.button.callback('🔙 KEMBALI', 'ownermenu_back')]
            ]).reply_markup
        }
    );
}));

bot.action('set_method_rumahotp', createBulletproofHandler('SET_METHOD_RUMAHOTP', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    utils.setDepositMethod('rumahotp');
    await ctx.editMessageText(
        `✅ *DEPOSIT METHOD DIUBAH!*\n\n` +
        `Metode deposit sekarang: RUMAHOTP\n\n` +
        `Semua transaksi deposit baru akan menggunakan RumahOTP.`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 KEMBALI', 'owner_set_deposit_method')]
            ]).reply_markup
        }
    );
}));

bot.action('set_method_atlantic', createBulletproofHandler('SET_METHOD_ATLANTIC', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    utils.setDepositMethod('atlantic');
    await ctx.editMessageText(
        `✅ *DEPOSIT METHOD DIUBAH!*\n\n` +
        `Metode deposit sekarang: ATLANTIC\n\n` +
        `Semua transaksi deposit baru akan menggunakan Atlantic H2H.`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 KEMBALI', 'owner_set_deposit_method')]
            ]).reply_markup
        }
    );
}));

// Handler untuk maintenance settings di ownermenu - FIXED
bot.action('owner_maintenance', createBulletproofHandler('OWNER_MAINTENANCE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const settings = db.getSettings();
    const maintenanceStatus = settings.maintenance ? 'ON 🔴' : 'OFF 🟢';
    const autoMaintenance = maintenanceManager.maintenanceSchedule.enabled ? 'ON 🟢' : 'OFF 🔴';
    const schedule = `${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB`;

    await ctx.editMessageText(
        `🔧 *MAINTENANCE SETTINGS*\n\n` +
        `🔄 Status Manual: ${maintenanceStatus}\n` +
        `⏰ Auto Maintenance: ${autoMaintenance}\n` +
        `📅 Jadwal: ${schedule}\n\n` +
        `Pilih aksi:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(settings.maintenance ? '✅ Matikan Maintenance' : '🔴 Hidupkan Maintenance', 
                                         `toggle_maintenance_${settings.maintenance ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Jadwal', 'change_maintenance_schedule'),
                    Markup.button.callback('🔄 Toggle Auto', 'toggle_auto_maintenance')
                ],
                [
                    Markup.button.callback('📊 Status', 'check_maintenance_status'),
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk toggle maintenance manual - FIXED
bot.action(/toggle_maintenance_(on|off)/, createBulletproofHandler('TOGGLE_MAINTENANCE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const action = ctx.match[1];
    const shouldEnable = action === 'on';
    
    const data = db.load();
    data.settings.maintenance = shouldEnable;
    db.save(data);

    await ctx.answerCbQuery(`✅ Maintenance ${shouldEnable ? 'dihidupkan' : 'dimatikan'}!`);
    
    // Refresh the maintenance settings menu
    const settings = db.getSettings();
    const maintenanceStatus = settings.maintenance ? 'ON 🔴' : 'OFF 🟢';
    const autoMaintenance = maintenanceManager.maintenanceSchedule.enabled ? 'ON 🟢' : 'OFF 🔴';
    const schedule = `${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB`;

    await ctx.editMessageText(
        `🔧 *MAINTENANCE SETTINGS*\n\n` +
        `🔄 Status Manual: ${maintenanceStatus}\n` +
        `⏰ Auto Maintenance: ${autoMaintenance}\n` +
        `📅 Jadwal: ${schedule}\n\n` +
        `Pilih aksi:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(settings.maintenance ? '✅ Matikan Maintenance' : '🔴 Hidupkan Maintenance', 
                                         `toggle_maintenance_${settings.maintenance ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Jadwal', 'change_maintenance_schedule'),
                    Markup.button.callback('🔄 Toggle Auto', 'toggle_auto_maintenance')
                ],
                [
                    Markup.button.callback('📊 Status', 'check_maintenance_status'),
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk toggle auto maintenance - FIXED
bot.action('toggle_auto_maintenance', createBulletproofHandler('TOGGLE_AUTO_MAINTENANCE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    maintenanceManager.maintenanceSchedule.enabled = !maintenanceManager.maintenanceSchedule.enabled;
    
    await ctx.answerCbQuery(`✅ Auto maintenance ${maintenanceManager.maintenanceSchedule.enabled ? 'dihidupkan' : 'dimatikan'}!`);
    
    // Refresh the maintenance settings menu
    const settings = db.getSettings();
    const maintenanceStatus = settings.maintenance ? 'ON 🔴' : 'OFF 🟢';
    const autoMaintenance = maintenanceManager.maintenanceSchedule.enabled ? 'ON 🟢' : 'OFF 🔴';
    const schedule = `${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB`;

    await ctx.editMessageText(
        `🔧 *MAINTENANCE SETTINGS*\n\n` +
        `🔄 Status Manual: ${maintenanceStatus}\n` +
        `⏰ Auto Maintenance: ${autoMaintenance}\n` +
        `📅 Jadwal: ${schedule}\n\n` +
        `Pilih aksi:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(settings.maintenance ? '✅ Matikan Maintenance' : '🔴 Hidupkan Maintenance', 
                                         `toggle_maintenance_${settings.maintenance ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Jadwal', 'change_maintenance_schedule'),
                    Markup.button.callback('🔄 Toggle Auto', 'toggle_auto_maintenance')
                ],
                [
                    Markup.button.callback('📊 Status', 'check_maintenance_status'),
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk check maintenance status dengan animasi loading berputar
// ==================== FIXED CHECK MAINTENANCE STATUS HANDLER ====================
bot.action('check_maintenance_status', createBulletproofHandler('CHECK_MAINTENANCE_STATUS', async (ctx) => {
    await ctx.answerCbQuery();
    
    const isAdmin = utils.isAdmin(ctx.from.id);
    const settings = db.getSettings();
    const jakartaTime = maintenanceManager.getJakartaTime();
    
    let statusMessage = `📊 *MAINTENANCE STATUS*\n\n`;
    
    if (isAdmin) {
        statusMessage += 
            `👑 Anda: Admin\n` +
            `🔄 Manual: ${settings.maintenance ? 'ON 🔴' : 'OFF 🟢'}\n` +
            `⏰ Auto: ${maintenanceManager.maintenanceSchedule.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
            `📅 Jadwal: ${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB\n` +
            `⏱️ Waktu Server: ${jakartaTime.fullTime} WIB\n` +
            `🔧 Status: ${maintenanceManager.isMaintenanceTime ? 'MAINTENANCE 🟡' : 'NORMAL 🟢'}\n\n`;
        
        if (maintenanceManager.isMaintenanceTime) {
            const [startHour, startMinute] = maintenanceManager.maintenanceSchedule.start.split(':').map(Number);
            const [endHour, endMinute] = maintenanceManager.maintenanceSchedule.end.split(':').map(Number);
            
            const currentTotalMinutes = jakartaTime.hours * 60 + jakartaTime.minutes;
            const endTotalMinutes = endHour * 60 + endMinute;
            
            let minutesLeft = endTotalMinutes - currentTotalMinutes;
            if (minutesLeft < 0) minutesLeft += 24 * 60;
            
            statusMessage += `⏳ Selesai dalam: ${minutesLeft} menit`;
        }
    } else {
        statusMessage += 
            `⏰ Waktu Server: ${jakartaTime.fullTime} WIB\n` +
            `🔧 Status: ${maintenanceManager.isMaintenanceTime ? 'MAINTENANCE 🟡' : 'NORMAL 🟢'}\n\n`;
        
        if (maintenanceManager.isMaintenanceTime) {
            statusMessage += 
                `❤️ MAINTENANCE SEDANG BERLANGSUNG\n\n` +
                `Bot sedang dalam maintenance harian:\n` +
                `❤️ Waktu: ${maintenanceManager.maintenanceSchedule.start} - ${maintenanceManager.maintenanceSchedule.end} WIB\n\n` +
                `Silakan lakukan deposit di luar jam tersebut.`;
        } else {
            statusMessage += `✅ Bot berjalan normal. Silakan gunakan fitur yang tersedia.`;
        }
    }

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔄 Refresh', 'check_maintenance_status')],
        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, statusMessage, keyboard);
}));

// Handler untuk backup settings - FIXED
bot.action('owner_backup_settings', createBulletproofHandler('OWNER_BACKUP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const settings = db.getSettings();
    const backupSettings = settings.backup || {
        auto: false,
        daily: false,
        time: '18.00'
    };

    await ctx.editMessageText(
        `💾 *BACKUP SETTINGS*\n\n` +
        `🔄 Auto Backup: ${backupSettings.auto ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `📅 Daily Backup: ${backupSettings.daily ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `⏰ Waktu: ${backupSettings.time}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(backupSettings.auto ? '🔴 Matikan Auto' : '🟢 Hidupkan Auto', 
                                         `toggle_backup_auto_${backupSettings.auto ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('⏰ Ubah Waktu', 'change_backup_time'),
                    Markup.button.callback('📦 Backup Sekarang', 'backup_now')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk referral settings - FIXED
bot.action('owner_referral_settings', createBulletproofHandler('OWNER_REFERRAL_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const settings = db.getSettings();
    const referralSettings = settings.referral || {
        enabled: true,
        bonus: 5000,
        referrerBonus: 2000,
        referredBonus: 1000
    };

    await ctx.editMessageText(
        `🎁 *REFERRAL SETTINGS*\n\n` +
        `🔄 Status: ${referralSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `💰 Bonus Referrer: Rp${utils.formatNumber(referralSettings.referrerBonus)}\n` +
        `🎁 Bonus Referred: Rp${utils.formatNumber(referralSettings.referredBonus)}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(referralSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_referral_${referralSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('💰 Ubah Bonus', 'change_referral_bonus'),
                    Markup.button.callback('📊 Stats', 'referral_stats')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

// Handler untuk create voucher - FIXED
bot.action('owner_create_voucher', createBulletproofHandler('OWNER_CREATE_VOUCHER', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.editMessageText(
        `🎫 *BUAT VOUCHER BARU*\n\n` +
        `Silakan kirim data voucher dengan format:\n\n` +
        `\`KODE|NOMINAL|MAX_USAGE\`\n\n` +
        `Contoh:\n` +
        `\`WELCOME10|10000|50\` - Voucher WELCOME10, Rp10.000, 50x usage\n` +
        `\`NEWUSER|5000|0\` - Voucher NEWUSER, Rp5.000, unlimited usage\n\n` +
        `*Keterangan:*\n` +
        `• KODE: Huruf besar, tanpa spasi\n` +
        `• NOMINAL: Angka saja\n` +
        `• MAX_USAGE: 0 untuk unlimited, atau angka`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'ownermenu_back')]
            ]).reply_markup
        }
    );

    activeSessions.lastCallback[ctx.from.id] = 'create_voucher';
}));

// Handler untuk owner stats - FIXED
bot.action('owner_stats', createBulletproofHandler('OWNER_STATS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const users = db.getAllUsers();
    const orders = Object.values(db.load().orders);
    const transactions = Object.values(db.load().transactions);
    
    const totalUsers = users.length;
    const totalOrders = orders.length;
    const totalDeposits = transactions.filter(t => t.type === 'deposit').length;
    const totalDepositAmount = transactions
        .filter(t => t.type === 'deposit' && t.status === 'completed')
        .reduce((sum, t) => sum + t.amount, 0);
    
    const activeUsers = users.filter(u => u.totalOrders > 0).length;
    const today = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => 
        new Date(o.createdAt).toISOString().split('T')[0] === today
    ).length;
    
    const topUsers = users
        .filter(u => u.totalOrders > 0)
        .sort((a, b) => b.totalOrders - a.totalOrders)
        .slice(0, 5);

    let statsText = `📊 *DETAILED STATISTICS*\n\n`;
    statsText += `👥 *Total Users:* ${totalUsers}\n`;
    statsText += `📦 *Total Orders:* ${totalOrders}\n`;
    statsText += `💳 *Total Deposits:* ${totalDeposits}\n`;
    statsText += `💰 *Total Deposit Amount:* Rp${utils.formatNumber(totalDepositAmount)}\n`;
    statsText += `🎯 *Active Users:* ${activeUsers}\n`;
    statsText += `📈 *Orders Today:* ${todayOrders}\n\n`;
    
    statsText += `🏆 *TOP 5 USERS:*\n`;
    topUsers.forEach((user, index) => {
        const rankIcon = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🔸';
        const username = user.username ? `@${user.username}` : `User ${user.id.substring(0, 6)}`;
        statsText += `${rankIcon} ${username}: ${user.totalOrders} orders | Rp${utils.formatNumber(user.balance)}\n`;
    });

    await ctx.editMessageText(statsText, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
            [Markup.button.callback('🔄 Refresh', 'owner_stats')],
            [Markup.button.callback('🔙 Kembali', 'ownermenu_back')]
        ]).reply_markup
    });
}));

// Handler untuk list users - FIXED
bot.action('owner_list_users', createBulletproofHandler('OWNER_LIST_USERS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const users = db.getAllUsers();
    const activeUsers = users.filter(u => u.totalOrders > 0);
    const newUsers = users
        .sort((a, b) => new Date(b.joinDate) - new Date(a.joinDate))
        .slice(0, 10);

    let usersText = `👥 *USER MANAGEMENT*\n\n`;
    usersText += `📊 Total: ${users.length} users\n`;
    usersText += `🎯 Active: ${activeUsers.length} users\n\n`;
    
    usersText += `🆕 *10 USER TERBARU:*\n`;
    newUsers.forEach((user, index) => {
        const username = user.username ? `@${user.username}` : `User ${user.id.substring(0, 6)}`;
        const joinDate = new Date(user.joinDate).toLocaleDateString('id-ID');
        usersText += `${index + 1}. ${username} - ${joinDate}\n`;
        usersText += `   📦 ${user.totalOrders} orders | 💰 Rp${utils.formatNumber(user.balance)}\n\n`;
    });

    await ctx.editMessageText(usersText, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
            [Markup.button.callback('📧 Broadcast', 'owner_broadcast')],
            [Markup.button.callback('🔄 Refresh', 'owner_list_users')],
            [Markup.button.callback('🔙 Kembali', 'ownermenu_back')]
        ]).reply_markup
    });
}));

// ==================== AUTO TOP-UP ALERT HANDLERS ====================

bot.action('owner_auto_topup_settings', createBulletproofHandler('OWNER_AUTO_TOPUP_SETTINGS', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const settings = db.getSettings();
    const autoTopupSettings = settings.autoTopupAlert || {
        enabled: true,
        threshold: 50000,
        lastAlertSent: null
    };

    await ctx.editMessageText(
        `🚨 *AUTO TOP-UP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${autoTopupSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `💰 Threshold: Rp${utils.formatNumber(autoTopupSettings.threshold)}\n` +
        `⏰ Terakhir Alert: ${autoTopupSettings.lastAlertSent ? new Date(autoTopupSettings.lastAlertSent).toLocaleString('id-ID') : 'Belum pernah'}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(autoTopupSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_topup_alert_${autoTopupSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('💰 Ubah Threshold', 'change_topup_threshold'),
                    Markup.button.callback('🔄 Cek Saldo Bot', 'check_bot_balance')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

bot.action(/toggle_topup_alert_(on|off)/, createBulletproofHandler('TOGGLE_TOPUP_ALERT', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    const action = ctx.match[1];
    const shouldEnable = action === 'on';
    
    const settings = db.getSettings();
    settings.autoTopupAlert.enabled = shouldEnable;
    db.updateSettings(settings);

    await ctx.answerCbQuery(`✅ Auto top-up alert ${shouldEnable ? 'dihidupkan' : 'dimatikan'}!`);
    
    // Refresh menu
    const updatedSettings = db.getSettings();
    const autoTopupSettings = updatedSettings.autoTopupAlert;

    await ctx.editMessageText(
        `🚨 *AUTO TOP-UP ALERT SETTINGS*\n\n` +
        `🔄 Status: ${autoTopupSettings.enabled ? 'ON 🟢' : 'OFF 🔴'}\n` +
        `💰 Threshold: Rp${utils.formatNumber(autoTopupSettings.threshold)}\n` +
        `⏰ Terakhir Alert: ${autoTopupSettings.lastAlertSent ? new Date(autoTopupSettings.lastAlertSent).toLocaleString('id-ID') : 'Belum pernah'}\n\n` +
        `Pilih pengaturan:`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [
                    Markup.button.callback(autoTopupSettings.enabled ? '🔴 Matikan' : '🟢 Hidupkan', 
                                         `toggle_topup_alert_${autoTopupSettings.enabled ? 'off' : 'on'}`)
                ],
                [
                    Markup.button.callback('💰 Ubah Threshold', 'change_topup_threshold'),
                    Markup.button.callback('🔄 Cek Saldo Bot', 'check_bot_balance')
                ],
                [
                    Markup.button.callback('🔙 Kembali', 'ownermenu_back')
                ]
            ]).reply_markup
        }
    );
}));

bot.action('change_topup_threshold', createBulletproofHandler('CHANGE_TOPUP_THRESHOLD', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.editMessageText(
        `💰 *UBAH THRESHOLD TOP-UP ALERT*\n\n` +
        `Silakan kirim nominal threshold baru:\n\n` +
        `Contoh: \`50000\` untuk Rp50,000\n` +
        `Saat ini: Rp${utils.formatNumber(db.getSettings().autoTopupAlert.threshold)}`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_auto_topup_settings')]
            ]).reply_markup
        }
    );

    activeSessions.lastCallback[ctx.from.id] = 'change_topup_threshold';
}));

// Handler untuk check bot balance dengan animasi loading berputar
bot.action('check_bot_balance', createBulletproofHandler('CHECK_BOT_BALANCE', async (ctx) => {
    if (!utils.isAdmin(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    await ctx.answerCbQuery('🔄 Mengecek saldo bot...');
    
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.log('⚠️ Cannot delete message, continuing...');
    }
    
    const loadingMsg = await ctx.reply('💰 *Mengecek saldo bot...*', { 
        parse_mode: 'Markdown' 
    });
    
    const frames = [
        "💰 Mengecek saldo bot [▰▱▱▱▱]",
        "🔗 Menghubungi server [▰▰▱▱▱]", 
        "📊 Memproses data [▰▰▰▱▱]",
        "💳 Verifikasi saldo [▰▰▰▰▱]",
        "✅ Siap menampilkan [▰▰▰▰▰]"
    ];
    
    let frameIndex = 0;
    const loadingInterval = setInterval(async () => {
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                frames[frameIndex],
                { parse_mode: 'Markdown' }
            );
            frameIndex = (frameIndex + 1) % frames.length;
        } catch (error) {
            clearInterval(loadingInterval);
        }
    }, 500);
    
    try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        clearInterval(loadingInterval);
        await ctx.deleteMessage(loadingMsg.message_id);
        
        const balanceResult = await api.rumahotp.getBalance();
        if (balanceResult && balanceResult.success) {
            const botBalance = balanceResult.data.balance || 0;
            const threshold = db.getSettings().autoTopupAlert.threshold;
            
            await ctx.reply(
                `💰 *SALDO BOT SAAT INI*\n\n` +
                `💵 *Saldo:* Rp${utils.formatNumber(botBalance)}\n` +
                `⚠️ *Threshold:* Rp${utils.formatNumber(threshold)}\n` +
                `📊 *Status:* ${botBalance < threshold ? '🔴 PERLU TOP-UP!' : '🟢 AMAN'}\n\n` +
                `⏰ Diperiksa: ${utils.getIndonesianTime()}`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔄 Refresh', 'check_bot_balance')],
                        [Markup.button.callback('🔙 Kembali', 'owner_auto_topup_settings')]
                    ]).reply_markup
                }
            );
        } else {
            throw new Error('Gagal mengambil saldo');
        }
        
    } catch (error) {
        clearInterval(loadingInterval);
        try {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                `❌ *GAGAL MENGECEK SALDO BOT*\n\n` +
                `Error: ${error.message}\n\n` +
                `Silakan coba lagi.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔄 Coba Lagi', 'check_bot_balance')],
                        [Markup.button.callback('🔙 Kembali', 'owner_auto_topup_settings')]
                    ]).reply_markup
                }
            );
        } catch (e) {
            console.error('Error handling animation failure:', e);
        }
    }
}));

// ==================== REFERRAL MENU ====================
bot.action('referral_menu', createBulletproofHandler('REFERRAL_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_REFERRAL');
    const settings = db.getSettings();
    const referralSettings = settings.referral || { enabled: true, bonus: 200 };
    
    const botUsername = bot.botInfo?.username || 'rumahOtpV1_Bot';
    const referralLink = `https://t.me/${botUsername}?start=ref_${user.referralCode}`;
    
    const referralText = `🎁 *SISTEM REFERRAL*\n\n` +
                        `💰 *Bonus Referrer:* Rp${utils.formatNumber(referralSettings.bonus)}\n` +
                        `🎁 *Bonus Referred:* Rp${utils.formatNumber(referralSettings.referredBonus || 100)}\n\n` +
                        `📊 *Statistik Anda:*\n` +
                        `👥 Referral Count: ${user.referralCount || 0}\n` +
                        `💎 Referral Earnings: Rp${utils.formatNumber(user.referralEarnings || 0)}\n\n` +
                        `🔗 *Link Referral Anda:*\n` +
                        `<code>${referralLink}</code>\n\n` +
                        `📋 *Cara kerja:*\n` +
                        `1. Bagikan link di atas ke teman\n` +
                        `2. Teman klik link dan mulai bot\n` +
                        `3. Bonus otomatis masuk ke saldo!`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('📋 DAFTAR REFERRAL', 'referral_list')],
        [Markup.button.callback('💰 KLAIM REFERRAL', 'claim_referral')],
        [Markup.button.callback('🔗 SALIN LINK', 'copy_referral_link')],
        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, referralText, keyboard, 'HTML');
}));

// ==================== REFERRAL LIST ====================
bot.action('referral_list', createBulletproofHandler('REFERRAL_LIST', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    const data = await safeDbOperation(() => db.load(), 'LOAD_REFERRAL_LIST');
    
    // Ambil semua referral user ini
    const userReferrals = Object.values(data.referrals || {})
        .filter(ref => ref.referrerId === userId.toString())
        .sort((a, b) => b.createdAt - a.createdAt);

    if (userReferrals.length === 0) {
        await messageUtils.replyWithEdit(
            ctx,
            `📋 *DAFTAR REFERRAL ANDA*\n\n` +
            `Belum ada user yang bergabung melalui referral Anda.\n\n` +
            `Ajak teman untuk mendapatkan bonus!`,
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'referral_menu')]
            ])
        );
        return;
    }

    let referralListText = `📋 *DAFTAR REFERRAL ANDA*\n\n`;
    referralListText += `Total Referral: ${userReferrals.length}\n\n`;

    userReferrals.forEach((ref, index) => {
        const time = new Date(ref.createdAt).toLocaleString('id-ID');
        const referredUser = data.users?.[ref.referredId];
        const username = referredUser?.username ? `@${referredUser.username}` : 
                        referredUser?.first_name || `User ${ref.referredId.substring(0, 6)}`;
        
        referralListText += `${index + 1}. ${username}\n`;
        referralListText += `   📅 ${time}\n`;
        referralListText += `   ✅ Bonus: ${ref.bonusGiven ? 'Sudah diklaim' : 'Belum diklaim'}\n`;
        referralListText += `━━━━━━━━━━━━━━\n`;
    });

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔄 Refresh', 'referral_list')],
        [Markup.button.callback('💰 Klaim Bonus', 'claim_referral')],
        [Markup.button.callback('🔙 Kembali', 'referral_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, referralListText, keyboard);
}));

// ==================== CLAIM REFERRAL ====================
bot.action('claim_referral', createBulletproofHandler('CLAIM_REFERRAL', async (ctx) => {
    await ctx.answerCbQuery();
    
    const userId = ctx.from.id;
    const user = await safeDbOperation(() => db.getUser(userId), 'GET_USER_CLAIM');
    const data = await safeDbOperation(() => db.load(), 'LOAD_CLAIM_DATA');
    
    // Hitung total bonus yang belum diklaim
    const unclaimedReferrals = Object.values(data.referrals || {})
        .filter(ref => ref.referrerId === userId.toString() && !ref.bonusGiven);
    
    if (unclaimedReferrals.length === 0) {
        await messageUtils.replyWithEdit(
            ctx,
            `💰 *KLAIM BONUS REFERRAL*\n\n` +
            `Tidak ada bonus referral yang tersedia untuk diklaim.\n\n` +
            `Ajak lebih banyak teman untuk mendapatkan bonus!`,
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'referral_menu')]
            ])
        );
        return;
    }

    const settings = db.getSettings();
    const bonusPerReferral = settings.referral?.bonus || 200;
    const totalBonus = unclaimedReferrals.length * bonusPerReferral;

    // Update saldo user
    user.balance += totalBonus;
    user.referralEarnings = (user.referralEarnings || 0) + totalBonus;
    
    // Mark semua sebagai sudah diklaim
    unclaimedReferrals.forEach(ref => {
        if (data.referrals[ref.id]) {
            data.referrals[ref.id].bonusGiven = true;
        }
    });

    // Save ke database
    await safeDbOperation(() => db.updateUser(userId, user), 'UPDATE_USER_BALANCE_REFERRAL');
    data.users[userId.toString()] = user;
    await safeDbOperation(() => db.save(data), 'SAVE_REFERRAL_CLAIM');

    await messageUtils.replyWithEdit(
        ctx,
        `🎉 *BONUS REFERRAL BERHASIL DIKLAIM!*\n\n` +
        `💰 *Jumlah Referral:* ${unclaimedReferrals.length}\n` +
        `💵 *Bonus per Referral:* Rp${utils.formatNumber(bonusPerReferral)}\n` +
        `💰 *Total Bonus:* Rp${utils.formatNumber(totalBonus)}\n\n` +
        `💳 *Saldo Sekarang:* Rp${utils.formatNumber(user.balance)}\n\n` +
        `Terima kasih telah mengajak teman! 🎊`,
        Markup.inlineKeyboard([
            [Markup.button.callback('📋 Lihat Daftar', 'referral_list')],
            [Markup.button.callback('🔙 Menu Referral', 'referral_menu')]
        ])
    );
}));

// ==================== COPY REFERRAL LINK ====================
bot.action('copy_referral_link', createBulletproofHandler('COPY_REFERRAL_LINK', async (ctx) => {
    await ctx.answerCbQuery('📋 Link referral disalin ke clipboard!', { show_alert: true });
    
    const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_COPY_LINK');
    const botUsername = bot.botInfo?.username || 'rumahOtpV1_Bot';
    const referralLink = `https://t.me/${botUsername}?start=ref_${user.referralCode}`;
    
    await messageUtils.replyWithEdit(
        ctx,
        `🔗 *LINK REFERRAL ANDA*\n\n` +
        `Salin link di bawah ini untuk dibagikan:\n\n` +
        `<code>${referralLink}</code>\n\n` +
        `📋 *Cara pakai:*\n` +
        `1. Bagikan link ini ke teman\n` +
        `2. Teman klik link dan mulai bot\n` +
        `3. Bonus otomatis masuk ke saldo Anda!\n\n` +
        `💰 *Bonus yang didapat:*\n` +
        `• Anda: Rp${utils.formatNumber(db.getSettings().referral?.bonus || 200)}\n` +
        `• Teman: Rp${utils.formatNumber(db.getSettings().referral?.referredBonus || 100)}`,
        Markup.inlineKeyboard([
            [Markup.button.callback('🔙 Kembali', 'referral_menu')]
        ]),
        'HTML'
    );
}));

// ==================== VOUCHER SYSTEM HANDLERS ====================

// ==================== VOUCHER MENU HANDLER ====================
bot.action('voucher_menu', createBulletproofHandler('VOUCHER_MENU', async (ctx) => {
    await ctx.answerCbQuery();
    
    const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_VOUCHER');
    const data = await safeDbOperation(() => db.load(), 'LOAD_VOUCHER_DATA');
    
    // Ambil voucher yang masih aktif
    const activeVouchers = Object.values(data.vouchers || {})
        .filter(voucher => !voucher.used && (!voucher.maxUsage || voucher.usedCount < voucher.maxUsage));
    
    let voucherText = `🎫 *MENU VOUCHER*\n\n`;
    
    if (activeVouchers.length === 0) {
        voucherText += `Tidak ada voucher yang tersedia saat ini.\n\n`;
        voucherText += `Tunggu voucher baru dari admin atau cek channel @KingStoreReal untuk info terbaru!`;
    } else {
        voucherText += `📋 *Voucher Tersedia:* ${activeVouchers.length}\n\n`;
        
        activeVouchers.slice(0, 5).forEach((voucher, index) => {
            voucherText += `🎫 *${voucher.code}*\n`;
            voucherText += `💰 Nilai: Rp${utils.formatNumber(voucher.amount || 0)}\n`;
            if (voucher.maxUsage) {
                voucherText += `📊 Tersisa: ${voucher.maxUsage - (voucher.usedCount || 0)}/${voucher.maxUsage}\n`;
            }
            voucherText += `━━━━━━━━━━━━━━\n`;
        });
        
        if (activeVouchers.length > 5) {
            voucherText += `\n...dan ${activeVouchers.length - 5} voucher lainnya`;
        }
        
        voucherText += `\n📝 *Cara pakai:*\n`;
        voucherText += `1. Klik "Gunakan Voucher"\n`;
        voucherText += `2. Masukkan kode voucher\n`;
        voucherText += `3. Bonus otomatis masuk ke saldo!`;
    }

    const keyboardRows = [];
    
    if (activeVouchers.length > 0) {
        keyboardRows.push([
            Markup.button.callback('🎫 GUNAKAN VOUCHER', 'use_voucher_input')
        ]);
    }
    
    keyboardRows.push([
        Markup.button.callback('🔙 Menu Utama', 'main_menu')
    ]);

    await messageUtils.replyWithEdit(ctx, voucherText, Markup.inlineKeyboard(keyboardRows));
}));

// ==================== USE VOUCHER INPUT HANDLER ====================
bot.action('use_voucher_input', createBulletproofHandler('USE_VOUCHER_INPUT', async (ctx) => {
    await ctx.answerCbQuery();
    
    const voucherText = 
        `🎫 *GUNAKAN VOUCHER*\n\n` +
        `Silakan masukkan kode voucher:\n\n` +
        `📋 *Contoh:*\n` +
        `• WELCOME10000\n` +
        `• DISKON5000\n` +
        `• BONUS2000\n\n` +
        `Ketik kode voucher dan kirim pesan:`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
    ]);

    await messageUtils.replyWithEdit(ctx, voucherText, keyboard);
    
    activeSessions.lastCallback[ctx.from.id] = 'use_voucher';
}));

// ==================== VOUCHER USE PROCESS ====================
async function processVoucherUse(ctx, voucherCode) {
    try {
        const userId = ctx.from.id;
        const user = await safeDbOperation(() => db.getUser(userId), 'GET_USER_VOUCHER_USE');
        const voucher = await safeDbOperation(() => db.getVoucher(voucherCode.toUpperCase()), 'GET_VOUCHER');
        
        if (!voucher) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *VOUCHER TIDAK DITEMUKAN*\n\n` +
                `Kode voucher "${voucherCode}" tidak valid atau sudah kadaluarsa.\n` +
                `Periksa kembali kode voucher Anda.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                ])
            );
            return;
        }

        if (voucher.used) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *VOUCHER SUDAH DIGUNAKAN*\n\n` +
                `Voucher "${voucherCode}" sudah digunakan.\n` +
                `Setiap voucher hanya bisa digunakan satu kali.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                ])
            );
            return;
        }

        if (voucher.maxUsage && voucher.usedCount >= voucher.maxUsage) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *VOUCHER SUDAH HABIS*\n\n` +
                `Voucher "${voucherCode}" sudah mencapai batas penggunaan.\n` +
                `Total penggunaan: ${voucher.usedCount}/${voucher.maxUsage}`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                ])
            );
            return;
        }

        // Gunakan voucher
        const success = await safeDbOperation(() => db.useVoucher(voucherCode.toUpperCase(), userId), 'USE_VOUCHER');
        
        if (success) {
            // Tambahkan saldo ke user
            user.balance += voucher.amount || 0;
            await safeDbOperation(() => db.updateUser(userId, user), 'UPDATE_USER_VOUCHER');
            
            await messageUtils.replyWithEdit(
                ctx,
                `🎉 *VOUCHER BERHASIL DIGUNAKAN!*\n\n` +
                `🎫 Kode: ${voucherCode}\n` +
                `💰 Bonus: Rp${utils.formatNumber(voucher.amount || 0)}\n` +
                `💳 Saldo Baru: Rp${utils.formatNumber(user.balance)}\n\n` +
                `Terima kasih telah menggunakan voucher! 🎊`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🎫 Cari Voucher Lain', 'voucher_menu')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            
            // Notifikasi ke owner
            try {
                await bot.telegram.sendMessage(
                    config.OWNER_ID,
                    `🎫 *VOUCHER DIGUNAKAN*\n\n` +
                    `👤 User: ${userId}\n` +
                    `📧 Username: ${ctx.from.username ? '@' + ctx.from.username : 'Tidak ada'}\n` +
                    `🎫 Voucher: ${voucherCode}\n` +
                    `💰 Amount: Rp${utils.formatNumber(voucher.amount || 0)}\n` +
                    `⏰ Time: ${utils.getIndonesianTime()}`,
                    { parse_mode: 'Markdown' }
                );
            } catch (error) {
                console.error('Error sending voucher notification to owner:', error);
            }
            
        } else {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *GAGAL MENGGUNAKAN VOUCHER*\n\n` +
                `Terjadi kesalahan saat menggunakan voucher.\n` +
                `Silakan coba lagi atau hubungi admin.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                ])
            );
        }
        
    } catch (error) {
        console.error('Error processing voucher use:', error);
        await messageUtils.replyWithEdit(
            ctx,
            `❌ *TERJADI KESALAHAN*\n\n` +
            `Gagal memproses voucher.\n` +
            `Silakan coba lagi atau hubungi admin.`,
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
            ])
        );
    }
}

// ==================== TEXT MESSAGE HANDLER ====================

// ==================== FIXED MESSAGE HANDLER ====================
bot.on('message', createBulletproofHandler('MESSAGE_HANDLER', async (ctx) => {
    const userId = ctx.from.id;
    const messageText = ctx.message.text;
    
    if (!messageText) return;

    const lastCallback = activeSessions.lastCallback[userId];
    
    // Handle AI customer service queries
    if (lastCallback === 'ai_customer_service') {
        await handleAICustomerQuery(ctx, messageText);
        return;
    }
    
    // Handle deposit custom
    if (lastCallback === 'deposit_custom') {
        await handleDepositCustom(ctx, messageText);
        return;
    }
    
    // Handle set price (owner)
    if (lastCallback === 'set_price' && utils.isAdmin(userId)) {
        await handleSetPrice(ctx, messageText);
        return;
    }
    
    // Handle create voucher (owner)
    if (lastCallback === 'create_voucher' && utils.isAdmin(userId)) {
        await handleCreateVoucher(ctx, messageText);
        return;
    }
    
    // Handle use voucher (user)
    if (lastCallback === 'use_voucher') {
        await processVoucherUse(ctx, messageText);
        return;
    }
    
    // Handle H2H search products (owner)
    if (lastCallback === 'h2h_search_products' && utils.isAdmin(userId)) {
        await handleH2HSearchProducts(ctx, messageText);
        return;
    }
    
    // Handle H2H order (owner)
    if (lastCallback === 'process_h2h_order' && utils.isAdmin(userId)) {
        await handleH2HOrder(ctx, messageText);
        return;
    }
    
    // Handle cairkan custom (owner)
    if (lastCallback === 'cairkan_custom' && utils.isAdmin(userId)) {
        await handleCairkanCustom(ctx, messageText);
        return;
    }
    
    // Handle change price drop delay (owner)
    if (lastCallback === 'change_price_drop_delay' && utils.isAdmin(userId)) {
        await handleChangePriceDropDelay(ctx, messageText);
        return;
    }
    
    // Handle broadcast message (owner)
    if (activeSessions.broadcast === userId && utils.isAdmin(userId)) {
        await handleBroadcastMessage(ctx, messageText);
        return;
    }
    
    // Jika bukan command khusus, tampilkan menu utama
    if (messageText.startsWith('/')) {
        return; // Biarkan command handler yang menangani
    }
    
    // Default: Tampilkan main menu
    await showMainMenu(ctx);
}));

// ==================== AI CUSTOMER QUERY HANDLER ====================
async function handleAICustomerQuery(ctx, messageText) {
    try {
        // Tampilkan pesan sedang memproses
        await messageUtils.replyWithEdit(
            ctx,
            '🤖 *Memproses pertanyaan Anda...*',
            Markup.inlineKeyboard([])
        );

        const userId = ctx.from.id;
        const username = ctx.from.username || ctx.from.first_name || 'User';
        
        const aiResponse = await aiCustomerService.handleCustomerQuery(userId, messageText, username);
        
        // Kirim notifikasi ke owner
        await aiCustomerService.notifyOwnerAboutAIQuery(
            userId, 
            messageText, 
            aiResponse.response, 
            aiResponse.requiresHuman, 
            username
        );
        
        // Kirim response ke user
        await messageUtils.replyWithEdit(
            ctx,
            aiResponse.response,
            Markup.inlineKeyboard([
                [Markup.button.callback('🤖 Tanya Lagi', 'ai_customer_service')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
    } catch (error) {
        console.error('Error handling AI query:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Terjadi kesalahan saat memproses pertanyaan.*\n\nSilakan coba lagi atau hubungi admin.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// ==================== HANDLE DEPOSIT CUSTOM FUNCTION ====================
async function handleDepositCustom(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        const nominal = parseInt(messageText.replace(/[^\d]/g, ''));
        
        if (isNaN(nominal) || nominal < config.MIN_DEPOSIT) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *NOMINAL TIDAK VALID!*\n\n` +
                `Nominal minimal deposit: Rp${utils.formatNumber(config.MIN_DEPOSIT)}\n` +
                `Contoh: 5000, 10000, 25000`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
                ])
            );
            return;
        }
        
        // Lanjutkan proses deposit
        await processDeposit(ctx, nominal);
        
    } catch (error) {
        console.error('Error handling deposit custom:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *TERJADI KESALAHAN!*\n\n' +
            'Gagal memproses deposit custom.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
            ])
        );
    }
}

// ==================== HANDLE SET PRICE FUNCTION ====================
async function handleSetPrice(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        const percentage = parseFloat(messageText);
        
        if (isNaN(percentage) || percentage < 0 || percentage > 100) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *PERSENTASE TIDAK VALID!*\n\n' +
                'Persentase harus antara 0-100.\n' +
                'Contoh: 20, 25, 30',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        // Update profit percentage
        const success = await safeDbOperation(() => utils.setProfitPercentage(percentage), 'SET_PROFIT_PERCENTAGE');
        
        if (success) {
            await messageUtils.replyWithEdit(
                ctx,
                `✅ *PERSENTASE KEUNTUNGAN BERHASIL DIUBAH!*\n\n` +
                `💰 *Persentase baru:* ${percentage}%\n\n` +
                `Semua harga akan dihitung dengan persentase ini.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
        } else {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *GAGAL MENGUBAH PERSENTASE!*\n\n' +
                'Terjadi kesalahan saat menyimpan pengaturan.\n' +
                'Silakan coba lagi.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
        }
        
    } catch (error) {
        console.error('Error handling set price:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *TERJADI KESALAHAN!*\n\n' +
            'Gagal memproses perubahan persentase.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}

// ==================== HANDLE H2H SEARCH PRODUCTS FUNCTION ====================
async function handleH2HSearchProducts(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        if (!messageText || messageText.trim().length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *KATA KUNCI TIDAK BOLEH KOSONG!*\n\n' +
                'Silakan masukkan kata kunci pencarian.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_h2h_products')]
                ])
            );
            return;
        }
        
        // Proses pencarian H2H
        const keyword = messageText.trim().toLowerCase();
        
        await messageUtils.replyWithEdit(
            ctx,
            `🔍 *Mencari produk H2H: "${keyword}"...*`,
            Markup.inlineKeyboard([])
        );
        
        // Langsung panggil command listh2h
        ctx.message = ctx.message || {};
        ctx.message.text = `/listh2h ${keyword}`;
        
        // Panggil handler listh2h
        await bot.command('listh2h', ctx);
        
    } catch (error) {
        console.error('Error handling H2H search:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *GAGAL MENCARI PRODUK!*\n\n' +
            'Terjadi kesalahan saat mencari produk.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_h2h_products')]
            ])
        );
    }
}

// ==================== HANDLE H2H ORDER FUNCTION ====================
async function handleH2HOrder(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        const parts = messageText.split(' ');
        
        if (parts.length < 2) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *FORMAT ORDER SALAH!*\n\n' +
                'Format: `KODE_PRODUK NOMOR_TUJUAN`\n\n' +
                'Contoh:\n' +
                '• D1 081234567890\n' +
                '• P1 628123456789',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        const productCode = parts[0];
        const targetNumber = parts.slice(1).join(' ');
        
        // Validasi nomor
        const cleanedNumber = targetNumber.replace(/[^\d]/g, '');
        if (cleanedNumber.length < 10) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *NOMOR TUJUAN TIDAK VALID!*\n\n' +
                'Nomor tujuan harus minimal 10 digit.\n' +
                'Contoh: 081234567890, 628123456789',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        // Proses order H2H
        await messageUtils.replyWithEdit(
            ctx,
            `🔄 *Memproses order H2H...*\n\n` +
            `📦 Kode: ${productCode}\n` +
            `📱 Tujuan: ${targetNumber}`,
            Markup.inlineKeyboard([])
        );
        
        // Langsung panggil command orderh2h
        ctx.message = ctx.message || {};
        ctx.message.text = `/orderh2h ${productCode} ${targetNumber}`;
        
        // Panggil handler orderh2h
        await bot.command('orderh2h', ctx);
        
    } catch (error) {
        console.error('Error handling H2H order:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *GAGAL MEMPROSES ORDER!*\n\n' +
            'Terjadi kesalahan saat memproses order.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}

// ==================== HANDLE CAIRKAN CUSTOM FUNCTION ====================
async function handleCairkanCustom(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        const nominal = parseInt(messageText.replace(/[^\d]/g, ''));
        
        if (isNaN(nominal) || nominal < 1000 || nominal % 1000 !== 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *NOMINAL TIDAK VALID!*\n\n' +
                'Nominal harus:\n' +
                '• Minimal: Rp1.000\n' +
                '• Kelipatan: Rp1.000\n\n' +
                'Contoh: 1000, 2000, 5000, 10000',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_cairkan')]
                ])
            );
            return;
        }
        
        // Proses cairkan langsung
        await processCairkanInstant(ctx, nominal);
        
    } catch (error) {
        console.error('Error handling cairkan custom:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *TERJADI KESALAHAN!*\n\n' +
            'Gagal memproses pencairan.\n' +
            'Silakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_cairkan')]
            ])
        );
    }
}

// ==================== HANDLE CHANGE PRICE DROP DELAY FUNCTION ====================
async function handleChangePriceDropDelay(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset callback
        delete activeSessions.lastCallback[userId];
        
        const delayMinutes = parseInt(messageText);
        
        if (isNaN(delayMinutes) || delayMinutes < 1 || delayMinutes > 60) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *DELAY TIDAK VALID!*\n\n' +
                'Delay harus antara 1-60 menit.\n' +
                'Contoh: 5, 10, 15',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
                ])
            );
            return;
        }
        
        // Update delay in settings
        const settings = db.getSettings();
        settings.priceDropAlert.delayBetweenAlerts = delayMinutes * 60 * 1000; // Convert to milliseconds
        const success = db.updateSettings(settings);
        
        if (success) {
            await messageUtils.replyWithEdit(
                ctx,
                `✅ *DELAY ALERT BERHASIL DIUBAH!*\n\n` +
                `⏰ *Delay baru:* ${delayMinutes} menit\n\n` +
                `Alert harga turun akan dikirim dengan delay ini.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
                ])
            );
        } else {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *GAGAL MENGUBAH DELAY!*\n\n' +
                'Terjadi kesalahan saat menyimpan pengaturan.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
                ])
            );
        }
        
    } catch (error) {
        console.error('Error handling change price drop delay:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *TERJADI KESALAHAN!*\n\n' +
            'Gagal memproses perubahan delay.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
            ])
        );
    }
}

// ==================== HANDLE BROADCAST MESSAGE FUNCTION ====================
async function handleBroadcastMessage(ctx, messageText) {
    try {
        const userId = ctx.from.id;
        
        // Reset broadcast session
        delete activeSessions.broadcast;
        
        if (!messageText || messageText.trim().length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *PESAN TIDAK BOLEH KOSONG!*\n\n' +
                'Silakan kirim pesan yang valid.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        const allUsers = await safeDbOperation(() => db.getAllUsers(), 'GET_ALL_USERS_BROADCAST');
        
        if (allUsers.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *TIDAK ADA USER UNTUK DIKIRIM!*\n\n' +
                'Belum ada user yang terdaftar.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }
        
        await messageUtils.replyWithEdit(
            ctx,
            `📢 *MENGIRIM BROADCAST...*\n\n` +
            `📝 Pesan: ${messageText.substring(0, 100)}${messageText.length > 100 ? '...' : ''}\n` +
            `👥 Target: ${allUsers.length} user\n` +
            `⏰ Waktu mulai: ${utils.getIndonesianTime()}\n\n` +
            `Mohon tunggu...`,
            Markup.inlineKeyboard([])
        );
        
        let successCount = 0;
        let failedCount = 0;
        
        // Kirim broadcast ke semua user
        for (const user of allUsers) {
            try {
                await bot.telegram.sendMessage(
                    user.id,
                    `📢 *BROADCAST MESSAGE*\n\n` +
                    `${messageText}\n\n` +
                    `⏰ ${utils.getIndonesianTime()}\n` +
                    `🤖 Andin Official`,
                    { parse_mode: 'Markdown' }
                );
                successCount++;
                
                // Delay untuk menghindari rate limit
                await new Promise(resolve => setTimeout(resolve, 100));
                
            } catch (error) {
                console.error(`Failed to send broadcast to user ${user.id}:`, error.message);
                failedCount++;
            }
        }
        
        const resultText = 
            `📢 *BROADCAST SELESAI!*\n\n` +
            `✅ Berhasil: ${successCount} user\n` +
            `❌ Gagal: ${failedCount} user\n` +
            `👥 Total: ${allUsers.length} user\n\n` +
            `📝 Pesan:\n${messageText.substring(0, 200)}${messageText.length > 200 ? '...' : ''}`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('📢 Broadcast Lagi', 'owner_broadcast')],
            [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
        ]);
        
        await messageUtils.replyWithEdit(ctx, resultText, keyboard);
        
    } catch (error) {
        console.error('Error handling broadcast:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *GAGAL MENGIRIM BROADCAST!*\n\n' +
            'Terjadi kesalahan saat mengirim broadcast.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}

bot.on('text', createBulletproofHandler('TEXT_MESSAGE', async (ctx) => {
    if (ctx.message.text.startsWith('/')) {
        return;
    }

    const userId = ctx.from.id;
    const userMessage = ctx.message.text.trim();
    
    console.log(`📨 Received text from ${userId}: ${userMessage}`);

    if (utils.checkSpam(userId)) {
        await ctx.reply('⚠️ Terlalu banyak permintaan. Silakan tunggu beberapa saat.');
        return;
    }

    const lastCallback = activeSessions.lastCallback[userId];

// Di dalam bot.on('text') handler, tambahkan:
// Handle order cepat
if (lastCallback && lastCallback.startsWith('quick_order_')) {
    const productCode = lastCallback.replace('quick_order_', '');
    const targetNumber = userMessage.trim();
    
    // Validasi nomor
    if (!targetNumber || targetNumber.length < 10) {
        await ctx.reply(
            '❌ Nomor tujuan tidak valid! Pastikan nomor minimal 10 digit.',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Coba Lagi', 'owner_h2h_products')]
                ]).reply_markup
            }
        );
        delete activeSessions.lastCallback[userId];
        return;
    }

    // Langsung proses order
    await processH2HOrderInstant(ctx, productCode, targetNumber);
    delete activeSessions.lastCallback[userId];
    return;
}

// Handle cairkan custom
if (lastCallback === 'cairkan_custom') {
    const nominal = userMessage.trim();
    
    if (!nominal || isNaN(nominal) || parseInt(nominal) < 1000) {
        await ctx.reply(
            '❌ Nominal tidak valid! Minimal Rp1.000 dan harus angka.',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Coba Lagi', 'owner_cairkan')]
                ]).reply_markup
            }
        );
        return;
    }

    // Validasi kelipatan 1000
    if (parseInt(nominal) % 1000 !== 0) {
        await ctx.reply(
            '❌ Nominal harus kelipatan 1.000!',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Coba Lagi', 'owner_cairkan')]
                ]).reply_markup
            }
        );
        return;
    }

    await processCairkanInstant(ctx, nominal);
    delete activeSessions.lastCallback[userId];
    return;
}

// Handle pencarian produk H2H
if (lastCallback === 'h2h_search_products') {
    const keyword = userMessage.trim();
    
    if (keyword.length < 2) {
        await ctx.reply('❌ Kata kunci terlalu pendek! Minimal 2 karakter.');
        return;
    }

    const loadingMsg = await ctx.reply(`🔍 *Mencari "${keyword}"...*`, {
        parse_mode: 'Markdown'
    });

    try {
        const res = await axios.get("https://www.rumahotp.com/api/v1/h2h/product", {
            headers: { "x-apikey": config.RUMAHOTP_API_KEY }
        });

        let products = res.data.data || [];
        products = products.sort((a, b) => a.price - b.price);

        const result = products.filter(p =>
            p.name.toLowerCase().includes(keyword.toLowerCase()) ||
            p.brand.toLowerCase().includes(keyword.toLowerCase()) ||
            p.note.toLowerCase().includes(keyword.toLowerCase()) ||
            p.code.toLowerCase().includes(keyword.toLowerCase())
        );

        await ctx.deleteMessage(loadingMsg.message_id);

        if (result.length === 0) {
            await ctx.reply(
                `❌ Tidak ada produk ditemukan untuk "*${keyword}*"`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔍 Cari Lagi', 'h2h_search_manual')],
                        [Markup.button.callback('🔙 Kategori', 'owner_h2h_products')]
                    ]).reply_markup
                }
            );
            return;
        }

        // Tampilkan hasil pencarian
        const pageSize = 5;
        const totalPages = Math.ceil(result.length / pageSize);
        
        global.h2hPages[ctx.chat.id] = {
            keyword: keyword,
            result: result,
            pageSize: pageSize,
            totalPages: totalPages
        };

        sendH2HPage(bot, ctx.chat.id, 1);

    } catch (error) {
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Gagal mencari produk!\nError: ${error.message}`,
            { parse_mode: 'Markdown' }
        );
    }

    delete activeSessions.lastCallback[userId];
    return;
}

// Handle proses cairkan saldo
if (lastCallback === 'process_cairkan') {
    const nominal = userMessage.trim();
    
    if (!nominal || isNaN(nominal) || parseInt(nominal) < 1000) {
        await ctx.reply(
            '❌ Nominal tidak valid! Minimal Rp1.000 dan harus angka.',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Coba Lagi', 'owner_cairkan')]
                ]).reply_markup
            }
        );
        return;
    }

    await processCairkanSaldo(ctx, nominal);
    delete activeSessions.lastCallback[userId];
    return;
}

// Handle proses H2H order
if (lastCallback === 'process_h2h_order') {
    const parts = userMessage.trim().split(' ');
    
    if (parts.length < 2) {
        await ctx.reply(
            '❌ Format salah! Gunakan: `KODE_PRODUK NOMOR_TUJUAN`',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Coba Lagi', 'owner_h2h_order')]
                ]).reply_markup
            }
        );
        return;
    }

    const code = parts[0];
    const target = parts.slice(1).join(' ');

    // Proses order H2H
    await processH2HOrder(ctx, code, target);
    delete activeSessions.lastCallback[userId];
    return;
}

    // ✅ PERBAIKAN: AI Customer Service - TANPA DEKLARASI ULANG userMessage
    if (lastCallback === 'ai_customer_service') {
        const userId = ctx.from.id;
        const username = ctx.from.username || 'User';
        
        if (userMessage.length > 500) {
            await ctx.reply(
                '❌ *Pertanyaan terlalu panjang!*\n\n' +
                'Silakan batasi pertanyaan maksimal 500 karakter.',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🤖 Coba Lagi', 'ai_customer_service')]
                    ]).reply_markup
                }
            );
            return;
        }

        // Tampilkan pesan sedang memproses
        const processingMsg = await ctx.reply('🔄 *AI sedang memproses pertanyaan Anda...*', {
            parse_mode: 'Markdown'
        });

        try {
            // Proses pertanyaan dengan AI
            const aiResult = await aiCustomerService.handleCustomerQuery(userId, userMessage, username);
            
            // Hapus pesan processing
            await ctx.deleteMessage(processingMsg.message_id);
            
            if (aiResult.success) {
                // Kirim respon AI ke user
                await ctx.reply(
                    `🤖 *AI Customer Service*\n\n` +
                    `❓ *Pertanyaan Anda:*\n${userMessage}\n\n` +
                    `💬 *Jawaban AI:*\n${aiResult.response}\n\n` +
                    `${aiResult.requiresHuman ? '🚨 *Untuk pertanyaan lebih lanjut, silakan hubungi admin @KingStoreGanteng*' : '💫 *Semoga membantu!*'}`,
                    {
                        parse_mode: 'Markdown',
                        reply_markup: Markup.inlineKeyboard([
                            [Markup.button.callback('🔄 Tanya Lagi', 'ai_customer_service')],
                            [Markup.button.callback('🗑️ Hapus Riwayat', 'clear_ai_history')],
                            [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                        ]).reply_markup
                    }
                );

                // Kirim notifikasi ke owner
                await aiCustomerService.notifyOwnerAboutAIQuery(
                    userId, 
                    userMessage, 
                    aiResult.response, 
                    aiResult.requiresHuman, 
                    username
                );

            } else {
                // Fallback jika AI gagal
                await ctx.reply(
                    `❌ *Maaf, AI sedang mengalami gangguan*\n\n` +
                    `Silakan hubungi admin langsung di @KingStoreGanteng untuk bantuan.\n\n` +
                    `Pertanyaan Anda: ${userMessage}`,
                    {
                        parse_mode: 'Markdown',
                        reply_markup: Markup.inlineKeyboard([
                            [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                        ]).reply_markup
                    }
                );
            }

        } catch (error) {
            // Error handling
            await ctx.deleteMessage(processingMsg.message_id);
            
            await ctx.reply(
                `❌ *Terjadi kesalahan sistem*\n\n` +
                `Silakan hubungi admin @KingStoreGanteng untuk bantuan.\n\n` +
                `Error: ${error.message}`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
            
            console.error('❌ AI Customer Service Error:', error);
        }

        // Jangan hapus callback agar user bisa terus chat
        return;
    }

    // Handle custom deposit
    if (lastCallback === 'deposit_custom') {
        const amount = parseInt(userMessage);
        if (isNaN(amount) || amount < config.MIN_DEPOSIT) {
            await ctx.reply(
                `❌ *Nominal tidak valid!*\n\n` +
                `Silakan masukkan angka minimal ${config.MIN_DEPOSIT}.\n` +
                `Contoh: \`5000\` untuk deposit Rp5,000`,
                { 
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'deposit_menu')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }
        
        const processingMsg = await ctx.reply('🔄 *Mengatur deposit custom...*', {
            parse_mode: 'Markdown'
        });

        const dots = ['', '.', '..', '...'];
        let dotIndex = 0;
        const progressInterval = setInterval(async () => {
            try {
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    processingMsg.message_id,
                    undefined,
                    `🔄 *Mengatur deposit custom${dots[dotIndex]}*\n\n` +
                    `💵 Nominal: Rp${utils.formatNumber(amount)}`,
                    { parse_mode: 'Markdown' }
                );
                dotIndex = (dotIndex + 1) % dots.length;
            } catch (error) {
                clearInterval(progressInterval);
            }
        }, 500);

        await new Promise(resolve => setTimeout(resolve, 1500));
        clearInterval(progressInterval);

        await ctx.deleteMessage(processingMsg.message_id);
        await processDeposit(ctx, amount);
        delete activeSessions.lastCallback[userId];
        return;
    }

    // Handle voucher usage
    if (lastCallback === 'use_voucher') {
        const code = userMessage.toUpperCase().trim();
        
        const processingMsg = await ctx.reply('🔄 *Memproses voucher...*', {
            parse_mode: 'Markdown'
        });

        let progress = 0;
        const progressInterval = setInterval(async () => {
            try {
                progress += 20;
                if (progress > 100) progress = 100;
                
                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    processingMsg.message_id,
                    undefined,
                    `🔄 *Memproses voucher...*\n\n` +
                    `🎫 Kode: ${code}\n` +
                    `📊 Progress: ${progress}%`,
                    { parse_mode: 'Markdown' }
                );
                
                if (progress >= 100) {
                    clearInterval(progressInterval);
                }
            } catch (error) {
                clearInterval(progressInterval);
            }
        }, 400);

        await new Promise(resolve => setTimeout(resolve, 1000));
        clearInterval(progressInterval);

        const voucher = db.getVoucher(code);
        
        if (!voucher) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                processingMsg.message_id,
                undefined,
                `❌ *VOUCHER TIDAK VALID!*\n\n` +
                `Kode voucher tidak ditemukan.\n` +
                `Pastikan kode yang dimasukkan benar.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        if (voucher.maxUsage > 0 && voucher.usedCount >= voucher.maxUsage) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                processingMsg.message_id,
                undefined,
                `❌ *VOUCHER SUDAH HABIS!*\n\n` +
                `Kode voucher ini sudah mencapai batas penggunaan.\n` +
                `Silakan gunakan voucher lainnya.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        const success = db.useVoucher(code, ctx.from.id);
        if (success) {
            const user = await safeDbOperation(() => db.getUser(ctx.from.id), 'GET_USER_VOUCHER');
            user.balance += voucher.amount;
            await safeDbOperation(() => db.updateUser(ctx.from.id, user), 'UPDATE_USER_VOUCHER');

            await ctx.telegram.editMessageText(
                ctx.chat.id,
                processingMsg.message_id,
                undefined,
                `🎉 *VOUCHER BERHASIL DITUKARKAN!*\n\n` +
                `🎫 Kode: ${voucher.code}\n` +
                `💰 Bonus: Rp${utils.formatNumber(voucher.amount)}\n` +
                `💳 Saldo Baru: Rp${utils.formatNumber(user.balance)}\n` +
                `⏰ Waktu: ${utils.getIndonesianTime()}\n\n` +
                `Terima kasih telah menggunakan voucher kami! 🎁`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
        } else {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                processingMsg.message_id,
                undefined,
                `❌ *GAGAL MENGGUNAKAN VOUCHER!*\n\n` +
                `Silakan coba lagi atau hubungi admin.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'voucher_menu')]
                    ]).reply_markup
                }
            );
        }
        
        delete activeSessions.lastCallback[userId];
        return;
    }

    // Handle create voucher (admin only)
    if (lastCallback === 'create_voucher' && utils.isAdmin(userId)) {
        const parts = userMessage.split('|');
        if (parts.length < 2) {
            await ctx.reply(
                '❌ *Format salah!*\n\n' +
                'Gunakan format: `KODE|NOMINAL|MAX_USAGE`\n' +
                'Contoh: `WELCOME10|10000|50`',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_create_voucher')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        const code = parts[0].toUpperCase().trim();
        const amount = parseInt(parts[1]);
        const maxUsage = parts[2] ? parseInt(parts[2]) : 0;

        if (isNaN(amount) || amount <= 0) {
            await ctx.reply(
                '❌ *Nominal tidak valid!*\n' +
                'Nominal harus angka positif.',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_create_voucher')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        const existingVoucher = db.getVoucher(code);
        if (existingVoucher) {
            await ctx.reply(
                `❌ *Voucher sudah ada!*\n\n` +
                `Kode ${code} sudah digunakan.\n` +
                `Silakan gunakan kode yang berbeda.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_create_voucher')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        const voucher = {
            code: code,
            amount: amount,
            maxUsage: maxUsage,
            createdAt: Date.now(),
            used: false,
            usedBy: null,
            usedAt: null,
            usedCount: 0
        };

        const success = db.addVoucher(voucher);
        if (success) {
            await ctx.reply(
                `✅ *VOUCHER BERHASIL DIBUAT!*\n\n` +
                `🎫 Kode: ${code}\n` +
                `💰 Nominal: Rp${utils.formatNumber(amount)}\n` +
                `📊 Max Usage: ${maxUsage === 0 ? 'Unlimited' : maxUsage}\n` +
                `⏰ Dibuat: ${utils.getIndonesianTime()}\n\n` +
                `Voucher siap digunakan!`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🎫 Buat Lagi', 'owner_create_voucher')],
                        [Markup.button.callback('🔙 Owner Menu', 'ownermenu_back')]
                    ]).reply_markup
                }
            );
        } else {
            await ctx.reply(
                '❌ *Gagal membuat voucher!*\n' +
                'Silakan coba lagi.',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_create_voucher')]
                    ]).reply_markup
                }
            );
        }

        delete activeSessions.lastCallback[userId];
        return;
    }

    // Handle set price (admin only)
    if (lastCallback === 'set_price' && utils.isAdmin(userId)) {
        const percentage = parseInt(userMessage);
        if (isNaN(percentage) || percentage < 0 || percentage > 100) {
            await ctx.reply(
                '❌ *Persentase tidak valid!*\n\n' +
                'Silakan masukkan angka antara 0-100.\n' +
                'Contoh: `20` untuk 20% keuntungan',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_set_price')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        utils.setProfitPercentage(percentage);
        await ctx.reply(
            `✅ *KEUNTUNGAN BERHASIL DIUBAH!*\n\n` +
            `💰 Persentase Baru: ${percentage}%\n` +
            `⏰ Waktu: ${utils.getIndonesianTime()}\n\n` +
            `Semua harga akan disesuaikan dengan persentase ini.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'ownermenu_back')]
                ]).reply_markup
            }
        );

        delete activeSessions.lastCallback[userId];
        return;
    }

    // Handle change topup threshold (admin only)
    if (lastCallback === 'change_topup_threshold' && utils.isAdmin(userId)) {
        const threshold = parseInt(userMessage);
        if (isNaN(threshold) || threshold <= 0) {
            await ctx.reply(
                '❌ *Threshold tidak valid!*\n\n' +
                'Silakan masukkan angka positif.\n' +
                'Contoh: `50000` untuk Rp50,000',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'owner_auto_topup_settings')]
                    ]).reply_markup
                }
            );
            delete activeSessions.lastCallback[userId];
            return;
        }

        const settings = db.getSettings();
        settings.autoTopupAlert.threshold = threshold;
        db.updateSettings(settings);

        await ctx.reply(
            `✅ *THRESHOLD BERHASIL DIUBAH!*\n\n` +
            `💰 Threshold Baru: Rp${utils.formatNumber(threshold)}\n` +
            `⏰ Waktu: ${utils.getIndonesianTime()}\n\n` +
            `Sistem akan mengirim alert ketika saldo bot di bawah threshold ini.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Auto Top-up Settings', 'owner_auto_topup_settings')]
                ]).reply_markup
            }
        );

        delete activeSessions.lastCallback[userId];
        return;
    }

    // Di dalam bot.on('text') - tambahkan case untuk change_price_drop_delay
if (lastCallback === 'change_price_drop_delay' && utils.isAdmin(userId)) {
    const delayMinutes = parseInt(userMessage);
    if (isNaN(delayMinutes) || delayMinutes < 1) {
        await ctx.reply(
            '❌ *Delay tidak valid!*\n\n' +
            'Silakan masukkan angka minimal 1 menit.\n' +
            'Contoh: `5` untuk 5 menit',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Kembali', 'owner_price_drop_settings')]
                ]).reply_markup
            }
        );
        delete activeSessions.lastCallback[userId];
        return;
    }

    const settings = db.getSettings();
    settings.priceDropAlert.delayBetweenAlerts = delayMinutes * 60000; // Convert to milliseconds
    db.updateSettings(settings);

    await ctx.reply(
        `✅ *DELAY ALERT HARGA TURUN BERHASIL DIUBAH!*\n\n` +
        `⏰ Delay Baru: ${delayMinutes} menit\n` +
        `⏰ Waktu: ${utils.getIndonesianTime()}\n\n` +
        `Sistem akan menunggu ${delayMinutes} menit antara alert harga turun.`,
        {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Price Drop Settings', 'owner_price_drop_settings')]
            ]).reply_markup
        }
    );

    delete activeSessions.lastCallback[userId];
    return;
}

    // Jika tidak ada callback yang aktif
    console.log('❌ No active callback found for message:', userMessage);
    await ctx.reply(
        '🤔 Saya tidak mengerti perintah ini.\n\n' +
        'Gunakan menu yang tersedia atau ketik /start untuk memulai.',
        { parse_mode: 'Markdown' }
    );
}));

// ==================== PROCESS CAIRKAN INSTANT FUNCTION ====================
async function processCairkanInstant(ctx, nominal) {
    try {
        const userId = ctx.from.id;
        
        // Tampilkan loading
        await messageUtils.replyWithEdit(
            ctx,
            `💰 *Memproses pencairan Rp${utils.formatNumber(nominal)}...*`,
            Markup.inlineKeyboard([])
        );

        // Map nominal ke e-wallet
        const ewallet = config.type_ewallet_RUMAHOTP?.toLowerCase() || 'dana';
        const nomorTujuan = config.nomor_pencairan_RUMAHOTP;
        
        if (!nomorTujuan) {
            await messageUtils.replyWithEdit(
                ctx,
                '❌ *NOMOR TUJUAN TIDAK DIATUR!*\n\n' +
                'Silakan atur nomor pencairan di config.js terlebih dahulu.',
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }

        // Cari produk berdasarkan nominal
        const productRes = await axios.get("https://www.rumahotp.com/api/v1/h2h/product", {
            headers: { "x-apikey": config.RUMAHOTP_API_KEY }
        });

        const allProducts = productRes.data.data || [];
        
        // Mapping prefix berdasarkan e-wallet
        const prefixMap = {
            dana: "D",
            gopay: "GPY", 
            ovo: "OVO",
            shopeepay: "SHOPE",
            linkaja: "LINK"
        };

        const prefix = prefixMap[ewallet];
        if (!prefix) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ E-wallet "${ewallet}" tidak didukung!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }

        const filteredProducts = allProducts.filter(x => x.code.startsWith(prefix));
        
        // Cari produk yang sesuai dengan nominal
        const foundProduct = filteredProducts.find(x => {
            const angkaName = Number(String(x.name).replace(/\D/g, ""));
            const angkaNote = Number(String(x.note).replace(/\D/g, ""));
            return angkaName === nominal || angkaNote === nominal;
        });

        if (!foundProduct) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ Produk dengan nominal Rp${utils.formatNumber(nominal)} tidak ditemukan untuk ${ewallet.toUpperCase()}!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }

        const productCode = foundProduct.code;
        
        // Buat transaksi
        const url = `https://www.rumahotp.com/api/v1/h2h/transaksi/create?id=${productCode}&target=${nomorTujuan}`;
        const res = await axios.get(url, {
            headers: {
                "x-apikey": config.RUMAHOTP_API_KEY,
                "Accept": "application/json"
            }
        });

        if (!res.data.success) {
            await messageUtils.replyWithEdit(
                ctx,
                `❌ *Transaksi gagal!*\nPesan: ${res.data.message || "Tidak diketahui."}`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
                ])
            );
            return;
        }

        const transactionData = res.data.data;

        // Tampilkan informasi transaksi
        const transactionText = 
            `✅ *TRANSAKSI BERHASIL DIBUAT!*\n\n` +
            `💰 *Nominal:* Rp${utils.formatNumber(nominal)}\n` +
            `🏧 *E-Wallet:* ${ewallet.toUpperCase()}\n` +
            `📱 *Tujuan:* ${nomorTujuan}\n` +
            `🎫 *Produk:* ${transactionData.product?.name || '-'}\n` +
            `🏷️ *Brand:* ${transactionData.product?.brand || '-'}\n` +
            `🧩 *Kode:* \`${transactionData.product?.code || '-'}\`\n\n` +
            `📌 *Status Awal:* ${transactionData.status}\n` +
            `🆔 *ID Transaksi:* \`${transactionData.id}\`\n\n` +
            `⏳ *Sedang memantau status transaksi...*`;

        await messageUtils.replyWithEdit(
            ctx,
            transactionText,
            Markup.inlineKeyboard([])
        );

        // Mulai monitoring transaksi
        await monitorH2HOrder(ctx, null, transactionData.id);
        
    } catch (error) {
        console.error('Error in processCairkanInstant:', error);
        
        await messageUtils.replyWithEdit(
            ctx,
            `❌ *GAGAL MEMPROSES PENCAIRAN!*\n\n` +
            `Error: ${error.message}\n\n` +
            `Silakan coba lagi beberapa saat.`,
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Owner Menu', 'owner_menu_button')]
            ])
        );
    }
}

// Fungsi untuk proses H2H order instant
async function processH2HOrderInstant(ctx, productCode, targetNumber) {
    const loadingMsg = await ctx.reply(`💳 *Memproses order ${productCode}...*`, {
        parse_mode: 'Markdown'
    });

    try {
        // 🔥 CREATE TRANSAKSI LANGSUNG
        const url = `https://www.rumahotp.com/api/v1/h2h/transaksi/create?id=${productCode}&target=${targetNumber}`;
        const res = await axios.get(url, {
            headers: {
                "x-apikey": config.RUMAHOTP_API_KEY,
                "Accept": "application/json"
            }
        });

        if (!res.data.success) {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                loadingMsg.message_id,
                undefined,
                `❌ *Transaksi gagal!*\nPesan: ${res.data.message || "Tidak diketahui."}`,
                { parse_mode: 'Markdown' }
            );
            return;
        }

        const d = res.data.data;

        const initialText =
`✅ *Transaksi Berhasil Dibuat!*

🛒 *Produk:* ${d.product?.name || "-"}
🏷️ Brand: ${d.product?.brand || "-"}
🧩 Code: \`${d.product?.code || "-"}\`
📂 Kategori: ${d.product?.category || "-"}

🎯 *Tujuan:* ${d.tujuan}

📌 *Status Awal:* ${d.status}
🆔 *ID Transaksi:* \`${d.id}\`

⏳ *Sedang memantau status transaksi...*`;

        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            initialText,
            { parse_mode: 'Markdown' }
        );

        // 🔥 AUTO CHECK STATUS
        await monitorH2HOrder(ctx, loadingMsg.message_id, d.id);

    } catch (error) {
        console.error("H2H ORDER INSTANT ERROR:", error);
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Gagal memproses order!\nError: ${error.message}`,
            { parse_mode: 'Markdown' }
        );
    }
}

// Fungsi untuk proses cairkan saldo
async function processCairkanSaldo(ctx, nominal) {
    const loadingMsg = await ctx.reply(`💰 *Memproses pencairan Rp${nominal}...*`, {
        parse_mode: 'Markdown'
    });

    try {
        // Gunakan fungsi cairkan yang sudah ada
        await ctx.telegram.sendMessage(
            ctx.chat.id,
            `/cairkan ${nominal}`,
            { parse_mode: 'Markdown' }
        );
        
        await ctx.deleteMessage(loadingMsg.message_id);
    } catch (error) {
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Gagal memproses pencairan!\nError: ${error.message}`,
            { parse_mode: 'Markdown' }
        );
    }
}

// Fungsi untuk proses H2H order
async function processH2HOrder(ctx, code, target) {
    const loadingMsg = await ctx.reply(`💳 *Memproses order ${code}...*`, {
        parse_mode: 'Markdown'
    });

    try {
        // Gunakan fungsi orderh2h yang sudah ada
        await ctx.telegram.sendMessage(
            ctx.chat.id,
            `/orderh2h ${code} ${target}`,
            { parse_mode: 'Markdown' }
        );
        
        await ctx.deleteMessage(loadingMsg.message_id);
    } catch (error) {
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            loadingMsg.message_id,
            undefined,
            `❌ Gagal memproses order!\nError: ${error.message}`,
            { parse_mode: 'Markdown' }
        );
    }
}

// ==================== MONITOR DEPOSIT STATUS FUNCTION ====================
async function monitorDepositStatus(trxId) {
    const session = activeSessions.deposits[trxId];
    if (!session) return;

    const maxChecks = 120; // 10 menit (120 x 5 detik)
    let checkCount = 0;

    const checkInterval = setInterval(async () => {
        try {
            if (checkCount >= maxChecks) {
                clearInterval(checkInterval);
                console.log(`⏰ Deposit monitoring stopped for ${trxId} after ${maxChecks} checks`);
                return;
            }

            checkCount++;

            let statusResult;
            if (session.method === 'atlantic') {
                statusResult = await api.atlantich2h.checkDepositStatus(trxId);
            } else {
                statusResult = await api.rumahotp.checkDepositStatus(session.depositId || trxId);
            }

            if (statusResult?.success) {
                const status = statusResult.data?.status || 'pending';
                
                if (status === 'success' || status === 'paid' || status === 'completed') {
                    clearInterval(checkInterval);
                    await handleDepositSuccess(trxId, session, statusResult.data);
                    return;
                }
                
                // Update status di tampilan
                if (session.ctx && session.messageId) {
                    try {
                        const timeLeft = (session.startTime + (10 * 60 * 1000)) - Date.now();
                        const countdownText = utils.formatCountdown(timeLeft);
                        const minutesLeft = Math.ceil(timeLeft / (60 * 1000));
                        
                        const caption = 
                            `💳 *DETAIL PEMBAYARAN*\n\n` +
                            `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
                            `📦 *Biaya Admin:* Rp${utils.formatNumber(session.adminFee)}\n` +
                            `💠 *Total Bayar:* Rp${utils.formatNumber(session.totalAmount)}\n` +
                            `📊 *Status:* ${status.toUpperCase()}\n` +
                            `🆔 *Ref ID:* ${session.reffId}\n` +
                            `📲 *Scan QR Code di bawah ini:*\n` +
                            `⏰ *Kadaluarsa dalam:* ${countdownText}\n` +
                            `⏳ *Bisa dibatalkan dalam ${minutesLeft} menit*\n\n` +
                            `🔄 *Status akan diperiksa otomatis*`;

                        await session.ctx.telegram.editMessageCaption(
                            session.ctx.chat.id,
                            session.messageId,
                            undefined,
                            caption,
                            {
                                parse_mode: 'Markdown',
                                reply_markup: Markup.inlineKeyboard([
                                    [
                                        Markup.button.callback('🔄 Cek Status', `check_deposit_${trxId}`),
                                        Markup.button.callback('❌ Batalkan', `cancel_deposit_${trxId}`)
                                    ],
                                    [Markup.button.callback('🔙 Menu', 'main_menu')]
                                ]).reply_markup
                            }
                        );
                    } catch (error) {
                        // Ignore edit errors
                    }
                }
            }

        } catch (error) {
            console.error(`❌ Error checking deposit status for ${trxId}:`, error.message);
            
            if (checkCount >= maxChecks) {
                clearInterval(checkInterval);
            }
        }
    }, 5000); // Check every 5 seconds
}

// ==================== HANDLE DEPOSIT SUCCESS FUNCTION ====================
async function handleDepositSuccess(trxId, session, statusData) {
    try {
        // Update transaction status in database
        await safeDbOperation(() => db.updateTransactionStatus(trxId, 'success'), 'UPDATE_TRANSACTION_SUCCESS');
        
        // Update user balance
        const user = await safeDbOperation(() => db.getUser(session.userId), 'GET_USER_DEPOSIT_SUCCESS');
        user.balance += session.nominal;
        user.totalDeposit = (user.totalDeposit || 0) + 1;
        await safeDbOperation(() => db.updateUser(session.userId, user), 'UPDATE_USER_DEPOSIT_BALANCE');
        
        // Cleanup
        depositCountdownUtils.cancelDepositCountdown(trxId);
        lockUtils.releaseUserLock(session.userId);
        delete activeSessions.deposits[trxId];
        
        // Send success notification to user
        await session.ctx.reply(
            `✅ *DEPOSIT BERHASIL!*\n\n` +
            `💰 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
            `💳 *Saldo Baru:* Rp${utils.formatNumber(user.balance)}\n` +
            `🆔 *Ref ID:* ${session.reffId}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `Saldo telah ditambahkan. Selamat berbelanja! 🛍️`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('📱 Order Nokos', 'order_nokos')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
        
        // Send notification to owner
        await notifyOwnerDepositSuccess(session, session.ctx.from);
        
        console.log(`✅ Deposit success for user ${session.userId}, amount: Rp${session.nominal}`);
        
    } catch (error) {
        console.error('❌ Error handling deposit success:', error);
    }
}

async function processDepositCompletion(session, trxId, statusData) {
    try {
        console.log(`💰 Processing deposit completion: ${trxId}`);
        
        // 1. HAPUS PESAN QRIS
        await deleteDepositMessage(session.ctx, session.messageId);
        
        // 2. Update transaction status
        await safeDbOperation(() => db.updateTransactionStatus(trxId, 'completed'), 'UPDATE_TRX_COMPLETED');
        
        // 3. Get user data
        const user = await safeDbOperation(() => db.getUser(session.userId), 'GET_USER_FOR_DEPOSIT');
        
        // 4. ANTI DOUBLE: Verify transaction status again
        const verifiedTrx = await safeDbOperation(() => {
            const data = db.load();
            return Object.values(data.transactions).find(t => t.trxId === trxId);
        }, 'VERIFY_TRX_AFTER_UPDATE');
        
        if (!verifiedTrx || verifiedTrx.status !== 'completed') {
            throw new Error('Transaction status verification failed');
        }
        
        // 5. Update user balance ONLY if not already updated
        const oldBalance = user.balance;
        user.balance += session.nominal;
        user.totalDeposit += 1;
        
        await safeDbOperation(() => db.updateUser(session.userId, user), 'UPDATE_USER_BALANCE');
        
        console.log(`✅ Deposit ${trxId} completed: ${oldBalance} -> ${user.balance}`);
        
        // 6. KIRIM PESAN BARU - DEPOSIT BERHASIL
        await sendSingleDepositNotification(session, trxId, user);
        
    } catch (error) {
        console.error(`❌ Deposit completion error for ${trxId}:`, error);
    } finally {
        lockUtils.releaseUserLock(session.userId);
        delete activeSessions.deposits[trxId];
    }
}

async function processDepositFailure(session, trxId, status) {
    try {
        // HAPUS PESAN QRIS
        await deleteDepositMessage(session.ctx, session.messageId);
        
        // Update transaction status
        await safeDbOperation(() => db.updateTransactionStatus(trxId, status), 'UPDATE_TRX_FAILED');
        
        // KIRIM PESAN BARU - DEPOSIT GAGAL
        const failedMessage = 
            `❌ *DEPOSIT GAGAL*\n\n` +
            `💵 Nominal: Rp${utils.formatNumber(session.nominal)}\n` +
            `📦 Biaya Admin: Rp${utils.formatNumber(session.adminFee)}\n` +
            `💠 Total Bayar: Rp${utils.formatNumber(session.totalAmount)}\n` +
            `📊 Status: ${status.toUpperCase()}\n` +
            `🆔 Ref ID: ${session.reffId}\n\n` +
            `Deposit telah dibatalkan atau gagal.\n` +
            `Silakan buat deposit baru jika masih ingin melanjutkan.`;

        await session.ctx.reply(failedMessage, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('💳 Deposit Lagi', 'deposit_menu')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ]).reply_markup
        });
        
    } catch (error) {
        console.error(`❌ Deposit failure error for ${trxId}:`, error);
    } finally {
        lockUtils.releaseUserLock(session.userId);
        delete activeSessions.deposits[trxId];
    }
}

async function handleExpiredDeposit(session, trxId) {
    try {
        // HAPUS PESAN QRIS
        await deleteDepositMessage(session.ctx, session.messageId);
        
        // Update transaction status
        await safeDbOperation(() => db.updateTransactionStatus(trxId, 'expired'), 'UPDATE_TRANSACTION_EXPIRED');
        
        // KIRIM PESAN BARU - DEPOSIT EXPIRED
        await session.ctx.reply(
            `⏰ *WAKTU PEMBAYARAN HABIS*\n\n` +
            `💵 Nominal: Rp${utils.formatNumber(session.nominal)}\n` +
            `📦 Biaya Admin: Rp${utils.formatNumber(session.adminFee)}\n` +
            `💠 Total Bayar: Rp${utils.formatNumber(session.totalAmount)}\n` +
            `🆔 Ref ID: ${session.reffId}\n\n` +
            `Deposit telah kadaluarsa.\n` +
            `QR Code tidak lagi valid.\n\n` +
            `Silakan buat deposit baru jika masih ingin melanjutkan.`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('💳 Deposit Lagi', 'deposit_menu')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
        
    } catch (error) {
        console.error(`❌ Expired deposit error for ${trxId}:`, error);
    } finally {
        lockUtils.releaseUserLock(session.userId);
        delete activeSessions.deposits[trxId];
    }
}

// Helper function untuk menghapus pesan deposit
async function deleteDepositMessage(ctx, messageId) {
    try {
        if (messageId) {
            await ctx.deleteMessage(messageId);
            console.log(`🗑️ Deleted deposit QRIS message: ${messageId}`);
        }
    } catch (error) {
        // Ignore delete errors (message mungkin sudah dihapus)
        console.log('⚠️ Cannot delete deposit message (might be already deleted)');
    }
}

async function sendSingleDepositNotification(session, trxId, user) {
    try {
        // ANTI SPAM: Check if notification already sent
        const notificationKey = `notif_${trxId}`;
        if (activeSessions.notifications && activeSessions.notifications[notificationKey]) {
            console.log(`📨 Notification already sent for ${trxId}, skipping...`);
            return;
        }
        
        // Mark notification as sent
        if (!activeSessions.notifications) activeSessions.notifications = {};
        activeSessions.notifications[notificationKey] = true;
        
        const successMessage = 
            `✅ *DEPOSIT BERHASIL!*\n\n` +
            `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
            `📦 *Biaya Admin:* Rp${utils.formatNumber(session.adminFee)}\n` +
            `💠 *Total Bayar:* Rp${utils.formatNumber(session.totalAmount)}\n` +
            `💰 *Saldo Bertambah:* Rp${utils.formatNumber(session.nominal)}\n` +
            `💳 *Saldo Sekarang:* Rp${utils.formatNumber(user.balance)}\n` +
            `🆔 *Ref ID:* ${session.reffId}\n` +
            `🕒 *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `🎉 *Terima kasih! Saldo telah ditambahkan.*`;

        await session.ctx.reply(successMessage, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('💰 Cek Saldo', 'check_balance')],
                [Markup.button.callback('📱 Order Nokos', 'order_nokos')],
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ]).reply_markup
        });

        // Send owner notification (also with anti-spam)
        await sendSingleOwnerNotification(session, user);
        
    } catch (error) {
        console.error(`❌ Notification error for ${trxId}:`, error);
    }
}

async function sendSingleOwnerNotification(session, user) {
    try {
        const ownerNotifKey = `owner_notif_${session.reffId}`;
        if (activeSessions.notifications && activeSessions.notifications[ownerNotifKey]) {
            return;
        }
        
        if (!activeSessions.notifications) activeSessions.notifications = {};
        activeSessions.notifications[ownerNotifKey] = true;
        
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const fullName = [user.first_name, user.last_name].filter(Boolean).join(' ') || 'Unknown';
        
        const message = 
            `💰 *DEPOSIT BERHASIL - NOTIFIKASI OWNER*\n\n` +
            `👤 *User ID:* ${user.id}\n` +
            `📧 *Username:* ${username}\n` +
            `👤 *Nama:* ${fullName}\n` +
            `💵 *Nominal:* Rp${utils.formatNumber(session.nominal)}\n` +
            `📦 *Biaya Admin:* Rp${utils.formatNumber(session.adminFee)}\n` +
            `💠 *Total Bayar:* Rp${utils.formatNumber(session.totalAmount)}\n` +
            `🆔 *Ref ID:* ${session.reffId}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `✅ *Status:* Deposit berhasil dan saldo telah ditambahkan`;

        await bot.telegram.sendMessage(
            config.OWNER_ID,
            message,
            { parse_mode: 'Markdown' }
        );
        
    } catch (error) {
        console.error('❌ Owner notification error:', error);
    }
}

// Handler untuk check deposit status - KIRIM PESAN BARU
bot.action(/check_deposit_(.+)/, createBulletproofHandler('CHECK_DEPOSIT', async (ctx) => {
    await ctx.answerCbQuery();
    const trxId = ctx.match[1];
    
    try {
        const session = activeSessions.deposits[trxId];
        if (!session) {
            await ctx.reply(
                '❌ *Transaksi tidak ditemukan atau sudah selesai.*',
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
            return;
        }

        let statusResult;
        if (session.method === 'atlantic') {
            statusResult = await api.atlantich2h.checkDepositStatus(trxId);
        } else {
            statusResult = await api.rumahotp.checkDepositStatus(session.depositId || trxId);
        }

        if (statusResult && statusResult.success) {
            const statusData = statusResult.data || {};
            const status = statusData.status?.toLowerCase() || 'pending';
            
            let statusText = '';
            let keyboard = [];
            
            if (status === 'success' || status === 'paid' || status === 'completed') {
                statusText = `🔄 *Status Deposit Masih Diproses*\n\n` +
                           `📊 Status: ${status.toUpperCase()}\n` +
                           `💵 Nominal: Rp${utils.formatNumber(session.nominal)}\n` +
                           `🆔 Ref ID: ${session.reffId}\n\n` +
                           `Sistem sedang memverifikasi pembayaran Anda...`;
                keyboard = [
                    [Markup.button.callback('🔄 Refresh Status', `check_deposit_${trxId}`)],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ];
            } else {
                statusText = `📊 *STATUS DEPOSIT*\n\n` +
                           `💵 Nominal: Rp${utils.formatNumber(session.nominal)}\n` +
                           `📦 Biaya Admin: Rp${utils.formatNumber(session.adminFee)}\n` +
                           `💠 Total Bayar: Rp${utils.formatNumber(session.totalAmount)}\n` +
                           `📊 Status: ${status.toUpperCase()}\n` +
                           `🆔 Ref ID: ${session.reffId}\n\n` +
                           `Status deposit Anda saat ini: ${status.toUpperCase()}`;
                keyboard = [
                    [Markup.button.callback('🔄 Refresh Status', `check_deposit_${trxId}`)],
                    [Markup.button.callback('❌ Batalkan', `cancel_deposit_${trxId}`)],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ];
            }

            await ctx.reply(statusText, {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
            });
            
        } else {
            await ctx.reply(
                `❌ *Gagal Memeriksa Status*\n\n` +
                `Tidak dapat memeriksa status deposit.\n` +
                `Silakan coba lagi beberapa saat.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔄 Coba Lagi', `check_deposit_${trxId}`)],
                        [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                    ]).reply_markup
                }
            );
        }
        
    } catch (error) {
        console.error('❌ Error in CHECK_DEPOSIT:', error.message);
        await ctx.reply(
            '❌ *Terjadi kesalahan saat memeriksa status.*\n\nSilakan coba lagi.',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ]).reply_markup
            }
        );
    }
}));

// ==================== MONITOR ORDER STATUS FUNCTION ====================
async function monitorOrderStatus(ctx, orderId, dbOrderId) {
    const maxChecks = 60; // 5 menit (60 x 5 detik)
    let checkCount = 0;

    const interval = setInterval(async () => {
        try {
            if (checkCount >= maxChecks) {
                clearInterval(interval);
                console.log(`⏰ Order monitoring stopped for ${orderId} after ${maxChecks} checks`);
                return;
            }

            checkCount++;

            const statusResult = await api.rumahotp.getOrderStatus(orderId);
            
            if (statusResult?.success) {
                const hasOTP = statusResult.data?.otp_code && 
                              statusResult.data.otp_code !== '-' && 
                              statusResult.data.otp_code !== '';
                
                if (hasOTP) {
                    clearInterval(interval);
                    autoCancelUtils.cancelAutoCancel(orderId);
                    await handleOrderSuccess(ctx, orderId, dbOrderId, statusResult.data);
                    return;
                }
                
                // Update status display
                const timeLeft = (Date.now() - (checkCount * 5000)) + (5 * 60 * 1000);
                const totalSeconds = Math.max(0, Math.floor(timeLeft / 1000));
                const minutes = Math.floor(totalSeconds / 60);
                const seconds = totalSeconds % 60;
                const countdownText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                const orderData = await safeDbOperation(() => {
                    const data = db.load();
                    return Object.values(data.orders).find(o => o.orderId === orderId);
                }, 'LOAD_ORDER_STATUS');
                
                if (orderData && ctx.callbackQuery?.message?.message_id) {
                    try {
                        const messageText = 
                            `✅ *ORDER BERHASIL DIBUAT*\n\n` +
                            `📱 *Nomor:* \`${orderData.phoneNumber}\`\n` +
                            `🛍️ *Layanan:* ${orderData.service}\n` +
                            `🌍 *Negara:* ${orderData.country}\n` +
                            `💰 *Harga:* Rp${utils.formatNumber(orderData.finalPrice)}\n` +
                            `⏰ *Kadaluarsa dalam:* ${countdownText}\n\n` +
                            `🆔 *Order ID:* ${orderId}\n\n` +
                            `📞 *Tunggu SMS OTP masuk...*\n` +
                            `🔄 *Status dipantau otomatis*`;
                        
                        await ctx.telegram.editMessageText(
                            ctx.chat.id,
                            ctx.callbackQuery.message.message_id,
                            undefined,
                            messageText,
                            { parse_mode: 'Markdown' }
                        );
                    } catch (error) {
                        // Ignore edit errors
                    }
                }
            }

        } catch (error) {
            console.error(`❌ Error monitoring order ${orderId}:`, error.message);
            
            if (checkCount >= maxChecks) {
                clearInterval(interval);
            }
        }
    }, 5000); // Check every 5 seconds
}

// ==================== HANDLE ORDER SUCCESS FUNCTION ====================
async function handleOrderSuccess(ctx, orderId, dbOrderId, orderData) {
    try {
        // Update order status in database
        await safeDbOperation(() => db.updateOrderStatus(orderId, 'completed'), 'UPDATE_ORDER_COMPLETED');
        
        // Update user data
        const data = await safeDbOperation(() => db.load(), 'LOAD_ORDER_SUCCESS_DATA');
        const order = data.orders[dbOrderId];
        
        if (order && order.userId) {
            const user = data.users[order.userId];
            if (user) {
                // Update user stats
                const newLevel = utils.calculateLevel(user.totalOrders + 1);
                if (newLevel !== user.level) {
                    user.level = newLevel;
                }
                
                await safeDbOperation(() => db.save(data), 'SAVE_ORDER_SUCCESS');
            }
        }
        
        // Send OTP to user
        const otpMessage = 
            `🎉 *OTP DITERIMA!*\n\n` +
            `📱 *Nomor:* ${orderData.phone_number}\n` +
            `🔑 *Kode OTP:* \`${orderData.otp_code}\`\n` +
            `🛍️ *Layanan:* ${order.service || 'Unknown'}\n` +
            `🌍 *Negara:* ${order.country || 'Unknown'}\n` +
            `💰 *Harga:* Rp${utils.formatNumber(order.finalPrice)}\n\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `✅ *Order selesai!* Silakan gunakan kode OTP di atas.`;
        
        await ctx.reply(otpMessage, { parse_mode: 'Markdown' });
        
        // Release user lock
        lockUtils.releaseUserLock(ctx.from.id);
        
        console.log(`✅ Order ${orderId} completed successfully with OTP`);
        
    } catch (error) {
        console.error(`❌ Error handling order success for ${orderId}:`, error);
    }
}

// ==================== PROCESS AUTO REFUND FUNCTION ====================
async function processAutoRefund(orderId, dbOrderId, userId, reason = 'Auto cancel') {
    try {
        // Cek apakah sudah dalam proses refund
        if (autoCancelUtils.refundLocks.has(orderId)) {
            console.log(`⚠️ Refund already in progress for order ${orderId}`);
            return false;
        }

        // Lock refund process
        autoCancelUtils.refundLocks.add(orderId);

        const data = await safeDbOperation(() => db.load(), 'LOAD_REFUND_DATA');
        const order = data.orders[dbOrderId];
        
        if (!order) {
            console.error(`❌ Order ${orderId} not found in database`);
            autoCancelUtils.refundLocks.delete(orderId);
            return false;
        }

        // Update order status
        order.status = 'refunded';
        order.refundReason = reason;
        order.refundedAt = Date.now();
        
        // Refund saldo ke user
        const user = data.users[userId.toString()];
        if (user) {
            user.balance += order.finalPrice;
            
            // Notify user about refund
            try {
                await bot.telegram.sendMessage(
                    userId,
                    `🔄 *ORDER DIBATALKAN - REFUND DITERIMA*\n\n` +
                    `📱 *Nomor:* ${order.phoneNumber || 'N/A'}\n` +
                    `🛍️ *Layanan:* ${order.service}\n` +
                    `💰 *Jumlah Refund:* Rp${utils.formatNumber(order.finalPrice)}\n` +
                    `💳 *Saldo Sekarang:* Rp${utils.formatNumber(user.balance)}\n` +
                    `📝 *Alasan:* ${reason}\n\n` +
                    `Saldo telah dikembalikan. Silakan order kembali!`,
                    { parse_mode: 'Markdown' }
                );
            } catch (error) {
                console.error(`❌ Error notifying user about refund:`, error.message);
            }
        }

        // Save changes
        await safeDbOperation(() => db.save(data), 'SAVE_REFUND_DATA');
        
        // Notify owner
        try {
            await bot.telegram.sendMessage(
                config.OWNER_ID,
                `🔄 *AUTO REFUND - ${orderId}*\n\n` +
                `👤 User: ${userId}\n` +
                `💰 Amount: Rp${utils.formatNumber(order.finalPrice)}\n` +
                `📝 Reason: ${reason}\n` +
                `⏰ Time: ${utils.getIndonesianTime()}`,
                { parse_mode: 'Markdown' }
            );
        } catch (error) {
            console.error('Error sending refund notification to owner:', error);
        }

        console.log(`✅ Auto refund completed for order ${orderId}`);
        autoCancelUtils.refundLocks.delete(orderId);
        return true;

    } catch (error) {
        console.error(`❌ Error in processAutoRefund for order ${orderId}:`, error);
        autoCancelUtils.refundLocks.delete(orderId);
        return false;
    }
}

// Function untuk mengirim notifikasi OTP sukses ke channel
async function sendOrderSuccessNotification(ctx, orderData, otpCode) {
    try {
        const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada username';
        const fullName = [ctx.from.first_name, ctx.from.last_name].filter(Boolean).join(' ') || 'Unknown';
        const maskedPhone = utils.maskPhone(orderData.phoneNumber);
        
        const notificationText = 
            `🎉 *TRANSAKSI NOKOS BERHASIL!*\n\n` +
            `👤 *User:* ${fullName} (${username})\n` +
            `📱 *Nomor:* ${maskedPhone}\n` +
            `🧾 *Layanan:* ${orderData.service}\n` +
            `🔢 *OTP:* \`${otpCode}\`\n` +
            `💰 *Harga:* Rp${utils.formatNumber(orderData.finalPrice)}\n` +
            `⏰ *Waktu:* ${utils.getIndonesianTime()}\n\n` +
            `✅ *Status:* OTP berhasil dikirim ke user`;

        await bot.telegram.sendMessage(
            config.DONE_CHANNEL,
            notificationText,
            { parse_mode: 'Markdown' }
        );

        console.log(`📢 Notifikasi berhasil dikirim ke channel: ${otpCode}`);

    } catch (error) {
        console.error('❌ Error sending success notification:', error);
    }
}

// ==================== DEPOSIT HISTORY FUNCTION ====================
async function showDepositHistory(ctx) {
    try {
        const userId = ctx.from.id;
        const data = await safeDbOperation(() => db.load(), 'LOAD_DEPOSIT_HISTORY');
        
        // Ambil semua transaksi deposit user
        const userDeposits = Object.values(data.transactions || {})
            .filter(trx => trx.userId === userId.toString() && trx.type === 'deposit')
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, 10); // Limit 10 deposit terbaru

        if (userDeposits.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                `💳 *RIWAYAT DEPOSIT*\n\n` +
                `Belum ada riwayat deposit.\n\n` +
                `Lakukan deposit pertama Anda untuk mulai order nokos!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('💳 DEPOSIT', 'deposit_menu')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            return;
        }

        let historyText = `💳 *RIWAYAT DEPOSIT*\n\n`;
        historyText += `Total Deposit: ${userDeposits.length}\n\n`;

        userDeposits.forEach((deposit, index) => {
            const time = new Date(deposit.createdAt).toLocaleString('id-ID');
            const statusEmoji = deposit.status === 'success' ? '✅' : 
                               deposit.status === 'pending' ? '🟡' : '❌';
            
            historyText += `${statusEmoji} *Deposit #${index + 1}*\n`;
            historyText += `💰 Nominal: Rp${utils.formatNumber(deposit.amount)}\n`;
            historyText += `📦 Admin Fee: Rp${utils.formatNumber(deposit.adminFee || 0)}\n`;
            historyText += `💠 Total: Rp${utils.formatNumber(deposit.totalAmount || deposit.amount)}\n`;
            historyText += `📅 ${time}\n`;
            historyText += `📊 Status: ${deposit.status}\n`;
            historyText += `🆔 Ref: ${deposit.reffId?.substring(0, 12)}...\n`;
            historyText += `━━━━━━━━━━━━━━━━━━\n`;
        });

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🔄 Refresh', 'deposit_history')],
            [Markup.button.callback('💳 Deposit Lagi', 'deposit_menu')],
            [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
        ]);

        await messageUtils.replyWithEdit(ctx, historyText, keyboard);
        
    } catch (error) {
        console.error('Error showing deposit history:', error);
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Gagal memuat riwayat deposit.*\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// ==================== ORDER HISTORY FUNCTION ====================
async function showOrderHistory(ctx) {
    try {
        const userId = ctx.from.id;
        const user = await safeDbOperation(() => db.getUser(userId), 'GET_USER_ORDER_HISTORY');
        const data = await safeDbOperation(() => db.load(), 'LOAD_ORDER_HISTORY');
        
        // Ambil semua order user
        const userOrders = Object.values(data.orders || {})
            .filter(order => order.userId === userId.toString())
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, 10); // Limit 10 order terbaru

        if (userOrders.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                `📋 *RIWAYAT ORDER NOKOS*\n\n` +
                `Belum ada riwayat order.\n\n` +
                `Mulai order pertama Anda dengan menekan tombol "ORDER NOKOS"!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('📱 ORDER NOKOS', 'order_nokos')],
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            return;
        }

        let historyText = `📋 *RIWAYAT ORDER NOKOS*\n\n`;
        historyText += `Total Order: ${userOrders.length}\n\n`;

        userOrders.forEach((order, index) => {
            const time = new Date(order.createdAt).toLocaleString('id-ID');
            const statusEmoji = order.status === 'active' ? '🟢' : 
                              order.status === 'completed' ? '✅' : 
                              order.status === 'refunded' ? '🔄' : '❌';
            
            historyText += `${statusEmoji} *Order #${index + 1}*\n`;
            historyText += `📱 ${order.phoneNumber || 'N/A'}\n`;
            historyText += `🛍️ ${order.service}\n`;
            historyText += `🌍 ${order.country}\n`;
            historyText += `💰 Rp${utils.formatNumber(order.finalPrice)}\n`;
            historyText += `📅 ${time}\n`;
            historyText += `📊 Status: ${order.status}\n`;
            historyText += `━━━━━━━━━━━━━━━━━━\n`;
        });

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🔄 Refresh', 'order_history')],
            [Markup.button.callback('📱 Order Baru', 'order_nokos')],
            [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
        ]);

        await messageUtils.replyWithEdit(ctx, historyText, keyboard);
        
    } catch (error) {
        console.error('Error showing order history:', error);
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Gagal memuat riwayat order.*\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// ==================== TOP USERS FUNCTION ====================
async function showTopUsers(ctx) {
    try {
        const allUsers = await safeDbOperation(() => db.getAllUsers(), 'GET_ALL_USERS');
        
        // Sort users berdasarkan total deposit (atau kriteria lain)
        const sortedUsers = allUsers
            .sort((a, b) => b.totalDeposit - a.totalDeposit)
            .slice(0, 10); // Top 10

        if (sortedUsers.length === 0) {
            await messageUtils.replyWithEdit(
                ctx,
                `🏆 *TOP USERS*\n\n` +
                `Belum ada data user.\n\n` +
                `Ajak teman untuk menggunakan bot ini!`,
                Markup.inlineKeyboard([
                    [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
                ])
            );
            return;
        }

        let topUsersText = `🏆 *TOP 10 USERS*\n\n`;
        topUsersText += `Ranking berdasarkan total deposit:\n\n`;

        sortedUsers.forEach((user, index) => {
            const rankEmoji = index === 0 ? '🥇' : 
                            index === 1 ? '🥈' : 
                            index === 2 ? '🥉' : `${index + 1}.`;
            
            const username = user.username ? `@${user.username}` : user.first_name || `User ${user.id.substring(0, 6)}`;
            
            topUsersText += `${rankEmoji} *${username}*\n`;
            topUsersText += `💰 Deposit: Rp${utils.formatNumber(user.totalDeposit)}\n`;
            topUsersText += `📦 Orders: ${user.totalOrders}\n`;
            topUsersText += `👑 Level: ${user.level}\n`;
            topUsersText += `━━━━━━━━━━━━━━━━━━\n`;
        });

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🔄 Refresh', 'top_users')],
            [Markup.button.callback('📊 My Stats', 'check_balance')],
            [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
        ]);

        await messageUtils.replyWithEdit(ctx, topUsersText, keyboard);
        
    } catch (error) {
        console.error('Error showing top users:', error);
        await messageUtils.replyWithEdit(
            ctx,
            '❌ *Gagal memuat data top users.*\nSilakan coba lagi.',
            Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Menu Utama', 'main_menu')]
            ])
        );
    }
}

// ==================== SAFE BOT STARTUP ====================

async function initializeBotSafely() {
    console.log('🚀 Initializing bot with safety systems...');
    
    try {
        console.log('🔍 Testing database connection...');
        const testData = db.load();
        console.log('✅ Database connection OK');
        
        if (!config.BOT_TOKEN) {
            throw new Error('BOT_TOKEN not found in config');
        }
        console.log('✅ Config validation OK');
        
        healthManager.startHealthMonitor();
        console.log('✅ Health monitor started');
        
        maintenanceManager.start();
        console.log('✅ Maintenance manager started');
        
        priceAlertManager.start();
        console.log('✅ Price alert system started');
        
        autoTopupAlert.start();
        refundRecovery.start(); // ✅ Start refund recovery system
        console.log('✅ Auto top-up alert system started');
        
        await bot.launch();
        console.log('🤖 Bot launched successfully!');
        
        await bot.telegram.sendMessage(
            config.OWNER_ID,
            `🤖 BOT STARTED SUCCESSFULLY\n\n` +
            `🕒 Time: ${new Date().toLocaleString('id-ID')}\n` +
            `🔄 Restart Count: ${healthManager.restartCount}\n` +
            `🛡️ Safety Systems: ACTIVE\n` +
            `🔧 Maintenance System: RUNNING\n` +
            `💰 Price Alert System: RUNNING\n` +
            `🚨 Auto Top-up Alert: RUNNING\n` +
            `💾 Database: OK\n` +
            `🏥 Health Monitor: RUNNING`
        );
        
        console.log('✅ Bot initialization completed');
        
    } catch (error) {
        console.error('❌ CRITICAL: Bot initialization failed:', error);
        
        try {
            await bot.telegram.sendMessage(
                config.OWNER_ID,
                `🚨 BOT STARTUP FAILED\n\n` +
                `Error: ${error.message}\n` +
                `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
                `Bot will attempt auto-restart...`
            );
        } catch (e) {}
        
        setTimeout(() => {
            console.log('🔄 Auto-restarting after startup failure...');
            process.exit(1);
        }, 10000);
    }
}

// ==================== BOT LAUNCH AND INITIALIZATION ====================

let backupInterval = null;

setTimeout(() => {
    scheduleBackup();
}, 5000);

// ==================== AUTO REFUND RECOVERY SYSTEM ====================

class RefundRecoverySystem {
    constructor() {
        this.recoveryInterval = null;
    }

    start() {
        console.log('🔄 Starting refund recovery system...');
        this.recoveryInterval = setInterval(() => {
            this.checkPendingRefunds();
        }, 60000); // Check every minute
    }

    async checkPendingRefunds() {
        try {
            const data = await safeDbOperation(() => db.load(), 'LOAD_RECOVERY_CHECK');
            const activeOrders = Object.values(data.orders).filter(order => 
                order.status === 'active' && Date.now() - order.createdAt > 10 * 60 * 1000
            );

            if (activeOrders.length > 0) {
                console.log(`🔍 Found ${activeOrders.length} potentially stuck orders for recovery`);
                
                for (const order of activeOrders) {
                    console.log(`🔄 Processing recovery for order: ${order.orderId}, created: ${new Date(order.createdAt).toLocaleString('id-ID')}`);
                    
                    // Check status terakhir
                    const statusResult = await api.rumahotp.getOrderStatus(order.orderId);
                    const hasOTP = statusResult?.success && statusResult.data?.otp_code && 
                                  statusResult.data.otp_code !== '-' && statusResult.data.otp_code !== '';

                    if (!hasOTP) {
                        console.log(`💰 Recovery: Refunding stuck order ${order.orderId}`);
                        const dbOrderId = Object.keys(data.orders).find(key => data.orders[key].orderId === order.orderId);
                        await processAutoRefund(order.orderId, dbOrderId, order.userId, 'Recovery system - Stuck order');
                    }
                }
            }
        } catch (error) {
            console.error('❌ Error in refund recovery system:', error);
        }
    }

    stop() {
        if (this.recoveryInterval) {
            clearInterval(this.recoveryInterval);
        }
    }
}

// Initialize recovery system
const refundRecovery = new RefundRecoverySystem();

// Backup scheduler
function scheduleBackup() {
    if (backupInterval) {
        clearInterval(backupInterval);
    }

    const settings = db.getSettings();
    
    if (!settings.backup) {
        settings.backup = {
            auto: false,
            daily: false,
            time: '18.00'
        };
        db.updateSettings(settings);
    }
    
    if (!settings.backup.auto) {
        console.log('🔕 Auto backup is disabled');
        return;
    }

    console.log('🔄 Scheduling auto backup...');
    
    const targetTime = settings.backup.time;
    const [hours, minutes] = targetTime.split(':').map(Number);
    
    const now = new Date();
    const target = new Date();
    target.setHours(hours, minutes, 0, 0);

    if (now > target) {
        target.setDate(target.getDate() + 1);
    }

    const timeUntilBackup = target - now;

    console.log(`⏰ Next backup scheduled at: ${target.toLocaleString('id-ID')}`);

    setTimeout(() => {
        performScheduledBackup();
        backupInterval = setInterval(performScheduledBackup, 24 * 60 * 60 * 1000);
    }, timeUntilBackup);
}

async function performScheduledBackup() {
    try {
        console.log('🔄 Performing scheduled backup...');
        const backupFile = await utils.createBackup();
        await bot.telegram.sendDocument(
            config.OWNER_ID,
            { source: backupFile },
            { caption: `📦 Backup otomatis - ${utils.getIndonesianTime()}` }
        );
        console.log('✅ Scheduled backup completed');
    } catch (error) {
        console.error('❌ Scheduled backup failed:', error);
    }
}

process.on('SIGINT', () => {
    console.log('🔄 Shutting down bot gracefully...');
    autoCancelUtils.cleanupTimers();
    depositCountdownUtils.cleanupTimers();
    maintenanceManager.stop();
    priceAlertManager.stop();
    autoTopupAlert.stop();
    if (backupInterval) {
        clearInterval(backupInterval);
    }
    userTransactionLocks.clear();
    bot.stop('SIGINT');
    console.log('✅ Bot shutdown complete');
});

process.on('SIGTERM', () => {
    console.log('🔄 Shutting down bot gracefully...');
    autoCancelUtils.cleanupTimers();
    depositCountdownUtils.cleanupTimers();
    maintenanceManager.stop();
    priceAlertManager.stop();
    autoTopupAlert.stop();
    if (backupInterval) {
        clearInterval(backupInterval);
    }
    userTransactionLocks.clear();
    bot.stop('SIGTERM');
    console.log('✅ Bot shutdown complete');
});

initializeBotSafely();

console.log('✅ UNKILLABLE BOT CODE LOADED SUCCESSFULLY! ALL SAFETY SYSTEMS ARE ACTIVE! 🚀');
console.log('🎯 CRITICAL IMPROVEMENTS IMPLEMENTED:');
console.log('   ✅ Bulletproof Handler System - No more crashes');
console.log('   ✅ Advanced Request Queue System - Handle 1000+ users');
console.log('   ✅ Notification Queue System - Anti spam notifications');
console.log('   ✅ Price Alert Manager - Smart price drop alerts');
console.log('   ✅ Auto Top-up Alert System - Prevent bot balance issues');
console.log('   ✅ Auto Daily Maintenance System - 23:00-00:10 WIB');
console.log('   ✅ Health Monitoring & Auto-Restart');
console.log('   ✅ Global Error Protection');
console.log('   ✅ Safe API Calls with Retry Logic & Rate Limiting');
console.log('   ✅ Safe Database Operations');
console.log('   ✅ Emergency Owner Alerts');
console.log('   ✅ Memory Leak Protection');
console.log('   ✅ Graceful Shutdown Handling');
console.log('   ✅ ALL HANDLERS PROTECTED - Complete coverage');
console.log('   ✅ ALL OWNERMENU CALLBACKS FIXED - No missing handlers');
console.log('   ✅ REAL-TIME COUNTDOWN SYSTEM - For orders and deposits');
console.log('   ✅ EXACT REFUND AMOUNTS - No more incorrect refunds');
console.log('   ✅ ANTI SPAM REFUND NOTIFICATIONS - No duplicate alerts');
console.log('   ✅ FIXED COUNTDOWN SYSTEM - Stable 05:00 to 00:00');
console.log('   ✅ CLEAN PRICE DISPLAY - No confusing percentages');
console.log('   ✅ NO BUTTONS DURING ORDER - Better user experience');
console.log('   ✅ FIXED MAINTENANCE SCREEN - Like in the reference image');
console.log('   ✅ PROPER ERROR HANDLING - No more parse entity errors');

// Export for testing
module.exports = { bot, healthManager, errorHandler, maintenanceManager, priceAlertManager, autoTopupAlert };
