module.exports = {
    // Bot Configuration
    BOT_TOKEN: '7515293027:AAEheb3F23FiLS4St9VLGh588AxUFrYgacg',
    OWNER_ID: '7568960443',
    ADMIN_IDS: ['7568960443'],
    
    // API Configuration
    RUMAHOTP_API_KEY: 'otp_nLAFsEYMflodPEct',
    RUMAHOTP_BASE_URL: 'https://www.rumahotp.com/api',
    ATLANTICH2H_API_KEY: 'dwdXPbgyGGn7oeanWf7tuHVz7HKopuxWaHLuXDPpUYykXjGMNflZKMVyRln9xU8y5LBxTsIkgQObiJIiT6hife2frPESMGOKwUvW',
    ATLANTICH2H_BASE_URL: 'https://atlantich2h.com',
    

    type_ewallet_RUMAHOTP: "dana", // dana, gopay, ovo, shopeepay, linkaja

    nomor_pencairan_RUMAHOTP: "-", // nomor tujuan pencairan otomatis


    
    // Channel Configuration
    LOG_CHANNEL: '@testiandinxdurov',
    DONE_CHANNEL: '@testiandinxdurov',
    CHANNEL_ID: '-1003432762310',
    
    // Bot Settings
    PROFIT_PERCENTAGE: 30,
    SESSION_TIMEOUT: 300000,
// AI Configuration - Gemini
AI_ENABLED: true,
AI_MODEL: "gemini-2.0-flash",
GEMINI_API_KEY: "AIzaSyD3sng2eEVquVw4zYYsvnnwx11B4P2Vmfg", // Pastikan ini API key yang benar
    // Deposit Settings
    MIN_DEPOSIT: 1000,
    QRIS_FEE_PERCENTAGE: 0.7,
    QRIS_FEE_FLAT: 200,
    
    // Database file
    DB_FILE: 'database.json',
    
    
    // New Settings
    DEPOSIT_METHOD: 'rumahotp',
    PAYMENT_TIMEOUT: 600000, // 10 menit
    STATUS_CHECK_INTERVAL: 3000,
    
    // Notification Settings
    NOTIFY_NEW_USERS: true,
    NOTIFY_RETURNING_USERS: false,

    // Referral Settings
    REFERRAL_BONUS: 5000,

    // SATU LINK FOTO UNTUK SEMUA MENU
    BOT_MAIN_IMAGE: 'https://files.catbox.moe/1kdckv.jpg'
};
