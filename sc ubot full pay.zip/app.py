"""
PAYMENT BOT PAYMENT WITH AI ASSISTANT
Version: 3.1.0
Author: PAYMENT BOT PAYMENT
Description: Full-featured userbot with AI assistant, payment processing, panel management, and auto-transaction handling
"""

# =============================================
# IMPORTS
# =============================================

import asyncio
import time
import os
import json
import sys
import signal
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import re
import random
import string
import hashlib
import base64
import io
import logging
from logging.handlers import RotatingFileHandler
import math
import ssl
import certifi

# Telethon
from telethon import TelegramClient, events, functions, types
from telethon.sessions import StringSession
from telethon.tl.types import PeerUser, PeerChat, PeerChannel
from telethon.tl.functions.messages import SendReactionRequest
from telethon.tl.types import ReactionEmoji

# HTTP & Networking
import httpx
import aiohttp
from aiohttp import ClientSession, ClientTimeout

# QR Code & Images
import qrcode
from PIL import Image, ImageDraw, ImageFont

# SSH
import asyncssh

# AI
import google.generativeai as genai

# Data Validation
from pydantic import BaseModel, Field, validator

# =============================================
# CONFIGURATION
# =============================================

class Config(BaseModel):
    # Telegram API
    API_ID: int = 34846365
    API_HASH: str = "0b62ccec3ccd6caeb5514a267d89f8b6"
    OWNER_ID: int = 7568960443
    SESSION_STRING: str = ""
    LOG_GROUP_ID: Optional[int] = None
    
    # AI Configuration
    GEMINI_API_KEY: str = "AIzaSyBaarbzU6_rXKgYA-srQwSLwl6fgbSfliA"
    GEMINI_MODEL: str = "gemini-2.0-flash"
    AI_TEMPERATURE: float = 0.7
    AI_MAX_TOKENS: int = 1000
    
    # Payment Gateway
    APIKEY_HOST: str = "dwdXPbgyGGn7oeanWf7tuHVz7HKopuxWaHLuXDPpUYykXjGMNflZKMVyRln9xU8y5LBxTsIkgQObiJIiT6hife2frPESMGOKwUvW"
    
    # Panel Configuration
    PANEL_DOMAIN: str = "public.naaofficial.web.id"
    PANEL_API_KEY: str = "ptla_ytLzEdXyb9ivNip1kAx7rXW5v1F1yI7c4qAinyN2RBy"
    PANEL_CLIENT_API_KEY: str = "ptlc_Js6pbaujW91BWQ10fwQA7iLisXAexb07frQxv2VcELF"
    PANEL_NEST_ID: str = "5"
    PANEL_LOCATION_ID: str = "1"
    
    # Product Configuration
    DANA_PRODUCTS: Dict[str, Dict] = {
        "DANA1": {"nama": "DANA 1.000", "harga": 1250},
        "DANA2": {"nama": "DANA 2.000", "harga": 2152},
        "DANA3": {"nama": "DANA 3.000", "harga": 3190},
        "DANA4": {"nama": "DANA 4.000", "harga": 4250},
        "DANA5": {"nama": "DANA 5.000", "harga": 5405},
        "DANA6": {"nama": "DANA 6.000", "harga": 6180},
        "DANA7": {"nama": "DANA 7.000", "harga": 7205},
        "DANA9": {"nama": "DANA 9.000", "harga": 9205},
        "DANA10": {"nama": "DANA 10.000", "harga": 10120},
        "DANA11": {"nama": "DANA 11.000", "harga": 11175},
        "DANA12": {"nama": "DANA 12.000", "harga": 12175},
        "DANA13": {"nama": "DANA 13.000", "harga": 13175},
        "DANA14": {"nama": "DANA 14.000", "harga": 14175},
        "DANA15": {"nama": "DANA 15.000", "harga": 15250},
        "DANA16": {"nama": "DANA 16.000", "harga": 16175},
        "DANA17": {"nama": "DANA 17.000", "harga": 17157},
        "DANA18": {"nama": "DANA 18.000", "harga": 18180},
        "DANA19": {"nama": "DANA 19.000", "harga": 19175},
        "DANA20": {"nama": "DANA 20.000", "harga": 20150},
        "DANA25": {"nama": "DANA 25.000", "harga": 25150},
        "DANA30": {"nama": "DANA 30.000", "harga": 30155},
        "DANA35": {"nama": "DANA 35.000", "harga": 35100},
        "DANA40": {"nama": "DANA 40.000", "harga": 40155},
        "DANA45": {"nama": "DANA 45.000", "harga": 45155},
        "DANA50": {"nama": "DANA 50.000", "harga": 50500},
        "DANA55": {"nama": "DANA 55.000", "harga": 55145},
        "DANA60": {"nama": "DANA 60.000", "harga": 60799},
        "DANA65": {"nama": "DANA 65.000", "harga": 65175},
        "DANA70": {"nama": "DANA 70.000", "harga": 70150},
        "DANA80": {"nama": "DANA 80.000", "harga": 80100},
        "DANA85": {"nama": "DANA 85.000", "harga": 85150},
        "DANA90": {"nama": "DANA 90.000", "harga": 90150},
        "DANA95": {"nama": "DANA 95.000", "harga": 95150},
        "DANA100": {"nama": "DANA 100.000", "harga": 100155},
        "DANA115": {"nama": "DANA 115.000", "harga": 115250},
        "DANA120": {"nama": "DANA 120.000", "harga": 120500},
        "DANA125": {"nama": "DANA 125.000", "harga": 125205},
        "DANA130": {"nama": "DANA 130.000", "harga": 130250},
        "DANA150": {"nama": "DANA 150.000", "harga": 150400},
        "DANA165": {"nama": "DANA 165.000", "harga": 165180},
        "DANA200": {"nama": "DANA 200.000", "harga": 200155},
        "DANA250": {"nama": "DANA 250.000", "harga": 250250},
        "DANA300": {"nama": "DANA 300.000", "harga": 300190},
        "DANA350": {"nama": "DANA 350.000", "harga": 350150},
        "DANA400": {"nama": "DANA 400.000", "harga": 400220},
        "DANA600": {"nama": "DANA 600.000", "harga": 600165},
        "DANA700": {"nama": "DANA 700.000", "harga": 700165},
        "DANA800": {"nama": "DANA 800.000", "harga": 800155},
        "DANA900": {"nama": "DANA 900.000", "harga": 900145},
        "DANA1000": {"nama": "DANA 1.000.000", "harga": 1001100}
    }
    
    # Panel Resources
    PANEL_RESOURCES: Dict[str, Dict] = {
        "1gb": {"ram": 1000, "disk": 1000, "cpu": 40},
        "2gb": {"ram": 2000, "disk": 1000, "cpu": 60},
        "3gb": {"ram": 3000, "disk": 2000, "cpu": 80},
        "4gb": {"ram": 4000, "disk": 2000, "cpu": 100},
        "5gb": {"ram": 5000, "disk": 3000, "cpu": 120},
        "6gb": {"ram": 6000, "disk": 3000, "cpu": 140},
        "7gb": {"ram": 7000, "disk": 4000, "cpu": 160},
        "8gb": {"ram": 8000, "disk": 4000, "cpu": 180},
        "9gb": {"ram": 9000, "disk": 5000, "cpu": 200},
        "10gb": {"ram": 10000, "disk": 5000, "cpu": 220},
        "unlimited": {"ram": 0, "disk": 0, "cpu": 0},
        "unli": {"ram": 0, "disk": 0, "cpu": 0}
    }
    
    # Panel Eggs
    PANEL_EGGS: Dict[str, str] = {
        "python": "17",
        "nodejs": "16"
    }
    
    # Backup & Files
    BACKUP_FILE: str = "bot_backup.json"
    SESSION_FILE: str = "session.txt"
    LOG_FILE: str = "logs/userbot.log"
    BLACKLIST_FILE: str = "data/blacklist.json"
    
    # Hackback Script
    HB_PANEL_SCRIPT: str = "bash <(curl -s https://raw.githubusercontent.com/iLyxxDev/hosting/refs/heads/main/install.sh)"
    
    # Bot Settings
    ADMIN_FEE: int = 50
    PAYMENT_TIMEOUT: int = 900  # 15 minutes
    WITHDRAWAL_TIMEOUT: int = 300  # 5 minutes
    AI_RESPONSE_DELAY: Tuple[float, float] = (0.5, 1.5)
    MAX_LOG_SIZE: int = 10485760  # 10MB
    BACKUP_COUNT: int = 5
    
    # Spam Configuration
    MAX_SPAM_MESSAGES: int = 50  # Batas maksimal spam
    SPAM_DELAY: float = 0.5  # Delay antar spam
    
    # Watermark
    WATERMARK: str = "© Created By @andinsukaapink"

# =============================================
# LOGGING CONFIGURATION
# =============================================

def setup_logging():
    """Setup comprehensive logging system"""
    # Create logs directory if not exists
    os.makedirs("logs", exist_ok=True)
    
    # Configure root logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # Remove existing handlers
    logger.handlers.clear()
    
    # File handler with rotation
    file_handler = RotatingFileHandler(
        Config().LOG_FILE,
        maxBytes=Config().MAX_LOG_SIZE,
        backupCount=Config().BACKUP_COUNT,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_formatter)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)
    
    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

# Initialize logging
logger = setup_logging()

# =============================================
# GLOBAL STATE MANAGEMENT
# =============================================

class GlobalState:
    """Global state manager for the bot"""
    
    def __init__(self):
        self.active_transactions: Dict[int, Dict] = {}
        self.active_withdrawals: Dict[str, Dict] = {}
        self.user_lists: Dict[int, List] = {}
        self.done_channels: set = set()
        self.ai_conversations: Dict[int, List] = {}
        self.user_sessions: Dict[int, Dict] = {}
        self.ai_transactions: Dict[str, Dict] = {}
        
        # AFK Mode
        self.afk_mode: bool = False
        self.afk_reason: str = ""
        self.afk_since: Optional[datetime] = None
        
        # Muted users
        self.muted_users: Dict[int, Dict] = {}  # {user_id: {"until": timestamp, "reason": ""}}
        
        # Banned users
        self.banned_users: Dict[int, Dict] = {}  # {user_id: {"banned_at": timestamp, "reason": ""}}
        
        # Spam protection
        self.spam_cooldown: Dict[int, float] = {}  # {user_id: last_spam_time}
        self.spam_count: Dict[int, int] = {}  # {user_id: spam_count_last_minute}
        
        # Statistics
        self.stats = {
            "transactions_processed": 0,
            "withdrawals_processed": 0,
            "panels_created": 0,
            "ai_responses": 0,
            "errors": 0,
            "start_time": datetime.now()
        }
        
        # Cache for performance
        self.cache = {
            "balance": {"value": 0.0, "timestamp": 0},
            "users": {"value": [], "timestamp": 0}
        }
        
        # Tagall tracking
        self.tagall_active: Dict[int, bool] = {}
        
        # Auto CFD state
        self.auto_cfd_state = {
            "running": False,
            "reply_msg_id": None,
            "origin_chat_id": None,
            "interval": None
        }
        
        # Blacklist
        self.blacklist: List[str] = []
        
        # Load blacklist from file
        self.load_blacklist()
    
    def add_transaction(self, msg_id: int, data: Dict):
        """Add transaction to active transactions"""
        self.active_transactions[msg_id] = data
        self.stats["transactions_processed"] += 1
    
    def remove_transaction(self, msg_id: int):
        """Remove transaction from active transactions"""
        if msg_id in self.active_transactions:
            del self.active_transactions[msg_id]
    
    def add_withdrawal(self, trx_id: str, data: Dict):
        """Add withdrawal to active withdrawals"""
        self.active_withdrawals[trx_id] = data
        self.stats["withdrawals_processed"] += 1
    
    def remove_withdrawal(self, trx_id: str):
        """Remove withdrawal from active withdrawals"""
        if trx_id in self.active_withdrawals:
            del self.active_withdrawals[trx_id]
    
    def add_ai_transaction(self, trans_id: str, data: Dict):
        """Add AI transaction"""
        self.ai_transactions[trans_id] = data
    
    def update_ai_transaction(self, trans_id: str, updates: Dict):
        """Update AI transaction"""
        if trans_id in self.ai_transactions:
            self.ai_transactions[trans_id].update(updates)
    
    def get_user_session(self, user_id: int) -> Dict:
        """Get or create user session"""
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = {
                "message_count": 0,
                "last_message": None,
                "pending_confirmation": None,
                "context": {},
                "created_at": datetime.now()
            }
        return self.user_sessions[user_id]
    
    def update_user_session(self, user_id: int, updates: Dict):
        """Update user session"""
        session = self.get_user_session(user_id)
        session.update(updates)
        session["last_message"] = datetime.now()
        session["message_count"] += 1
    
    def mute_user(self, user_id: int, duration_seconds: int, reason: str = ""):
        """Mute user for specified duration"""
        until_time = time.time() + duration_seconds
        self.muted_users[user_id] = {
            "until": until_time,
            "reason": reason,
            "muted_at": time.time()
        }
    
    def unmute_user(self, user_id: int):
        """Unmute user"""
        if user_id in self.muted_users:
            del self.muted_users[user_id]
    
    def is_user_muted(self, user_id: int) -> bool:
        """Check if user is muted"""
        if user_id not in self.muted_users:
            return False
        
        mute_data = self.muted_users[user_id]
        if time.time() > mute_data["until"]:
            # Auto unmute jika waktu sudah habis
            del self.muted_users[user_id]
            return False
        
        return True
    
    def ban_user(self, user_id: int, reason: str = ""):
        """Ban user permanently"""
        self.banned_users[user_id] = {
            "banned_at": time.time(),
            "reason": reason
        }
    
    def unban_user(self, user_id: int):
        """Unban user"""
        if user_id in self.banned_users:
            del self.banned_users[user_id]
    
    def is_user_banned(self, user_id: int) -> bool:
        """Check if user is banned"""
        return user_id in self.banned_users
    
    def can_spam(self, user_id: int) -> bool:
        """Check if user can spam (cooldown check)"""
        current_time = time.time()
        
        # Reset count jika sudah 1 menit
        if user_id in self.spam_count:
            if current_time - self.spam_cooldown.get(user_id, 0) > 60:
                self.spam_count[user_id] = 0
                self.spam_cooldown[user_id] = current_time
        
        # Check spam count
        spam_count = self.spam_count.get(user_id, 0)
        if spam_count >= 5:  # Max 5 spam commands per minute
            return False
        
        # Update count
        self.spam_count[user_id] = spam_count + 1
        self.spam_cooldown[user_id] = current_time
        
        return True
    
    def set_afk_mode(self, reason: str = ""):
        """Activate AFK mode"""
        self.afk_mode = True
        self.afk_reason = reason
        self.afk_since = datetime.now()
        logger.info(f"AFK mode activated: {reason}")
    
    def disable_afk_mode(self):
        """Disable AFK mode"""
        self.afk_mode = False
        duration = datetime.now() - self.afk_since if self.afk_since else timedelta(0)
        logger.info(f"AFK mode disabled. Duration: {duration}")
        self.afk_reason = ""
        self.afk_since = None
    
    def load_blacklist(self):
        """Load blacklist from file"""
        try:
            if os.path.exists(config.BLACKLIST_FILE):
                with open(config.BLACKLIST_FILE, 'r') as f:
                    self.blacklist = json.load(f)
                logger.info(f"Blacklist loaded: {len(self.blacklist)} entries")
        except Exception as e:
            logger.error(f"Failed to load blacklist: {str(e)}")
            self.blacklist = []
    
    def save_blacklist(self):
        """Save blacklist to file"""
        try:
            os.makedirs("data", exist_ok=True)
            with open(config.BLACKLIST_FILE, 'w') as f:
                json.dump(self.blacklist, f)
            logger.info(f"Blacklist saved: {len(self.blacklist)} entries")
        except Exception as e:
            logger.error(f"Failed to save blacklist: {str(e)}")
    
    def add_to_blacklist(self, chat_id: str):
        """Add chat to blacklist"""
        if chat_id not in self.blacklist:
            self.blacklist.append(chat_id)
            self.save_blacklist()
            return True
        return False
    
    def remove_from_blacklist(self, chat_id: str):
        """Remove chat from blacklist"""
        if chat_id in self.blacklist:
            self.blacklist.remove(chat_id)
            self.save_blacklist()
            return True
        return False
    
    def is_blacklisted(self, chat_id: str) -> bool:
        """Check if chat is blacklisted"""
        return chat_id in self.blacklist
    
    def get_stats(self) -> Dict:
        """Get bot statistics"""
        uptime = datetime.now() - self.stats["start_time"]
        self.stats["uptime"] = str(uptime).split('.')[0]
        self.stats["active_transactions"] = len(self.active_transactions)
        self.stats["active_withdrawals"] = len(self.active_withdrawals)
        self.stats["ai_transactions"] = len(self.ai_transactions)
        self.stats["user_sessions"] = len(self.user_sessions)
        self.stats["afk_mode"] = self.afk_mode
        self.stats["blacklist_count"] = len(self.blacklist)
        return self.stats

# Initialize global state
state = GlobalState()
config = Config()

# =============================================
# UTILITY FUNCTIONS
# =============================================

def mask_phone_number(phone: str) -> str:
    """Mask phone number for security"""
    if len(phone) >= 8:
        return phone[:4] + "****" + phone[-4:]
    return phone

def generate_random_string(length: int = 8) -> str:
    """Generate random string"""
    characters = string.ascii_lowercase + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def generate_transaction_id() -> str:
    """Generate transaction ID"""
    timestamp = int(time.time())
    random_part = random.randint(1000, 9999)
    return f"TRX-{timestamp}-{random_part}"

def format_currency(amount: int) -> str:
    """Format currency to Indonesian format"""
    return f"Rp {amount:,}"

def format_date(date: datetime) -> str:
    """Format date to readable string"""
    return date.strftime("%Y-%m-%d %H:%M:%S")

def calculate_admin_fee(amount: int) -> int:
    """Calculate admin fee"""
    return config.ADMIN_FEE

def save_backup():
    """Save backup data"""
    try:
        backup_data = {
            "active_transactions": state.active_transactions,
            "active_withdrawals": state.active_withdrawals,
            "done_channels": list(state.done_channels),
            "ai_transactions": state.ai_transactions,
            "user_sessions": state.user_sessions,
            "stats": state.stats,
            "backup_time": datetime.now().isoformat()
        }
        
        with open(config.BACKUP_FILE, 'w', encoding='utf-8') as f:
            json.dump(backup_data, f, ensure_ascii=False, indent=2)
        
        logger.info("Backup saved successfully")
        return True
        
    except Exception as e:
        logger.error(f"Backup failed: {str(e)}")
        return False

def load_backup():
    """Load backup data"""
    try:
        if os.path.exists(config.BACKUP_FILE):
            with open(config.BACKUP_FILE, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            # Restore data
            state.active_transactions = backup_data.get("active_transactions", {})
            state.active_withdrawals = backup_data.get("active_withdrawals", {})
            state.done_channels = set(backup_data.get("done_channels", []))
            state.ai_transactions = backup_data.get("ai_transactions", {})
            state.user_sessions = backup_data.get("user_sessions", {})
            
            logger.info("Backup loaded successfully")
            return True
            
    except Exception as e:
        logger.error(f"Restore failed: {str(e)}")
    
    return False

async def send_log(client: TelegramClient, message: str):
    """Send log to log group"""
    if config.LOG_GROUP_ID and client:
        try:
            await client.send_message(config.LOG_GROUP_ID, f"📊 LOG\n{message}")
        except Exception as e:
            logger.error(f"Failed to send log: {str(e)}")

def with_footer(message: str) -> str:
    """Add footer to message"""
    return f"{message}\n\n{config.WATERMARK}"

def random_emoji() -> str:
    """Return random emoji"""
    emojis = ["✨", "🌟", "⭐", "🎯", "🔥", "💫", "⚡", "💥", "🎉", "🎊"]
    return random.choice(emojis)

# =============================================
# PAYMENT FUNCTIONS
# =============================================

async def get_atlantic_balance() -> float:
    """Get balance from AtlanticH2H"""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                'https://atlantich2h.com/get_profile',
                data={"api_key": config.APIKEY_HOST}
            )
        
        if response.status_code == 200:
            data = response.json()
            if data.get('status'):
                profile_data = data.get('data', {})
                balance = profile_data.get('balance') or profile_data.get('saldo') or 0
                return float(balance)
        
        return 0.0
        
    except Exception as e:
        logger.error(f"Balance check failed: {str(e)}")
        return 0.0

async def find_best_dana_product(balance: float) -> Optional[Dict]:
    """Find best Dana product based on balance"""
    available_products = []
    
    for code, product in config.DANA_PRODUCTS.items():
        if balance >= product['harga']:
            available_products.append({
                'code': code,
                'nama': product['nama'],
                'harga': product['harga'],
                'sisa_saldo': balance - product['harga']
            })
    
    if not available_products:
        return None
    
    # Sort by remaining balance (ascending)
    available_products.sort(key=lambda x: x['sisa_saldo'])
    return available_products[0]

async def process_dana_withdrawal(phone: str, product_code: str, event, client: TelegramClient) -> bool:
    """Process Dana withdrawal"""
    try:
        if product_code not in config.DANA_PRODUCTS:
            await event.reply("❌ Kode produk tidak valid!")
            return False
        
        product = config.DANA_PRODUCTS[product_code]
        ref = f"TG-WD-{int(time.time())}-{random.randint(1000, 9999)}"
        
        async with httpx.AsyncClient(timeout=30.0) as http_client:
            response = await http_client.post(
                'https://atlantich2h.com/transaksi/create',
                data={
                    "api_key": config.APIKEY_HOST,
                    "reff_id": ref,
                    "code": product_code,
                    "target": phone
                }
            )
        
        data = response.json()
        
        if data.get('status'):
            trx_data = data.get('data', {})
            trx_id = trx_data.get('id')
            
            state.add_withdrawal(trx_id, {
                'phone': phone,
                'product': product['nama'],
                'amount': product['harga'],
                'ref': ref,
                'event': event,
                'product_code': product_code,
                'start_time': time.time()
            })
            
            # Send initial message
            info_msg = await event.reply(
                f"🚀 PENARIKAN DANA DIPROSES\n\n"
                f"📦 Produk: {product['nama']}\n"
                f"💵 Nominal: {format_currency(product['harga'])}\n"
                f"📱 Tujuan: `{mask_phone_number(phone)}`\n"
                f"🆔 Ref ID: {ref}\n"
                f"📊 Status: Processing\n\n"
                f"⏳ Menunggu konfirmasi..."
            )
            
            # Start monitoring
            asyncio.create_task(
                monitor_withdrawal_status(
                    client, trx_id, phone, product['nama'], 
                    product['harga'], ref, event, info_msg
                )
            )
            
            return True
        else:
            error_msg = data.get('message', 'Unknown error')
            await event.reply(f"❌ Gagal memproses penarikan:\n`{error_msg}`")
            return False
            
    except Exception as e:
        await event.reply(f"❌ Error sistem:\n`{str(e)}`")
        return False

async def monitor_withdrawal_status(client: TelegramClient, trx_id: str, phone: str, 
                                   product_name: str, amount: int, ref: str, 
                                   event, info_msg):
    """Monitor withdrawal status"""
    masked_phone = mask_phone_number(phone)
    max_attempts = 60
    attempts = 0
    
    while attempts < max_attempts:
        await asyncio.sleep(5)
        attempts += 1
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    'https://atlantich2h.com/transaksi/status',
                    data={"api_key": config.APIKEY_HOST, "id": trx_id}
                )
            
            data = response.json()
            status_data = data.get('data', {})
            status = status_data.get('status', '').lower()
            
            if status in ['success', 'sukses', 'completed']:
                success_msg = (
                    f"✅ TRANSAKSI SUKSES\n\n"
                    f"📦 Produk: {product_name}\n"
                    f"💵 Nominal: {format_currency(amount)}\n"
                    f"📱 Tujuan: {masked_phone}\n"
                    f"🆔 Ref ID: {ref}\n"
                    f"⏰ Waktu: {datetime.now().strftime('%H:%M:%S')}\n\n"
                    f"🎉 Terima kasih telah order!"
                )
                
                await info_msg.edit(success_msg)
                await send_log(client, 
                    f"✅ PENARIKAN DANA SUKSES\n"
                    f"📱 Ke: {masked_phone}\n"
                    f"💰 {product_name}\n"
                    f"💵 {format_currency(amount)}\n"
                    f"🆔 Ref: {ref}"
                )
                
                state.remove_withdrawal(trx_id)
                return
                
            elif status in ['failed', 'error', 'cancel']:
                await info_msg.edit(f"❌ Penarikan gagal!\nStatus: {status}")
                state.remove_withdrawal(trx_id)
                return
                
        except Exception as e:
            logger.error(f"Withdrawal status check error: {str(e)}")
            continue
    
    # Timeout
    await info_msg.edit(
        f"⏰ Monitoring timeout\n"
        f"Cek status manual dengan Ref ID: {ref}"
    )
    state.remove_withdrawal(trx_id)

# =============================================
# PANEL MANAGEMENT FUNCTIONS
# =============================================

async def create_panel_user(username: str, email: str, first_name: str, password: str) -> Optional[Dict]:
    """Create user in panel"""
    try:
        # Prepare URL with proper scheme
        panel_url = f"https://{config.PANEL_DOMAIN}"
        
        # Create SSL context
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30.0),
            verify=ssl_context
        ) as client:
            response = await client.post(
                f"{panel_url}/api/application/users",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.PANEL_API_KEY}"
                },
                json={
                    "email": email,
                    "username": username,
                    "first_name": first_name,
                    "last_name": "Server",
                    "language": "en",
                    "password": password
                }
            )
        
        logger.info(f"Panel user creation response: {response.status_code}")
        
        if response.status_code == 201:
            data = response.json()
            logger.info(f"User created successfully: {username}")
            return data
        else:
            logger.error(f"Failed to create user {username}: Status {response.status_code}, Response: {response.text}")
            return None
            
    except httpx.ConnectError as e:
        logger.error(f"Connection error to panel {config.PANEL_DOMAIN}: {str(e)}")
        return None
    except httpx.TimeoutException as e:
        logger.error(f"Timeout connecting to panel {config.PANEL_DOMAIN}: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Panel user creation error for {username}: {str(e)}")
        return None

async def create_panel_server(name: str, user_id: int, egg_id: str, 
                            ram: int, disk: int, cpu: int, egg_type: str) -> Optional[Dict]:
    """Create server in panel"""
    try:
        panel_url = f"https://{config.PANEL_DOMAIN}"
        
        # Get egg information
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30.0),
            verify=ssl_context
        ) as client:
            response = await client.get(
                f"{panel_url}/api/application/nests/{config.PANEL_NEST_ID}/eggs/{egg_id}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.PANEL_API_KEY}"
                }
            )
        
        if response.status_code != 200:
            logger.error(f"Failed to get egg info: Status {response.status_code}")
            return None
        
        egg_info = response.json()
        egg_data = egg_info.get('attributes', {})
        startup_cmd = egg_data.get('startup', '')
        
        # Set docker image
        if egg_type == "nodejs":
            docker_image = "ghcr.io/parkervcp/yolks:nodejs_24"
            environment = {
                "INST": "npm",
                "USER_UPLOAD": "0",
                "AUTO_UPDATE": "0",
                "CMD_RUN": "npm start"
            }
        else:  # python
            docker_image = "ghcr.io/parkervcp/yolks:python_3.12"
            environment = {
                "PY_FILE": "app.py",
                "REQUIREMENTS_FILE": "requirements.txt",
                "USER_UPLOAD": "0",
                "AUTO_UPDATE": "0",
                "CMD_RUN": "python app.py"
            }
        
        # Create server
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(60.0),
            verify=ssl_context
        ) as client:
            response = await client.post(
                f"{panel_url}/api/application/servers",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.PANEL_API_KEY}"
                },
                json={
                    "name": name,
                    "description": f"Created by Payment Bot - {datetime.now().strftime('%Y-%m-%d')}",
                    "user": user_id,
                    "egg": int(egg_id),
                    "docker_image": docker_image,
                    "startup": startup_cmd,
                    "environment": environment,
                    "limits": {
                        "memory": ram,
                        "swap": 0,
                        "disk": disk,
                        "io": 500,
                        "cpu": cpu
                    },
                    "feature_limits": {
                        "databases": 5,
                        "backups": 5,
                        "allocations": 5
                    },
                    "deploy": {
                        "locations": [int(config.PANEL_LOCATION_ID)],
                        "dedicated_ip": False,
                        "port_range": []
                    }
                }
            )
        
        logger.info(f"Server creation response: {response.status_code}")
        
        if response.status_code == 201:
            data = response.json()
            state.stats["panels_created"] += 1
            logger.info(f"Server created successfully: {name}")
            return data
        else:
            logger.error(f"Failed to create server {name}: Status {response.status_code}, Response: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Panel server creation error for {name}: {str(e)}")
        return None

async def get_panel_servers() -> Optional[List]:
    """Get all servers from panel"""
    try:
        panel_url = f"https://{config.PANEL_DOMAIN}"
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30.0),
            verify=ssl_context
        ) as client:
            response = await client.get(
                f"{panel_url}/api/application/servers",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.PANEL_API_KEY}"
                }
            )
        
        if response.status_code == 200:
            data = response.json()
            return data.get('data', [])
        else:
            logger.error(f"Failed to get panel servers: Status {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Get panel servers error: {str(e)}")
        return None

async def delete_panel_server(server_id: int) -> bool:
    """Delete server from panel"""
    try:
        panel_url = f"https://{config.PANEL_DOMAIN}"
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30.0),
            verify=ssl_context
        ) as client:
            response = await client.delete(
                f"{panel_url}/api/application/servers/{server_id}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {config.PANEL_API_KEY}"
                }
            )
        
        logger.info(f"Delete server response: {response.status_code}")
        return response.status_code == 204
        
    except Exception as e:
        logger.error(f"Delete panel server error: {str(e)}")
        return False

# =============================================
# SSH FUNCTIONS
# =============================================

async def execute_ssh_command(host: str, port: int, username: str, 
                            password: str, command: str, timeout: int = 300) -> Tuple:
    """Execute command via SSH"""
    try:
        async with asyncssh.connect(
            host=host,
            port=port,
            username=username,
            password=password,
            known_hosts=None
        ) as conn:
            result = await conn.run(command, timeout=timeout)
            return result.stdout, result.stderr, result.returncode
    except Exception as e:
        return None, str(e), -1

async def hackback_panel_installation(host: str, password: str, 
                                    chat_id: int, client: TelegramClient, 
                                    message_id: int) -> bool:
    """Install hackback panel via SSH"""
    try:
        # Generate credentials
        new_user = "admin" + generate_random_string(4)
        new_password = "admin" + generate_random_string(4)
        
        # Update status
        status_message = await client.edit_message(
            chat_id,
            message_id,
            f"🔓 HACKBACK PANEL PROSES\n\n"
            f"📡 IP: `{host}`\n"
            f"🔐 Pass: `{password}`\n"
            f"👤 User Baru: `{new_user}`\n"
            f"🔑 Pass Baru: `{new_password}`\n\n"
            f"⏳ Status: Connecting...\n"
            f"🕒 Waktu: {datetime.now().strftime('%H:%M:%S')}"
        )
        
        # Commands
        commands = [
            f"echo 'kingstoreganteng' | {config.HB_PANEL_SCRIPT}",
            f"echo '7' | {config.HB_PANEL_SCRIPT}",
            f"echo '{new_user}' | {config.HB_PANEL_SCRIPT}",
            f"echo '{new_password}' | {config.HB_PANEL_SCRIPT}"
        ]
        
        # Execute commands
        for i, command in enumerate(commands):
            stdout, stderr, returncode = await execute_ssh_command(
                host=host,
                port=22,
                username="root",
                password=password,
                command=command,
                timeout=300
            )
            
            progress = min(100, int((i + 1) / len(commands) * 100))
            
            await client.edit_message(
                chat_id,
                message_id,
                f"🔓 HACKBACK PANEL PROSES\n\n"
                f"📡 IP: `{host}`\n"
                f"🔐 Pass: `{password}`\n"
                f"👤 User Baru: `{new_user}`\n"
                f"🔑 Pass Baru: `{new_password}`\n\n"
                f"⏳ Status: Installing ({progress}%)\n"
                f"📊 Progress: ▰{'▰' * (progress // 25)}{'▱' * (4 - progress // 25)} {progress}%"
            )
        
        # Success message
        success_message = (
            f"✅ HACKBACK PANEL BERHASIL!\n\n"
            f"📡 IP Address: `{host}`\n"
            f"👤 Username: `{new_user}`\n"
            f"🔑 Password: `{new_password}`\n\n"
            f"🌐 Panel URL: http://{host}:8080\n"
            f"⚡ Script: Hosting Panel Autoinstall\n\n"
            f"🔒 Simpan credentials dengan aman!\n"
            f"🕒 Selesai: {datetime.now().strftime('%H:%M:%S')}"
        )
        
        await client.edit_message(chat_id, message_id, success_message)
        return True
        
    except Exception as e:
        error_message = (
            f"❌ ERROR HACKBACK PANEL\n\n"
            f"📡 IP: `{host}`\n"
            f"💻 Error: {str(e)}\n\n"
            f"🕒 Waktu: {datetime.now().strftime('%H:%M:%S')}"
        )
        await client.edit_message(chat_id, message_id, error_message)
        return False

# =============================================
# PANEL INSTALLATION FUNCTIONS
# =============================================

async def install_panel(chat_id: int, ip: str, password: str, domain_panel: str, client: TelegramClient) -> bool:
    """Install Pterodactyl Panel via SSH"""
    try:
        random_num = random.randint(1000, 9999)
        random_name = f"admin{random_num}"
        random_email = f"admin{random_num}@gmail.com"
        
        # Send initial message
        full_log = f"📡 Menghubungkan ke VPS *{ip}*...\n"
        full_log += "Silakan tunggu 10-20 menit\n\n"
        full_log += f"🌐 Domain: https://{domain_panel}\n"
        full_log += f"✉ Email: {random_email}\n\n"
        full_log += "⏳ Proses install sedang berjalan..."
        
        status_msg = await client.send_message(
            chat_id,
            full_log,
            parse_mode='markdown'
        )
        
        last_update = time.time()
        
        # Execute installer via SSH
        command = "bash <(curl -s https://pterodactyl-installer.se)"
        
        async def handle_installer_output(stdout: str, stderr: str):
            nonlocal full_log, last_update
            
            if stdout:
                full_log += f"\n{stdout}"
            
            if stderr:
                full_log += f"\n[ERR] {stderr}"
            
            # Update message every 2 seconds
            current_time = time.time()
            if current_time - last_update > 2:
                last_update = current_time
                
                # Truncate log if too long
                display_log = full_log[-3000:] if len(full_log) > 3000 else full_log
                
                update_text = f"📡 Proses Install Panel:\n```\n{display_log}\n```"
                
                try:
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        update_text,
                        parse_mode='markdown'
                    )
                except:
                    pass
        
        # Connect via SSH
        try:
            async with asyncssh.connect(
                host=ip,
                port=22,
                username="root",
                password=password,
                known_hosts=None
            ) as conn:
                
                # Create installer process
                result = await conn.create_process(command)
                
                # Handle interactive input
                inputs = [
                    ("Input 0-6", "0\n"),
                    ("Database name (panel)", f"{random_name}\n"),
                    ("Database username (pterodactyl)", f"{random_name}\n"),
                    ("Password (press enter", "\n"),
                    ("Select timezone", "Asia/Jakarta\n"),
                    ("Provide the email address", f"{random_email}\n"),
                    ("Email address for the initial admin account", f"{random_email}\n"),
                    ("Username for the initial admin account", f"{random_name}\n"),
                    ("First name for the initial admin account", f"{random_name}\n"),
                    ("Last name for the initial admin account", f"{random_name}\n"),
                    ("Password for the initial admin account", f"{random_num}\n"),
                    ("Set the FQDN", f"{domain_panel}\n"),
                    ("(y/N)", "y\n"),
                    ("Enable sending anonymous telemetry", "yes\n"),
                    ("(Y)es/(N)o", "Y\n")
                ]
                
                # Read output and send inputs
                while True:
                    try:
                        data = await result.stdout.read(4096)
                        if not data:
                            break
                        
                        output = data.decode('utf-8', errors='ignore')
                        await handle_installer_output(output, "")
                        
                        # Check for prompts and send responses
                        for prompt, response in inputs:
                            if prompt.lower() in output.lower():
                                result.stdin.write(response)
                                break
                                
                    except EOFError:
                        break
                
                # Get exit code
                exit_code = await result.wait()
                
                if exit_code == 0:
                    success_msg = (
                        f"✅ *Sukses install Panel!*\n\n"
                        f"📌 IP VPS: `{ip}`\n"
                        f"🔑 Password VPS: `{password}`\n\n"
                        f"🌐 Panel: https://{domain_panel}\n"
                        f"👤 User: `{random_name}`\n"
                        f"🔐 Password Panel: `{random_num}`"
                    )
                    
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        success_msg,
                        parse_mode='markdown'
                    )
                    return True
                else:
                    error_msg = f"{full_log}\n⚠️ Installer selesai dengan kode {exit_code}. Cek manual di VPS."
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        error_msg
                    )
                    return False
                    
        except Exception as ssh_error:
            error_msg = f"❌ Gagal konek ke VPS:\n{str(ssh_error)}"
            await client.edit_message(
                chat_id,
                status_msg.id,
                error_msg
            )
            return False
            
    except Exception as e:
        logger.error(f"Panel installation error: {str(e)}")
        return False

async def install_wings(chat_id: int, ip: str, password: str, domain_panel: str, domain_node: str, client: TelegramClient) -> bool:
    """Install Pterodactyl Wings via SSH"""
    try:
        random_num = random.randint(1000, 9999)
        random_email = f"admin{random_num}@gmail.com"
        random_user_db = f"admin{random.randint(1000, 9999)}"
        random_pass_db = f"{random.randint(1000, 9999)}"
        
        # Send initial message
        full_log = f"📡 Menghubungkan ke VPS *{ip}*...\n"
        full_log += "Silakan tunggu 10-20 menit\n\n"
        full_log += f"🌐 Panel: https://{domain_panel}\n"
        full_log += f"🛰️ Node: {domain_node}\n"
        full_log += f"✉ Email: {random_email}\n\n"
        full_log += f"🗃️ User DB: {random_user_db}\n"
        full_log += f"🔐 Pass DB: {random_pass_db}\n\n"
        full_log += "⏳ Proses install sedang berjalan..."
        
        status_msg = await client.send_message(
            chat_id,
            full_log,
            parse_mode='markdown'
        )
        
        last_update = time.time()
        
        # Execute installer via SSH
        command = "bash <(curl -s https://pterodactyl-installer.se)"
        
        async def handle_installer_output(stdout: str, stderr: str):
            nonlocal full_log, last_update
            
            if stdout:
                full_log += f"\n{stdout}"
            
            if stderr:
                full_log += f"\n[ERR] {stderr}"
            
            # Update message every 2 seconds
            current_time = time.time()
            if current_time - last_update > 2:
                last_update = current_time
                
                # Truncate log if too long
                display_log = full_log[-3000:] if len(full_log) > 3000 else full_log
                
                update_text = f"📡 Proses Install Wings:\n```\n{display_log}\n```"
                
                try:
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        update_text,
                        parse_mode='markdown'
                    )
                except:
                    pass
        
        # Connect via SSH
        try:
            async with asyncssh.connect(
                host=ip,
                port=22,
                username="root",
                password=password,
                known_hosts=None
            ) as conn:
                
                # Create installer process
                result = await conn.create_process(command)
                
                # Handle interactive input
                inputs = [
                    ("Input 0-6", "1\n"),
                    ("(y/N)", "y\n"),
                    ("Enter the panel address", f"{domain_panel}\n"),
                    ("Database host username", f"{random_user_db}\n"),
                    ("Database host password", f"{random_pass_db}\n"),
                    ("Set the FQDN to use for Let's Encrypt", f"{domain_node}\n"),
                    ("Enter email address", f"{random_email}\n")
                ]
                
                # Read output and send inputs
                while True:
                    try:
                        data = await result.stdout.read(4096)
                        if not data:
                            break
                        
                        output = data.decode('utf-8', errors='ignore')
                        await handle_installer_output(output, "")
                        
                        # Check for prompts and send responses
                        for prompt, response in inputs:
                            if prompt.lower() in output.lower():
                                result.stdin.write(response)
                                break
                                
                    except EOFError:
                        break
                
                # Get exit code
                exit_code = await result.wait()
                
                if exit_code == 0:
                    success_msg = (
                        f"✅ *Wings berhasil diinstall!*\n\n"
                        f"📌 IP VPS: `{ip}`\n"
                        f"🔑 Password VPS: `{password}`\n\n"
                        f"🌐 Panel: {domain_panel}\n"
                        f"🛰️ Node: {domain_node}\n"
                        f"✉ Email: {random_email}"
                    )
                    
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        success_msg,
                        parse_mode='markdown'
                    )
                    return True
                else:
                    error_msg = f"{full_log}\n⚠️ Installer selesai dengan kode {exit_code}. Beberapa bagian mungkin gagal, cek manual VPS."
                    await client.edit_message(
                        chat_id,
                        status_msg.id,
                        error_msg
                    )
                    return False
                    
        except Exception as ssh_error:
            error_msg = f"❌ Gagal konek ke VPS:\n{str(ssh_error)}"
            await client.edit_message(
                chat_id,
                status_msg.id,
                error_msg
            )
            return False
            
    except Exception as e:
        logger.error(f"Wings installation error: {str(e)}")
        return False

# =============================================
# AI ASSISTANT
# =============================================

class AIAssistant:
    """AI Assistant using Gemini API"""
    
    def __init__(self):
        try:
            genai.configure(api_key=config.GEMINI_API_KEY)
            self.model = genai.GenerativeModel(config.GEMINI_MODEL)
            logger.info("✅ AI Assistant initialized")
        except Exception as e:
            logger.error(f"❌ Failed to initialize AI: {str(e)}")
            self.model = None
    
    async def generate_response(self, message: str, context: str = "") -> str:
        """Generate AI response"""
        if not self.model:
            return "🤖 AI sedang offline. Mohon coba lagi nanti."
        
        try:
            prompt = f"""
            Context: {context}
            Message: {message}
            
            Anda adalah asisten AI yang membantu menjawab pertanyaan user. 
            Gunakan bahasa yang ramah dan informatif.
            Jika pertanyaan tidak jelas, minta klarifikasi.
            """
            
            response = await asyncio.to_thread(
                self.model.generate_content,
                prompt,
                generation_config={
                    "temperature": config.AI_TEMPERATURE,
                    "max_output_tokens": config.AI_MAX_TOKENS,
                }
            )
            
            state.stats["ai_responses"] += 1
            return response.text
            
        except Exception as e:
            logger.error(f"AI generation error: {str(e)}")
            return "🤖 Maaf, terjadi kesalahan saat memproses permintaan Anda."

# Initialize AI Assistant
ai_assistant = AIAssistant()

# =============================================
# EVENT HANDLERS
# =============================================

async def setup_handlers(client: TelegramClient):
    """Setup all event handlers"""
    
    # ========== TEST HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.test$'))
    async def test_handler(event):
        """Test handler to check if bot is working"""
        logger.info(f"Test handler triggered by: {event.sender_id}")
        await event.reply(f"✅ Bot aktif! Your ID: {event.sender_id}\nOwner ID: {config.OWNER_ID}")
    
    # ========== ID HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.id$'))
    async def id_handler(event):
        """Get user ID with card format"""
        try:
            # Determine target user
            if event.is_reply:
                # If replying to a message, get that user's info
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
                try:
                    user = await client.get_entity(target_user)
                except:
                    user = None
            else:
                # Get own info
                target_user = event.sender_id
                user = await event.get_sender()
            
            # Get chat info if in group
            chat_title = None
            chat_id = None
            if event.is_group:
                chat = await event.get_chat()
                chat_title = chat.title if hasattr(chat, 'title') else "Private Chat"
                chat_id = chat.id
            
            # Build user info
            user_info = []
            
            if user:
                user_info.append(f"👤 **Nama:** {user.first_name or 'Unknown'}")
                if user.last_name:
                    user_info.append(f"👥 **Nama Belakang:** {user.last_name}")
                if user.username:
                    user_info.append(f"📱 **Username:** @{user.username}")
                user_info.append(f"🆔 **User ID:** `{target_user}`")
                if hasattr(user, 'phone'):
                    if user.phone:
                        masked_phone = mask_phone_number(user.phone)
                        user_info.append(f"📞 **Telepon:** `{masked_phone}`")
                user_info.append(f"🤖 **Bot:** {'✅ Ya' if getattr(user, 'bot', False) else '❌ Tidak'}")
            else:
                user_info.append(f"🆔 **User ID:** `{target_user}`")
            
            # Add chat info if available
            if chat_title and chat_id:
                user_info.append("\n💬 **Chat Info:**")
                user_info.append(f"📝 **Nama:** {chat_title}")
                user_info.append(f"🆔 **Chat ID:** `{chat_id}`")
            
            # Add message info
            user_info.append("\n📨 **Message Info:**")
            user_info.append(f"🆔 **Message ID:** `{event.message.id}`")
            user_info.append(f"📅 **Tanggal:** {format_date(event.message.date)}")
            
            # Create card format
            card = f"""
┌─────────────────────
│ 👤 USER ID CARD
├─────────────────────
{chr(10).join([f'│ {line}' for line in user_info])}
├─────────────────────
│ 📊 Status: Online
│ ⚡ Bot: Payment Bot v3.1.0
└─────────────────────
            """
            
            await event.reply(card, parse_mode='markdown')
            
        except Exception as e:
            logger.error(f"ID handler error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== MUTE HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.mute(?:\s+(.+))?$'))
    async def mute_handler(event):
        """Permanently mute user in group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .mute hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            reason = ""
            
            # Parse arguments
            args = event.pattern_match.group(1)
            if args:
                parts = args.strip().split(maxsplit=1)
                user_input = parts[0]
                reason = parts[1] if len(parts) > 1 else "Pelanggaran aturan grup"
            
            # Check if replying to a message
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
                if args:
                    reason = args.strip()
            
            # Or check if username/ID provided
            elif user_input:
                if user_input.isdigit():
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format: `.mute @username [alasan]` atau reply pesan user")
                    return
            else:
                await event.reply("❌ Format: `.mute @username [alasan]` atau reply pesan user")
                return
            
            if not target_user:
                await event.reply("❌ User tidak ditemukan!")
                return
            
            # Check if trying to mute self
            if target_user == event.sender_id:
                await event.reply("❌ Tidak bisa mute diri sendiri!")
                return
            
            # Check if trying to mute bot
            me = await client.get_me()
            if target_user == me.id:
                await event.reply("❌ Tidak bisa mute bot!")
                return
            
            # Apply mute
            try:
                # Mute user in Telegram (permanent)
                await client.edit_permissions(
                    event.chat_id,
                    target_user,
                    send_messages=False
                )
                
                # Also add to bot's mute list
                state.ban_user(target_user, reason)
                
                # Get user info for message
                try:
                    user_entity = await client.get_entity(target_user)
                    user_name = user_entity.first_name or "User"
                    if user_entity.username:
                        user_name += f" (@{user_entity.username})"
                except:
                    user_name = f"User ID: {target_user}"
                
                mute_message = f"✅ User {user_name} berhasil di-mute secara permanen!"
                if reason:
                    mute_message += f"\n📌 Alasan: {reason}"
                
                await event.reply(mute_message)
                
                # Log to group
                await send_log(
                    client,
                    f"🔇 USER DI-MUTE PERMANEN\n"
                    f"👤 User: {user_name}\n"
                    f"💬 Chat: {event.chat_id}\n"
                    f"📌 Reason: {reason}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk mute user!")
                elif "USER_NOT_PARTICIPANT" in error_msg:
                    await event.reply("❌ User tidak ditemukan dalam grup!")
                else:
                    await event.reply(f"❌ Gagal mute user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Mute error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== UNBAN HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.unban(?:\s+(.+))?$'))
    async def unban_handler(event):
        """Unban user from group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .unban hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            
            # Check if replying to a message
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
            
            # Or check if username/ID provided
            elif event.pattern_match.group(1):
                user_input = event.pattern_match.group(1).strip()
                
                if user_input.isdigit():
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format: `.unban @username` atau reply pesan user")
                    return
            else:
                await event.reply("❌ Format: `.unban @username` atau reply pesan user")
                return
            
            if not target_user:
                await event.reply("❌ User tidak ditemukan!")
                return
            
            # Check if trying to unban self
            if target_user == event.sender_id:
                await event.reply("❌ Tidak perlu unban diri sendiri!")
                return
            
            # Check if trying to unban bot
            me = await client.get_me()
            if target_user == me.id:
                await event.reply("❌ Bot tidak bisa di-ban/unban!")
                return
            
            # Unban user
            try:
                # Unban user in Telegram
                await client.edit_permissions(
                    event.chat_id,
                    target_user,
                    view_messages=True,
                    send_messages=True
                )
                
                # Remove from bot's ban list
                state.unban_user(target_user)
                
                # Get user info for message
                try:
                    user_entity = await client.get_entity(target_user)
                    user_name = user_entity.first_name or "User"
                    if user_entity.username:
                        user_name += f" (@{user_entity.username})"
                except:
                    user_name = f"User ID: {target_user}"
                
                await event.reply(f"✅ User {user_name} berhasil di-unban! User sekarang bisa bergabung kembali ke grup.")
                
                # Log to group
                await send_log(
                    client,
                    f"🔓 USER DI-UNBAN\n"
                    f"👤 User: {user_name}\n"
                    f"💬 Chat: {event.chat_id}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk unban user!")
                else:
                    await event.reply(f"❌ Gagal unban user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Unban error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== INSTALL PANEL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.installpanel (.+)$'))
    async def installpanel_handler(event):
        """Install Pterodactyl Panel"""
        if event.sender_id != config.OWNER_ID:
            return
        
        args = event.pattern_match.group(1).strip()
        parts = args.split(',')
        
        if len(parts) < 3:
            await event.reply("❌ Format: `.installpanel ip,password,domainpanel`\nContoh: `.installpanel 1.1.1.1,password123,panel.domain.com`")
            return
        
        ip = parts[0].strip()
        password = parts[1].strip()
        domain_panel = parts[2].strip()
        
        # Validate IP format
        if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip):
            await event.reply("❌ Format IP tidak valid!")
            return
        
        # Validate domain
        if not re.match(r'^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', domain_panel):
            await event.reply("❌ Format domain tidak valid!")
            return
        
        await event.reply(f"🚀 Memulai instalasi panel...\n📡 IP: `{ip}`\n🌐 Domain: `{domain_panel}`")
        
        # Start installation
        success = await install_panel(event.chat_id, ip, password, domain_panel, client)
        
        if success:
            await event.reply("✅ Instalasi panel selesai!")
        else:
            await event.reply("❌ Instalasi panel gagal!")
    
    # ========== INSTALL WINGS HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.installwings (.+)$'))
    async def installwings_handler(event):
        """Install Pterodactyl Wings"""
        if event.sender_id != config.OWNER_ID:
            return
        
        args = event.pattern_match.group(1).strip()
        parts = args.split(',')
        
        if len(parts) < 4:
            await event.reply("❌ Format: `.installwings ip,password,domainpanel,domainnode`\nContoh: `.installwings 1.1.1.1,password123,panel.domain.com,node.domain.com`")
            return
        
        ip = parts[0].strip()
        password = parts[1].strip()
        domain_panel = parts[2].strip()
        domain_node = parts[3].strip()
        
        # Validate IP format
        if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip):
            await event.reply("❌ Format IP tidak valid!")
            return
        
        # Validate domains
        if not re.match(r'^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', domain_panel):
            await event.reply("❌ Format domain panel tidak valid!")
            return
        
        if not re.match(r'^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', domain_node):
            await event.reply("❌ Format domain node tidak valid!")
            return
        
        await event.reply(f"🚀 Memulai instalasi wings...\n📡 IP: `{ip}`\n🌐 Panel: `{domain_panel}`\n🛰️ Node: `{domain_node}`")
        
        # Start installation
        success = await install_wings(event.chat_id, ip, password, domain_panel, domain_node, client)
        
        if success:
            await event.reply("✅ Instalasi wings selesai!")
        else:
            await event.reply("❌ Instalasi wings gagal!")
    
    # ========== ADDBL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.addbl$'))
    async def addbl_handler(event):
        """Add chat to blacklist"""
        if event.sender_id != config.OWNER_ID:
            return
        
        try:
            chat_id = str(event.chat_id)
            chat_name = ""
            
            # Get chat name
            if event.is_group:
                chat = await event.get_chat()
                chat_name = chat.title if hasattr(chat, 'title') else "Group Chat"
            elif event.is_channel:
                chat = await event.get_chat()
                chat_name = chat.title if hasattr(chat, 'title') else "Channel"
            else:
                chat_name = "Private Chat"
            
            # Add to blacklist
            if state.add_to_blacklist(chat_id):
                message = f"<blockquote>✅ Chat <b>{chat_name}</b> ditambahkan ke blacklist.</blockquote>"
                await event.reply(with_footer(message), parse_mode='html')
            else:
                message = f"<blockquote>⚠️ Chat <b>{chat_name}</b> sudah ada di blacklist.</blockquote>"
                await event.reply(with_footer(message), parse_mode='html')
                
        except Exception as e:
            logger.error(f"Addbl error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== DELBL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.delbl$'))
    async def delbl_handler(event):
        """Remove chat from blacklist"""
        if event.sender_id != config.OWNER_ID:
            return
        
        try:
            chat_id = str(event.chat_id)
            chat_name = ""
            
            # Get chat name
            if event.is_group:
                chat = await event.get_chat()
                chat_name = chat.title if hasattr(chat, 'title') else "Group Chat"
            elif event.is_channel:
                chat = await event.get_chat()
                chat_name = chat.title if hasattr(chat, 'title') else "Channel"
            else:
                chat_name = "Private Chat"
            
            # Remove from blacklist
            if state.remove_from_blacklist(chat_id):
                message = f"<blockquote>✅ Chat <b>{chat_name}</b> dihapus dari blacklist.</blockquote>"
                await event.reply(with_footer(message), parse_mode='html')
            else:
                message = f"<blockquote>⚠️ Chat <b>{chat_name}</b> tidak ada di blacklist.</blockquote>"
                await event.reply(with_footer(message), parse_mode='html')
                
        except Exception as e:
            logger.error(f"Delbl error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== CFD GROUP HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.cfd group$'))
    async def cfd_group_handler(event):
        """Forward message to all groups"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_reply:
            await event.reply("⚠️ Harus reply pesan!", parse_mode='html')
            return
        
        try:
            reply_msg = await event.get_reply_message()
            
            # Get all dialogs
            dialogs = await client.get_dialogs()
            
            success_count = 0
            fail_count = 0
            
            # Forward to all groups
            for dialog in dialogs:
                if dialog.is_group and not state.is_blacklisted(str(dialog.id)):
                    try:
                        await client.forward_messages(
                            dialog.id,
                            reply_msg.id,
                            from_peer=event.chat_id
                        )
                        success_count += 1
                        await asyncio.sleep(0.5)  # Delay to avoid flood
                    except Exception as e:
                        fail_count += 1
                        logger.error(f"Failed to forward to {dialog.id}: {str(e)}")
            
            # Send result
            result_message = f"""
<blockquote>✅ Pesan berhasil diteruskan ke grup!</blockquote>
<blockquote>DETAIL CFD GROUP
SUCCESS : {success_count} pesan terkirim
GAGAL   : {fail_count} pesan gagal terkirim</blockquote>
            """
            
            await event.reply(with_footer(result_message), parse_mode='html')
            
        except Exception as e:
            logger.error(f"CFD group error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== TAGALL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.tagall(?:\s+(.+))?$'))
    async def tagall_handler(event):
        """Tag all users in group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("⚠️ Hanya bisa digunakan di grup!", parse_mode='html')
            return
        
        if event.chat_id in state.tagall_active and state.tagall_active[event.chat_id]:
            await event.reply("⚠️ Tagall sedang berjalan di grup ini.", parse_mode='html')
            return
        
        try:
            state.tagall_active[event.chat_id] = True
            
            custom_text = event.pattern_match.group(1) or ""
            
            # Get all participants
            participants = await client.get_participants(event.chat_id)
            
            # Filter out bots and deleted accounts
            users = []
            for user in participants:
                if not getattr(user, 'deleted', False) and not getattr(user, 'bot', False):
                    users.append(user)
            
            # Shuffle users
            random.shuffle(users)
            
            # Create mentions with random emojis
            mentions = []
            for user in users:
                emoji = random_emoji()
                mentions.append(f'<a href="tg://user?id={user.id}">{emoji}</a>')
            
            # Split into batches of 5
            batch_size = 5
            batches = [mentions[i:i + batch_size] for i in range(0, len(mentions), batch_size)]
            
            async def send_batches():
                for i, batch in enumerate(batches):
                    if not state.tagall_active.get(event.chat_id, False):
                        break
                    
                    message_text = f"<blockquote>{custom_text}</blockquote>\n\n" if custom_text else ""
                    message_text += " ".join(batch)
                    
                    try:
                        await client.send_message(
                            event.chat_id,
                            with_footer(message_text),
                            parse_mode='html'
                        )
                    except Exception as e:
                        logger.error(f"Failed to send tagall batch: {str(e)}")
                    
                    # Delay between batches
                    await asyncio.sleep(2)
                
                # Cleanup
                if event.chat_id in state.tagall_active:
                    state.tagall_active[event.chat_id] = False
            
            # Start sending batches
            asyncio.create_task(send_batches())
            
            await event.reply(f"🚀 Memulai tagall {len(users)} user...", parse_mode='html')
            
        except Exception as e:
            logger.error(f"Tagall error: {str(e)}")
            state.tagall_active[event.chat_id] = False
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== AUTOCFD HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.autocfd$'))
    async def autocfd_handler(event):
        """Start auto CFD"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if state.auto_cfd_state["running"]:
            await event.reply("⚠️ AUTO CFD sudah berjalan.", parse_mode='html')
            return
        
        if not event.is_reply:
            await event.reply("⚠️ Harus reply pesan!", parse_mode='html')
            return
        
        try:
            reply_msg = await event.get_reply_message()
            
            # Save state
            state.auto_cfd_state["running"] = True
            state.auto_cfd_state["reply_msg_id"] = reply_msg.id
            state.auto_cfd_state["origin_chat_id"] = event.chat_id
            
            await event.reply("✅ AUTO CFD diaktifkan! Bot akan forward pesan setiap 30 menit.", parse_mode='html')
            
            # Start auto CFD task
            asyncio.create_task(run_auto_cfd(client))
            
        except Exception as e:
            logger.error(f"Auto CFD error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== STOPCFD HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.stopcfd$'))
    async def stopcfd_handler(event):
        """Stop auto CFD"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not state.auto_cfd_state["running"]:
            await event.reply("❌ AUTO CFD tidak sedang berjalan.", parse_mode='html')
            return
        
        # Stop auto CFD
        state.auto_cfd_state["running"] = False
        state.auto_cfd_state["reply_msg_id"] = None
        state.auto_cfd_state["origin_chat_id"] = None
        
        await event.reply("✅ AUTO CFD berhasil dihentikan.")
    
    # ========== MENU HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.menu$'))
    async def menu_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        stats = state.get_stats()
        
        menu_text = f"""
```🤖 PAYMENT BOT MENU v3.1.0```

```OWNER COMMANDS:
.afk [alasan] - Aktifkan AFK Mode
.unafk - Matikan AFK Mode
.status - Status bot lengkap
.stats - Statistik bot

ADMIN COMMANDS:
.cadmin username password - Buat admin user panel
.done [barang|harga|pembayaran|tanggal] - Kirim pesan done
.done [barang] - Isi step by step
.donecancel - Batalkan proses done

USER MANAGEMENT:
.id - Get user ID card (reply atau sendiri)
.mute @username [alasan] - Mute user permanen
.unban @username - Unban user dari grup
.tmute [waktu] @username [alasan] - Temporary mute
.unmute @username - Unmute user
Format waktu: 1d, 2h, 30m, 45s

SPAM COMMANDS:
.spam [jumlah] [teks] - Spam di chat saat ini
.spamto [jumlah] @username [teks] - Spam ke user tertentu
.spamreply [jumlah] [teks] - Spam reply ke pesan (reply dulu)
.spamfile [jumlah] [caption] - Spam file (reply ke file)

AI COMMANDS:
.ai - Test AI response
.aistats - AI statistics

PAYMENT:
.pay <nominal> - Buat pembayaran QRIS
.saldo - Cek saldo AtlanticH2H
.tarik <nomor> - Tarik Dana otomatis
.tarikmanual <nomor> <kode> - Tarik manual

PANEL MANAGEMENT:
.1gb <username> <nodejs/python> - Panel 1GB
.2gb <username> <nodejs/python> - Panel 2GB
.3gb <username> <nodejs/python> - Panel 3GB
.4gb <username> <nodejs/python> - Panel 4GB
.5gb <username> <nodejs/python> - Panel 5GB
.6gb <username> <nodejs/python> - Panel 6GB
.7gb <username> <nodejs/python> - Panel 7GB
.8gb <username> <nodejs/python> - Panel 8GB
.9gb <username> <nodejs/python> - Panel 9GB
.10gb <username> <nodejs/python> - Panel 10GB
.unli <username> <nodejs/python> - Panel unlimited

PANEL INSTALLATION:
.installpanel ip,password,domain - Install Pterodactyl Panel
.installwings ip,password,paneldomain,nodedomain - Install Wings

MANAGEMENT:
.listpanel - List semua server
.delpanel <id> - Hapus server
.backup - Backup data
.restore - Restore data

SECURITY:
.hbpanel ip,password - Hackback panel
.testvps ip,password - Test VPS

BLACKLIST:
.addbl - Tambah chat ke blacklist
.delbl - Hapus chat dari blacklist

FORWARDING:
.cfd group - Forward pesan ke semua grup (reply)
.autocfd - Auto forward setiap 30 menit (reply)
.stopcfd - Stop auto forward

MENTION:
.tagall [teks] - Tag semua user di grup

SETTINGS:
.session - Lihat session
.setloggroup - Set grup log (reply)

DONE CHANNELS:
.adddone @channel - Tambah channel done
.listdone - List channel done
.deldone @channel - Hapus channel done

STATISTICS:
• Uptime: {stats['uptime']}
• Transactions: {stats['transactions_processed']}
• Withdrawals: {stats['withdrawals_processed']}
• Panels: {stats['panels_created']}
• AI Responses: {stats['ai_responses']}
• Blacklist: {stats['blacklist_count']} chats
• AI Mode: {'🟢 ON' if stats['afk_mode'] else '🔴 OFF'}

Owner: @andinsukaapink
Version: 3.1.0
Time: {datetime.now().strftime('%H:%M:%S')}```
"""
        await event.reply(menu_text)
    
    # ========== AFK HANDLERS ==========
    @client.on(events.NewMessage(pattern=r'^\.afk(?:\s+(.+))?$'))
    async def afk_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        reason = event.pattern_match.group(1) or "Sedang sibuk, AI yang menangani"
        state.set_afk_mode(reason)
        
        await event.reply(
            f"🤖 AFK MODE DIAKTIFKAN!\n\n"
            f"📝 Alasan: {reason}\n"
            f"⏰ Mulai: {format_date(state.afk_since)}\n\n"
            f"✅ Bot sekarang akan menangani:\n"
            f"• Semua chat dari user\n"
            f"• Pertanyaan produk\n"
            f"• Konfirmasi transaksi\n"
            f"• Penanganan komplain\n\n"
            f"👑 Owner bisa istirahat, bot yang urus semua! 🎯"
        )
        
        await send_log(client, f"🤖 AFK MODE AKTIF - Reason: {reason}")
    
    @client.on(events.NewMessage(pattern=r'^\.unafk$'))
    async def unafk_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        if not state.afk_mode:
            await event.reply("🤖 AFK mode belum aktif!")
            return
        
        duration = datetime.now() - state.afk_since
        hours = duration.seconds // 3600
        minutes = (duration.seconds % 3600) // 60
        seconds = duration.seconds % 60
        
        state.disable_afk_mode()
        
        await event.reply(
            f"✅ AFK MODE DIMATIKAN\n\n"
            f"⏱️ Durasi AFK aktif: {hours} jam {minutes} menit {seconds} detik\n"
            f"🤖 Total AI responses: {state.stats['ai_responses']}\n\n"
            f"👑 Owner kembali online!"
        )
        
        await send_log(client, "🤖 AFK MODE DIMATIKAN - Owner kembali online")
    
    # ========== AFK AUTO-REPLY ==========
    @client.on(events.NewMessage(incoming=True))
    async def afk_auto_reply_handler(event):
        """Handle AFK auto-reply for messages"""
        
        # Skip jika bukan dari user lain
        if event.sender_id == config.OWNER_ID:
            return
        
        # Skip jika AFK mode tidak aktif
        if not state.afk_mode:
            return
        
        # Skip jika pesan adalah command
        message_text = event.message.text or ""
        if message_text.startswith('.'):
            return
        
        # Hitung durasi AFK
        afk_duration = datetime.now() - state.afk_since
        total_seconds = int(afk_duration.total_seconds())
        
        # Format durasi
        if total_seconds >= 3600:
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            duration_str = f"{hours} jam {minutes} menit"
        elif total_seconds >= 60:
            minutes = total_seconds // 60
            seconds = total_seconds % 60
            duration_str = f"{minutes} menit {seconds} detik"
        else:
            duration_str = f"{total_seconds} detik"
        
        # Case 1: Pesan langsung (private chat)
        if event.is_private:
            reply_text = (
                f"😴 <b>Sedang AFK</b>\n"
                f"📌 <b>Alasan:</b> {state.afk_reason}\n"
                f"⏱️ <b>Durasi:</b> {duration_str}\n\n"
                f"Mohon tunggu ya, akan dibalas nanti!"
            )
            await event.reply(reply_text, parse_mode='html')
            return
        
        # Case 2: Reply pesan owner di grup
        if event.is_group and event.message.reply_to_msg_id:
            try:
                reply_msg = await event.get_reply_message()
                if reply_msg and reply_msg.sender_id == config.OWNER_ID:
                    reply_text = (
                        f"😴 <b>Sedang AFK</b>\n"
                        f"📌 <b>Alasan:</b> {state.afk_reason}\n"
                        f"⏱️ <b>Durasi:</b> {duration_str}\n\n"
                        f"Owner sedang tidak aktif, akan dibalas nanti!"
                    )
                    await event.reply(reply_text, parse_mode='html')
                    return
            except:
                pass
    
    # ========== CREATE ADMIN HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.cadmin (\w+) (.+)$'))
    async def create_admin_handler(event):
        """Create admin user in panel"""
        if event.sender_id != config.OWNER_ID:
            return
        
        try:
            panel_name = event.pattern_match.group(1).strip().lower()
            password = event.pattern_match.group(2).strip()
            
            if len(password) < 8:
                await event.reply("❌ Password minimal 8 karakter!")
                return
            
            processing_msg = await event.reply("🔄 Membuat admin user...")
            
            panel_url = f"https://{config.PANEL_DOMAIN}"
            ssl_context = ssl.create_default_context(cafile=certifi.where())
            
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(30.0),
                verify=ssl_context
            ) as http_client:
                response = await http_client.post(
                    f"{panel_url}/api/application/users",
                    headers={
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {config.PANEL_API_KEY}"
                    },
                    json={
                        "email": f"{panel_name}@admin.king",
                        "username": panel_name,
                        "first_name": panel_name,
                        "last_name": "admin",
                        "language": "en",
                        "root_admin": True,
                        "password": password
                    }
                )
            
            if response.status_code == 201:
                user_data = response.json()
                admin_data = user_data.get('attributes', {})
                
                success_msg = (
                    f"✅ ADMIN USER BERHASIL DIBUAT\n\n"
                    f"👑 Status: Root Admin\n"
                    f"👤 Username: {panel_name}\n"
                    f"🔑 Password: {password}\n"
                    f"📧 Email: {panel_name}@admin.king\n"
                    f"🆔 User ID: {admin_data.get('id', 'N/A')}\n\n"
                    f"🌐 Panel: {config.PANEL_DOMAIN}\n"
                    f"🔐 Simpan credentials dengan aman!"
                )
                
                await processing_msg.edit(success_msg)
                
                # Log to group
                await send_log(
                    client,
                    f"👑 ADMIN USER DIBUAT\n"
                    f"👤 Username: {panel_name}\n"
                    f"🆔 ID: {admin_data.get('id', 'N/A')}"
                )
                
            else:
                await processing_msg.edit(
                    f"❌ Gagal membuat admin user\n"
                    f"Status: {response.status_code}\n"
                    f"Response: {response.text[:200]}"
                )
                
        except Exception as e:
            logger.error(f"Create admin error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== DONE HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.done(?:\s+(.+))?$'))
    async def done_handler(event):
        """Create and send done message to channels"""
        if event.sender_id != config.OWNER_ID:
            return
        
        try:
            args = event.pattern_match.group(1)
            
            if not args:
                # Jika tanpa argumen, minta input step by step
                await event.reply(
                    "📝 **DONE TEMPLATE CREATOR**\n\n"
                    "Silakan isi data berikut secara berurutan:\n\n"
                    "1. 📦 **Nama Barang**\n"
                    "   Contoh: `Panel NodeJS 2GB`\n\n"
                    "2. 💵 **Harga**\n"
                    "   Contoh: `Rp 50.000`\n\n"
                    "3. 💳 **Metode Pembayaran**\n"
                    "   Contoh: `QRIS` atau `DANA`\n\n"
                    "4. 📅 **Tanggal** (opsional, default: sekarang)\n"
                    "   Contoh: `2024-01-01 12:00:00`\n\n"
                    "**Atau gunakan format lengkap:**\n"
                    "`.done barang|harga|pembayaran|tanggal`"
                )
                return
            
            # Parse format: .done barang|harga|pembayaran|tanggal
            if '|' in args:
                parts = args.split('|')
                if len(parts) < 3:
                    await event.reply("❌ Format salah!\nContoh: `.done Panel 2GB|Rp 50.000|QRIS|2024-01-01`")
                    return
                
                product = parts[0].strip()
                price = parts[1].strip()
                payment_method = parts[2].strip()
                date = parts[3].strip() if len(parts) > 3 else datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                await send_done_message(event, product, price, payment_method, date)
                
            else:
                # Jika hanya 1 argumen, anggap itu nama barang dan minta sisanya
                product = args.strip()
                
                async with client.conversation(event.chat_id, timeout=120) as conv:
                    try:
                        # Minta harga
                        await conv.send_message(f"📦 Barang: **{product}**\n\n💰 **Masukkan harga:**\nContoh: `Rp 50.000`")
                        price_msg = await conv.get_response()
                        price = price_msg.text.strip()
                        
                        # Minta metode pembayaran
                        await conv.send_message(f"📦 Barang: **{product}**\n💰 Harga: **{price}**\n\n💳 **Masukkan metode pembayaran:**\nContoh: `QRIS`")
                        payment_msg = await conv.get_response()
                        payment_method = payment_msg.text.strip()
                        
                        # Minta tanggal (opsional)
                        await conv.send_message(f"📦 Barang: **{product}**\n💰 Harga: **{price}**\n💳 Pembayaran: **{payment_method}**\n\n📅 **Masukkan tanggal (tekan enter untuk skip):**\nContoh: `2024-01-01 12:00:00`")
                        date_msg = await conv.get_response()
                        date = date_msg.text.strip()
                        
                        if not date:
                            date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        
                        # Hapus pesan konversasi
                        try:
                            await price_msg.delete()
                            await payment_msg.delete()
                            await date_msg.delete()
                        except:
                            pass
                        
                        await send_done_message(event, product, price, payment_method, date)
                        
                    except asyncio.TimeoutError:
                        await event.reply("❌ Waktu habis! Proses dibatalkan.")
                    except Exception as e:
                        await event.reply(f"❌ Error: {str(e)}")
                        
        except Exception as e:
            logger.error(f"Done handler error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    async def send_done_message(event, product: str, price: str, payment_method: str, date: str):
        """Send done message to all done channels"""
        if not state.done_channels:
            await event.reply("❌ Belum ada channel done yang ditambahkan!\nGunakan: `.adddone @channel_username`")
            return
        
        # Format pesan
        done_message = f"""✅ ORDER SELESAI

📦 Barang: {product}
💵 Harga: {price}
💳 Pembayaran: {payment_method}
📅 Tanggal: {date}

🎉 Terima kasih telah order!
By: PAYMENT BOT PAYMENT 🤖"""
        
        processing_msg = await event.reply(f"📤 Mengirim ke {len(state.done_channels)} channel...")
        
        # Kirim ke semua channel done
        success_count = 0
        failed_channels = []
        
        for channel in state.done_channels:
            try:
                await client.send_message(
                    channel,
                    done_message
                )
                success_count += 1
                await asyncio.sleep(0.5)  # Delay antar pengiriman
            except Exception as e:
                failed_channels.append((channel, str(e)))
                logger.error(f"Failed to send to {channel}: {str(e)}")
        
        # Report hasil
        result_msg = f"✅ **DONE MESSAGE SENT**\n\n"
        result_msg += f"📦 **Barang:** {product}\n"
        result_msg += f"💰 **Harga:** {price}\n"
        result_msg += f"💳 **Pembayaran:** {payment_method}\n"
        result_msg += f"📅 **Tanggal:** {date}\n\n"
        result_msg += f"📊 **Status:** {success_count}/{len(state.done_channels)} channel berhasil\n"
        
        if failed_channels:
            result_msg += "\n❌ **Gagal dikirim ke:**\n"
            for channel, error in failed_channels[:3]:  # Tampilkan maksimal 3 error
                result_msg += f"• {channel}: {error[:50]}\n"
            if len(failed_channels) > 3:
                result_msg += f"• ... dan {len(failed_channels) - 3} channel lainnya\n"
        
        await processing_msg.edit(result_msg)
        
        # Log to group
        await send_log(
            client,
            f"✅ DONE MESSAGE SENT\n"
            f"📦 Product: {product}\n"
            f"💰 Price: {price}\n"
            f"📤 Sent to: {success_count} channels"
        )
    
    # ========== DONE CANCEL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.donecancel$'))
    async def done_cancel_handler(event):
        """Cancel ongoing done process"""
        if event.sender_id != config.OWNER_ID:
            return
        
        # Hapus data done dari session
        user_session = state.user_sessions.get(event.sender_id, {})
        if "done_data" in user_session:
            user_session.pop("done_data")
            await event.reply("✅ Proses done dibatalkan!")
        else:
            await event.reply("❌ Tidak ada proses done yang aktif!")
    
    # ========== SPAM HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.spam(?:\s+(\d+))?\s+(.+)$'))
    async def spam_handler(event):
        """Spam messages without confirmation"""
        if event.sender_id != config.OWNER_ID:
            return
        
        # Check spam cooldown
        if not state.can_spam(event.sender_id):
            await event.reply("⏳ Tunggu sebentar sebelum menggunakan spam lagi! (Cooldown 1 menit)")
            return
        
        try:
            # Parse arguments
            args = event.pattern_match.group(0).split(maxsplit=2)
            
            if len(args) < 3:
                await event.reply(
                    "❌ **Format:** `.spam [jumlah] [teks]`\n"
                    "**Contoh:**\n"
                    "• `.spam 5 Hello World`\n"
                    "• `.spam 10 @username check this out`"
                )
                return
            
            # Extract count and text
            count_part = args[1]
            text = args[2]
            
            # Parse count
            if count_part.isdigit():
                count = int(count_part)
            else:
                # Jika tidak ada angka, default ke 1
                count = 1
                text = event.pattern_match.group(1)  # Ambil semua text
            
            # Validasi count
            if count <= 0:
                await event.reply("❌ Jumlah harus lebih dari 0!")
                return
            
            if count > config.MAX_SPAM_MESSAGES:
                await event.reply(f"❌ Maksimal {config.MAX_SPAM_MESSAGES} pesan per spam!")
                return
            
            # Cek jika di group atau private
            if event.is_group:
                target_chat = event.chat_id
            elif event.is_private:
                target_chat = event.chat_id
            else:
                await event.reply("❌ Hanya bisa digunakan di group atau private chat!")
                return
            
            # Mulai spam langsung
            processing_msg = await event.reply(f"🚀 **MEMULAI SPAM**\n\n"
                                              f"📊 Jumlah: {count} pesan\n"
                                              f"⏱️ Delay: {config.SPAM_DELAY}s\n"
                                              f"📤 Target: {'Group' if event.is_group else 'Private'}")
            
            sent_count = 0
            failed_count = 0
            
            for i in range(count):
                try:
                    await client.send_message(target_chat, text)
                    sent_count += 1
                    
                    # Update progress setiap 10 pesan
                    if (i + 1) % 10 == 0:
                        progress = f"📤 {i + 1}/{count} ({((i + 1) / count * 100):.1f}%)"
                        try:
                            await processing_msg.edit(f"🚀 **SPAM IN PROGRESS**\n\n"
                                                     f"📊 Target: {count} pesan\n"
                                                     f"✅ Terkirim: {i + 1}\n"
                                                     f"📈 Progress: {progress}")
                        except:
                            pass
                    
                    # Delay antar pesan
                    await asyncio.sleep(config.SPAM_DELAY)
                    
                except Exception as e:
                    failed_count += 1
                    logger.error(f"Failed to send spam message {i + 1}: {str(e)}")
                    
                    # Jika error flood wait, tunggu sebentar
                    if "FLOOD_WAIT" in str(e):
                        try:
                            wait_time = int(str(e).split()[-1])
                            await asyncio.sleep(wait_time + 1)
                        except:
                            await asyncio.sleep(5)
            
            # Report hasil
            result_msg = f"✅ **SPAM COMPLETE**\n\n"
            result_msg += f"📊 **Target:** {count} pesan\n"
            result_msg += f"✅ **Berhasil:** {sent_count} pesan\n"
            
            if failed_count > 0:
                result_msg += f"❌ **Gagal:** {failed_count} pesan\n"
            
            result_msg += f"⏱️ **Durasi:** {count * config.SPAM_DELAY:.1f} detik\n"
            result_msg += f"📝 **Pesan:**\n`{text[:50]}{'...' if len(text) > 50 else ''}`"
            
            await processing_msg.edit(result_msg)
            
            # Log to group
            await send_log(
                client,
                f"🚀 SPAM EXECUTED\n"
                f"📊 Count: {count} messages\n"
                f"✅ Success: {sent_count}\n"
                f"❌ Failed: {failed_count}\n"
                f"💬 Target: {'Group' if event.is_group else 'Private'}\n"
                f"📝 Text: {text[:100]}..."
            )
            
        except Exception as e:
            logger.error(f"Spam error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== SPAMTO HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.spamto(?:\s+(\d+))?\s+@?(\w+)\s+(.+)$'))
    async def spamto_handler(event):
        """Spam to specific user/group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        # Check spam cooldown
        if not state.can_spam(event.sender_id):
            await event.reply("⏳ Tunggu sebentar sebelum menggunakan spam lagi! (Cooldown 1 menit)")
            return
        
        try:
            # Parse arguments
            parts = event.pattern_match.group(0).split(maxsplit=3)
            
            if len(parts) < 4:
                await event.reply(
                    "❌ **Format:** `.spamto [jumlah] @username [teks]`\n"
                    "**Contoh:** `.spamto 5 @username Hello World`"
                )
                return
            
            # Extract parameters
            count_part = parts[1]
            target = parts[2].replace('@', '')
            text = parts[3]
            
            # Parse count
            if count_part.isdigit():
                count = int(count_part)
            else:
                # Jika format: .spamto @username text
                count = 1
                target = parts[1].replace('@', '')
                text = ' '.join(parts[2:])
            
            # Validasi count
            if count <= 0:
                await event.reply("❌ Jumlah harus lebih dari 0!")
                return
            
            if count > config.MAX_SPAM_MESSAGES:
                await event.reply(f"❌ Maksimal {config.MAX_SPAM_MESSAGES} pesan per spam!")
                return
            
            # Cari target
            try:
                target_entity = await client.get_entity(target)
            except Exception as e:
                await event.reply(f"❌ Tidak dapat menemukan target: @{target}\nError: {str(e)}")
                return
            
            processing_msg = await event.reply(f"🚀 **MEMULAI SPAM KE** @{target}\n\n"
                                              f"📊 Jumlah: {count} pesan\n"
                                              f"⏱️ Delay: {config.SPAM_DELAY}s")
            
            sent_count = 0
            failed_count = 0
            
            for i in range(count):
                try:
                    await client.send_message(target_entity.id, text)
                    sent_count += 1
                    
                    # Update progress setiap 5 pesan
                    if (i + 1) % 5 == 0:
                        progress = f"📤 {i + 1}/{count} ({((i + 1) / count * 100):.1f}%)"
                        try:
                            await processing_msg.edit(f"🚀 **SPAM KE** @{target}\n\n"
                                                     f"📊 Target: {count} pesan\n"
                                                     f"✅ Terkirim: {i + 1}\n"
                                                     f"📈 Progress: {progress}")
                        except:
                            pass
                    
                    # Delay antar pesan
                    await asyncio.sleep(config.SPAM_DELAY)
                    
                except Exception as e:
                    failed_count += 1
                    logger.error(f"Failed to spam to @{target}: {str(e)}")
                    
                    # Jika error flood wait, tunggu sebentar
                    if "FLOOD_WAIT" in str(e):
                        try:
                            wait_time = int(str(e).split()[-1])
                            await asyncio.sleep(wait_time + 1)
                        except:
                            await asyncio.sleep(5)
            
            # Report hasil
            result_msg = f"✅ **SPAM COMPLETE**\n\n"
            result_msg += f"🎯 **Target:** @{target}\n"
            result_msg += f"📊 **Target:** {count} pesan\n"
            result_msg += f"✅ **Berhasil:** {sent_count} pesan\n"
            
            if failed_count > 0:
                result_msg += f"❌ **Gagal:** {failed_count} pesan\n"
            
            result_msg += f"⏱️ **Durasi:** {count * config.SPAM_DELAY:.1f} detik\n"
            result_msg += f"📝 **Pesan:**\n`{text[:50]}{'...' if len(text) > 50 else ''}`"
            
            await processing_msg.edit(result_msg)
            
            # Log to group
            await send_log(
                client,
                f"🚀 SPAM TO USER\n"
                f"🎯 Target: @{target}\n"
                f"📊 Count: {count} messages\n"
                f"✅ Success: {sent_count}\n"
                f"❌ Failed: {failed_count}\n"
                f"📝 Text: {text[:100]}..."
            )
            
        except Exception as e:
            logger.error(f"Spamto error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== SPAM REPLY HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.spamreply(?:\s+(\d+))?\s+(.+)$'))
    async def spamreply_handler(event):
        """Spam by replying to a message"""
        if event.sender_id != config.OWNER_ID:
            return
        
        # Check spam cooldown
        if not state.can_spam(event.sender_id):
            await event.reply("⏳ Tunggu sebentar sebelum menggunakan spam lagi! (Cooldown 1 menit)")
            return
        
        if not event.is_reply:
            await event.reply("❌ Reply pesan yang ingin di-spam!")
            return
        
        try:
            reply_msg = await event.get_reply_message()
            chat_id = reply_msg.chat_id
            reply_to = reply_msg.id
            
            # Parse arguments
            args = event.pattern_match.group(0).split(maxsplit=2)
            
            if len(args) < 3:
                await event.reply(
                    "❌ **Format:** `.spamreply [jumlah] [teks]`\n"
                    "**Contoh:** `.spamreply 5 Hello World`"
                )
                return
            
            # Extract parameters
            count_part = args[1]
            text = args[2]
            
            # Parse count
            if count_part.isdigit():
                count = int(count_part)
            else:
                count = 1
                text = event.pattern_match.group(1)
            
            # Validasi count
            if count <= 0:
                await event.reply("❌ Jumlah harus lebih dari 0!")
                return
            
            if count > config.MAX_SPAM_MESSAGES:
                await event.reply("❌ Maksimal 50 pesan per spam!")
                return
            
            processing_msg = await event.reply(f"🚀 **MEMULAI SPAM REPLY**\n\n"
                                              f"📊 Jumlah: {count} pesan\n"
                                              f"⏱️ Delay: {config.SPAM_DELAY}s\n"
                                              f"💬 Reply to: Pesan #{reply_to}")
            
            sent_count = 0
            failed_count = 0
            
            for i in range(count):
                try:
                    await client.send_message(
                        chat_id,
                        text,
                        reply_to=reply_to
                    )
                    sent_count += 1
                    
                    # Update progress setiap 5 pesan
                    if (i + 1) % 5 == 0:
                        progress = f"📤 {i + 1}/{count} ({((i + 1) / count * 100):.1f}%)"
                        try:
                            await processing_msg.edit(f"🚀 **SPAM REPLY**\n\n"
                                                     f"📊 Target: {count} pesan\n"
                                                     f"✅ Terkirim: {i + 1}\n"
                                                     f"📈 Progress: {progress}")
                        except:
                            pass
                    
                    # Delay antar pesan
                    await asyncio.sleep(config.SPAM_DELAY)
                    
                except Exception as e:
                    failed_count += 1
                    logger.error(f"Failed to send spam reply {i + 1}: {str(e)}")
                    
                    # Jika error flood wait, tunggu sebentar
                    if "FLOOD_WAIT" in str(e):
                        try:
                            wait_time = int(str(e).split()[-1])
                            await asyncio.sleep(wait_time + 1)
                        except:
                            await asyncio.sleep(5)
            
            # Report hasil
            result_msg = f"✅ **SPAM REPLY COMPLETE**\n\n"
            result_msg += f"📊 **Target:** {count} pesan\n"
            result_msg += f"✅ **Berhasil:** {sent_count} pesan\n"
            
            if failed_count > 0:
                result_msg += f"❌ **Gagal:** {failed_count} pesan\n"
            
            result_msg += f"⏱️ **Durasi:** {count * config.SPAM_DELAY:.1f} detik\n"
            result_msg += f"📝 **Pesan:**\n`{text[:50]}{'...' if len(text) > 50 else ''}`\n"
            result_msg += f"💬 **Reply to:** Pesan #{reply_to}"
            
            await processing_msg.edit(result_msg)
            
            # Log to group
            await send_log(
                client,
                f"🚀 SPAM REPLY EXECUTED\n"
                f"📊 Count: {count} messages\n"
                f"✅ Success: {sent_count}\n"
                f"❌ Failed: {failed_count}\n"
                f"💬 Reply to: Message #{reply_to}\n"
                f"📝 Text: {text[:100]}..."
            )
            
        except Exception as e:
            logger.error(f"Spamreply error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== SPAM FILE HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.spamfile(?:\s+(\d+))?\s+(.+)$'))
    async def spamfile_handler(event):
        """Spam with file (reply to file message)"""
        if event.sender_id != config.OWNER_ID:
            return
        
        # Check spam cooldown
        if not state.can_spam(event.sender_id):
            await event.reply("⏳ Tunggu sebentar sebelum menggunakan spam lagi! (Cooldown 1 menit)")
            return
        
        if not event.is_reply:
            await event.reply("❌ Reply pesan file yang ingin di-spam!")
            return
        
        try:
            reply_msg = await event.get_reply_message()
            
            if not reply_msg.file:
                await event.reply("❌ Pesan yang di-reply bukan file!")
                return
            
            # Parse arguments
            args = event.pattern_match.group(0).split(maxsplit=2)
            
            if len(args) < 3:
                count = 1
                caption = event.pattern_match.group(1) or ""
            else:
                count_part = args[1]
                caption = args[2]
                
                if count_part.isdigit():
                    count = int(count_part)
                else:
                    count = 1
                    caption = event.pattern_match.group(1)
            
            # Validasi count
            if count <= 0:
                await event.reply("❌ Jumlah harus lebih dari 0!")
                return
            
            if count > 25:  # Batas lebih kecil untuk file
                await event.reply("❌ Maksimal 25 file per spam!")
                return
            
            processing_msg = await event.reply(f"🚀 **MEMULAI SPAM FILE**\n\n"
                                              f"📊 Jumlah: {count} file\n"
                                              f"⏱️ Delay: 1.0s")
            
            sent_count = 0
            failed_count = 0
            
            for i in range(count):
                try:
                    await client.send_file(
                        event.chat_id,
                        reply_msg.media,
                        caption=caption if caption else None
                    )
                    sent_count += 1
                    
                    # Update progress setiap 2 pesan
                    if (i + 1) % 2 == 0:
                        progress = f"📤 {i + 1}/{count} ({((i + 1) / count * 100):.1f}%)"
                        try:
                            await processing_msg.edit(f"🚀 **SPAM FILE**\n\n"
                                                     f"📊 Target: {count} file\n"
                                                     f"✅ Terkirim: {i + 1}\n"
                                                     f"📈 Progress: {progress}")
                        except:
                            pass
                    
                    # Delay lebih lama untuk file
                    await asyncio.sleep(1.0)
                    
                except Exception as e:
                    failed_count += 1
                    logger.error(f"Failed to spam file {i + 1}: {str(e)}")
                    
                    # Jika error flood wait, tunggu sebentar
                    if "FLOOD_WAIT" in str(e):
                        try:
                            wait_time = int(str(e).split()[-1])
                            await asyncio.sleep(wait_time + 2)
                        except:
                            await asyncio.sleep(10)
            
            # Report hasil
            result_msg = f"✅ **SPAM FILE COMPLETE**\n\n"
            result_msg += f"📊 **Target:** {count} file\n"
            result_msg += f"✅ **Berhasil:** {sent_count} file\n"
            
            if failed_count > 0:
                result_msg += f"❌ **Gagal:** {failed_count} file\n"
            
            result_msg += f"⏱️ **Durasi:** {count * 1.0:.1f} detik"
            
            if caption:
                result_msg += f"\n📝 **Caption:**\n`{caption[:50]}{'...' if len(caption) > 50 else ''}`"
            
            await processing_msg.edit(result_msg)
            
            # Log to group
            await send_log(
                client,
                f"🚀 SPAM FILE EXECUTED\n"
                f"📊 Count: {count} files\n"
                f"✅ Success: {sent_count}\n"
                f"❌ Failed: {failed_count}"
            )
            
        except Exception as e:
            logger.error(f"Spamfile error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== KICK HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.kick(?:\s+(.+))?$'))
    async def kick_handler(event):
        """Kick user from group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .kick hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            
            # Cek jika reply pesan
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
            
            # Atau cek jika ada username/ID
            elif event.pattern_match.group(1):
                user_input = event.pattern_match.group(1).strip()
                
                if user_input.isdigit():
                    # Jika input adalah ID
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    # Jika input adalah username
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except Exception as e:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format: `.kick @username` atau reply pesan user")
                    return
            else:
                await event.reply("❌ Format: `.kick @username` atau reply pesan user")
                return
            
            if not target_user:
                await event.reply("❌ User tidak ditemukan!")
                return
            
            # Kick user dari grup
            try:
                await client.kick_participant(event.chat_id, target_user)
                await event.reply("✅ User berhasil dikeluarkan dari grup!")
                
                # Log to group
                await send_log(
                    client,
                    f"👢 USER DIKICK\n"
                    f"👤 User ID: {target_user}\n"
                    f"💬 Chat: {event.chat_id}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk menendang user!")
                elif "USER_NOT_PARTICIPANT" in error_msg:
                    await event.reply("❌ User tidak ditemukan dalam grup!")
                else:
                    await event.reply(f"❌ Gagal menendang user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Kick error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== BAN HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.ban(?:\s+(.+))?$'))
    async def ban_handler(event):
        """Ban user from group"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .ban hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            reason = ""
            
            # Parse arguments
            args = event.pattern_match.group(1)
            if args:
                parts = args.strip().split(maxsplit=1)
                user_input = parts[0]
                reason = parts[1] if len(parts) > 1 else "Tidak ada alasan"
            
            # Cek jika reply pesan
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
                if args:
                    reason = args.strip()
            
            # Atau cek jika ada username/ID
            elif user_input:
                if user_input.isdigit():
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format: `.ban @username [alasan]` atau reply pesan user")
                    return
            else:
                await event.reply("❌ Format: `.ban @username [alasan]` atau reply pesan user")
                return
            
            if not target_user:
                await event.reply("❌ User tidak ditemukan!")
                return
            
            try:
                # Ban user
                await client.edit_permissions(
                    event.chat_id,
                    target_user,
                    view_messages=False
                )
                
                ban_message = f"✅ User berhasil di-ban!"
                if reason:
                    ban_message += f"\n📌 Alasan: {reason}"
                
                await event.reply(ban_message)
                
                # Log to group
                await send_log(
                    client,
                    f"🚫 USER DI-BAN\n"
                    f"👤 User ID: {target_user}\n"
                    f"💬 Chat: {event.chat_id}\n"
                    f"📌 Reason: {reason}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk ban user!")
                else:
                    await event.reply(f"❌ Gagal ban user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Ban error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== TMUTE HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.tmute(?:\s+(.+))?$'))
    async def tmute_handler(event):
        """Temporary mute user"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .tmute hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            duration_str = ""
            reason = ""
            
            # Parse arguments
            args = event.pattern_match.group(1)
            if not args:
                await event.reply("❌ Format: `.tmute [waktu] [username/@] [alasan]` atau reply")
                return
            
            parts = args.strip().split(maxsplit=2)
            
            # Cek jika reply pesan
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
                duration_str = parts[0] if len(parts) > 0 else ""
                reason = parts[1] if len(parts) > 1 else "Tidak ada alasan"
            else:
                if len(parts) < 2:
                    await event.reply("❌ Format: `.tmute [waktu] [username/@] [alasan]`")
                    return
                
                duration_str = parts[0]
                user_input = parts[1]
                reason = parts[2] if len(parts) > 2 else "Tidak ada alasan"
                
                # Parse user input
                if user_input.isdigit():
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format username salah!")
                    return
            
            # Parse duration
            duration_seconds = 0
            try:
                if 'd' in duration_str or 'h' in duration_str or 'm' in duration_str or 's' in duration_str:
                    # Format: 1d, 2h, 30m, 45s
                    total_seconds = 0
                    import re
                    pattern = r'(\d+)([dhms])'
                    matches = re.findall(pattern, duration_str)
                    
                    for amount, unit in matches:
                        amount = int(amount)
                        if unit == 'd':
                            total_seconds += amount * 86400
                        elif unit == 'h':
                            total_seconds += amount * 3600
                        elif unit == 'm':
                            total_seconds += amount * 60
                        elif unit == 's':
                            total_seconds += amount
                    
                    duration_seconds = total_seconds
                else:
                    # Default: menit
                    duration_seconds = int(duration_str) * 60
                    
            except ValueError:
                await event.reply("❌ Format waktu salah! Contoh: `.tmute 30m @username alasan`")
                return
            
            if duration_seconds <= 0:
                await event.reply("❌ Durasi harus lebih dari 0!")
                return
            
            if duration_seconds > 30 * 86400:  # Max 30 hari
                await event.reply("❌ Durasi maksimal 30 hari!")
                return
            
            # Apply mute
            try:
                # Mute user di Telegram
                await client.edit_permissions(
                    event.chat_id,
                    target_user,
                    until_date=datetime.now() + timedelta(seconds=duration_seconds),
                    send_messages=False
                )
                
                # Simpan di state
                state.mute_user(target_user, duration_seconds, reason)
                
                # Format duration untuk display
                if duration_seconds >= 86400:
                    days = duration_seconds // 86400
                    hours = (duration_seconds % 86400) // 3600
                    duration_display = f"{days} hari {hours} jam"
                elif duration_seconds >= 3600:
                    hours = duration_seconds // 3600
                    minutes = (duration_seconds % 3600) // 60
                    duration_display = f"{hours} jam {minutes} menit"
                elif duration_seconds >= 60:
                    minutes = duration_seconds // 60
                    seconds = duration_seconds % 60
                    duration_display = f"{minutes} menit {seconds} detik"
                else:
                    duration_display = f"{duration_seconds} detik"
                
                mute_message = f"✅ User di-mute selama {duration_display}!"
                if reason:
                    mute_message += f"\n📌 Alasan: {reason}"
                
                await event.reply(mute_message)
                
                # Log to group
                await send_log(
                    client,
                    f"🔇 USER DI-MUTE\n"
                    f"👤 User ID: {target_user}\n"
                    f"⏰ Durasi: {duration_display}\n"
                    f"💬 Chat: {event.chat_id}\n"
                    f"📌 Reason: {reason}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk mute user!")
                else:
                    await event.reply(f"❌ Gagal mute user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Tmute error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== UNMUTE HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.unmute(?:\s+(.+))?$'))
    async def unmute_handler(event):
        """Unmute user"""
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_group:
            await event.reply("❌ Fitur .unmute hanya bisa digunakan di grup!")
            return
        
        try:
            target_user = None
            
            # Cek jika reply pesan
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                target_user = reply_msg.sender_id
            
            # Atau cek jika ada username/ID
            elif event.pattern_match.group(1):
                user_input = event.pattern_match.group(1).strip()
                
                if user_input.isdigit():
                    target_user = int(user_input)
                elif user_input.startswith('@'):
                    try:
                        user_entity = await client.get_entity(user_input)
                        target_user = user_entity.id
                    except:
                        await event.reply(f"❌ Tidak dapat menemukan user @{user_input[1:]}")
                        return
                else:
                    await event.reply("❌ Format: `.unmute @username` atau reply pesan user")
                    return
            else:
                await event.reply("❌ Format: `.unmute @username` atau reply pesan user")
                return
            
            if not target_user:
                await event.reply("❌ User tidak ditemukan!")
                return
            
            try:
                # Unmute user di Telegram
                await client.edit_permissions(
                    event.chat_id,
                    target_user,
                    send_messages=True
                )
                
                # Hapus dari state
                state.unmute_user(target_user)
                
                await event.reply("✅ User berhasil di-unmute!")
                
                # Log to group
                await send_log(
                    client,
                    f"🔊 USER DI-UNMUTE\n"
                    f"👤 User ID: {target_user}\n"
                    f"💬 Chat: {event.chat_id}"
                )
                
            except Exception as e:
                error_msg = str(e)
                if "CHAT_ADMIN_REQUIRED" in error_msg:
                    await event.reply("❌ Bot harus menjadi admin untuk unmute user!")
                else:
                    await event.reply(f"❌ Gagal unmute user: {error_msg}")
                    
        except Exception as e:
            logger.error(f"Unmute error: {str(e)}")
            await event.reply(f"❌ Error: {str(e)}")
    
    # ========== PAYMENT HANDLERS ==========
    @client.on(events.NewMessage(pattern=r'^\.pay (\d+)$'))
    async def pay_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        try:
            processing_msg = await event.reply("⏳ Memproses pembayaran...")
            
            nominal = int(event.pattern_match.group(1))
            if nominal < 1000:
                await processing_msg.edit("❌ Minimal transaksi Rp 1,000")
                return
            
            admin_fee = calculate_admin_fee(nominal)
            total_amount = nominal + admin_fee
            ref = random.randint(1000000, 99999999)
            
            await processing_msg.edit("🔗 Menghubungkan ke payment gateway...")
            
            async with httpx.AsyncClient(timeout=30.0) as http_client:
                response = await http_client.post(
                    'https://atlantich2h.com/deposit/create',
                    data={
                        "api_key": config.APIKEY_HOST,
                        "reff_id": ref,
                        "nominal": total_amount,
                        "type": "ewallet",
                        "metode": "qrisfast"
                    }
                )
            
            data = response.json()
            if not data.get('status'):
                await processing_msg.edit(f"❌ Error: {data.get('message', 'Unknown error')}")
                return
            
            trx = data['data']
            
            # Generate QR Code
            await processing_msg.edit("🎨 Membuat QR Code...")
            
            try:
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                    box_size=6,
                    border=2,
                )
                qr.add_data(trx['qr_string'])
                qr.make(fit=True)
                
                img = qr.make_image(fill_color="black", back_color="white")
                img_bytes = io.BytesIO()
                img.save(img_bytes, format='JPEG')
                img_bytes.seek(0)
                img_bytes.name = 'qrcode.jpg'
                
                caption = (
                    f"💰 DETAIL PEMBAYARAN\n\n"
                    f"💵 Nominal: {format_currency(nominal)}\n"
                    f"📦 Biaya Admin: {format_currency(admin_fee)}\n"
                    f"💠 Total Bayar: {format_currency(total_amount)}\n"
                    f"📊 Status: {trx['status'].upper()}\n\n"
                    f"📲 Scan QR Code di bawah ini:\n"
                    f"⏰ Berlaku 15 menit\n\n"
                    f"❌ Batalkan: Reply pesan ini dengan `.batal`"
                )
                
                await processing_msg.delete()
                sent_msg = await client.send_file(
                    event.chat_id,
                    file=img_bytes,
                    caption=caption
                )
                
                # Save transaction
                state.add_transaction(sent_msg.id, {
                    'trx_id': trx['id'],
                    'nominal': nominal,
                    'admin_fee': admin_fee,
                    'total_amount': total_amount,
                    'ref': ref,
                    'chat_id': event.chat_id,
                    'message_id': sent_msg.id,
                    'start_time': time.time()
                })
                
            except Exception as qr_error:
                # Fallback without QR
                caption = (
                    f"💰 DETAIL PEMBAYARAN\n\n"
                    f"💵 Nominal: {format_currency(nominal)}\n"
                    f"📦 Biaya Admin: {format_currency(admin_fee)}\n"
                    f"💠 Total Bayar: {format_currency(total_amount)}\n\n"
                    f"🔗 QR String: {trx.get('qr_string', 'Tidak tersedia')}\n\n"
                    f"⏰ Berlaku 15 menit\n"
                    f"❌ Batalkan: Reply `.batal`"
                )
                
                await processing_msg.delete()
                sent_msg = await event.reply(caption)
                
                state.add_transaction(sent_msg.id, {
                    'trx_id': trx['id'],
                    'nominal': nominal,
                    'admin_fee': admin_fee,
                    'total_amount': total_amount,
                    'ref': ref,
                    'chat_id': event.chat_id,
                    'message_id': sent_msg.id,
                    'start_time': time.time()
                })
            
            # Start monitoring
            asyncio.create_task(
                monitor_payment_status(
                    client, trx['id'], sent_msg.id, nominal, 
                    admin_fee, total_amount, event, ref
                )
            )
            
        except Exception as e:
            logger.error(f"Payment error: {str(e)}")
            try:
                await processing_msg.edit(f"❌ Error: {str(e)[:200]}")
            except:
                await event.reply(f"❌ Error: {str(e)[:200]}")
    
    # ========== SALDO HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.saldo$'))
    async def saldo_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        processing_msg = await event.reply("🔄 Memeriksa saldo...")
        
        try:
            balance = await get_atlantic_balance()
            best_product = await find_best_dana_product(balance)
            
            balance_msg = (
                f"💰 SALDO ATLANTICH2H\n\n"
                f"💎 Saldo Tersedia: {format_currency(int(balance))}\n\n"
            )
            
            if best_product:
                balance_msg += (
                    f"🎯 REKOMENDASI PENARIKAN\n"
                    f"📦 Produk: {best_product['nama']}\n"
                    f"💵 Biaya: {format_currency(best_product['harga'])}\n"
                    f"💎 Sisa Saldo: {format_currency(int(best_product['sisa_saldo']))}\n\n"
                    f"💡 Gunakan `.tarik 08xxxxxxx` untuk menarik otomatis\n"
                )
            else:
                balance_msg += (
                    f"❌ Tidak ada produk yang dapat dibeli\n"
                    f"💡 Produk termurah: DANA 1.000 ({format_currency(1250)})\n"
                    f"💎 Tambah saldo untuk bisa menarik dana\n\n"
                )
            
            await processing_msg.edit(balance_msg)
            
        except Exception as e:
            await processing_msg.edit(f"❌ Gagal memeriksa saldo:\n`{str(e)}`")
    
    # ========== TARIK HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.tarik (.+)$'))
    async def tarik_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        phone = event.pattern_match.group(1).strip()
        
        if not phone.isdigit() or len(phone) < 10:
            await event.reply("❌ Format nomor tidak valid!\nContoh: `.tarik 081234567890`")
            return
        
        masked_phone = mask_phone_number(phone)
        processing_msg = await event.reply(f"🔍 Memeriksa saldo...")
        
        try:
            balance = await get_atlantic_balance()
            
            if balance <= 0:
                await processing_msg.edit("❌ Saldo tidak mencukupi!")
                return
            
            best_product = await find_best_dana_product(balance)
            
            if not best_product:
                await processing_msg.edit(f"❌ Tidak ada produk yang dapat dibeli!")
                return
            
            await processing_msg.edit(
                f"🚀 MEMPROSES PENARIKAN\n\n"
                f"📱 Ke: `{masked_phone}`\n"
                f"💰 Produk: {best_product['nama']}\n"
                f"💵 Biaya: {format_currency(best_product['harga'])}\n"
                f"💎 Sisa: {format_currency(int(best_product['sisa_saldo']))}\n\n"
                f"⏳ Mohon tunggu..."
            )
            
            success = await process_dana_withdrawal(phone, best_product['code'], event, client)
            
            if success:
                await processing_msg.delete()
            else:
                await processing_msg.edit("❌ Gagal memproses penarikan")
                
        except Exception as e:
            await processing_msg.edit(f"❌ Error sistem:\n`{str(e)}`")
    
    # ========== PANEL HANDLERS ==========
    @client.on(events.NewMessage(pattern=r'^\.(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb|unli) (.+) (nodejs|python)$'))
    async def panel_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        command = event.pattern_match.group(1).lower()
        username = event.pattern_match.group(2).strip().lower()
        egg_type = event.pattern_match.group(3).lower()
        
        if not username:
            await event.reply("❌ Format salah!\nContoh: `.1gb username nodejs`")
            return
        
        processing_msg = await event.reply("🔄 Membuat panel server...")
        
        try:
            # Get resource configuration
            resource = config.PANEL_RESOURCES.get(command)
            if not resource:
                await processing_msg.edit("❌ Konfigurasi resource tidak ditemukan!")
                return
            
            # Get egg ID
            egg_id = config.PANEL_EGGS.get(egg_type)
            if not egg_id:
                await processing_msg.edit("❌ Egg tidak ditemukan!")
                return
            
            # Prepare user data
            email = f"{username}@gmail.com"
            name = f"{username} Server".title()
            password = f"{username}001"
            
            # Create user
            await processing_msg.edit("🔄 Membuat user panel...")
            user_result = await create_panel_user(username, email, name, password)
            
            if not user_result:
                await processing_msg.edit("❌ Gagal membuat user! Periksa koneksi ke panel.")
                return
            
            user_data = user_result.get('attributes', {})
            user_id = user_data.get('id')
            
            # Create server
            await processing_msg.edit("🔄 Membuat server panel...")
            server_result = await create_panel_server(
                name=name,
                user_id=user_id,
                egg_id=egg_id,
                ram=resource['ram'],
                disk=resource['disk'],
                cpu=resource['cpu'],
                egg_type=egg_type
            )
            
            if not server_result:
                await processing_msg.edit("❌ Gagal membuat server!")
                return
            
            server_data = server_result.get('attributes', {})
            
            # Format success message
            if resource['ram'] == 0:
                ram_display = "Unlimited"
                disk_display = "Unlimited"
                cpu_display = "Unlimited"
            else:
                ram_display = f"{resource['ram'] // 1000}GB"
                disk_display = f"{resource['disk'] // 1000}GB"
                cpu_display = f"{resource['cpu']}%"
            
            success_message = (
                f"✅ PANEL BERHASIL DIBUAT\n\n"
                f"📡 Server ID: {server_data.get('id', 'N/A')}\n"
                f"👤 Username: {user_data.get('username', 'N/A')}\n"
                f"🔐 Password: {password}\n"
                f"📧 Email: {email}\n"
                f"🐍 Tipe: {egg_type.upper()}\n\n"
                f"⚙️ SPESIFIKASI:\n"
                f"• RAM: {ram_display}\n"
                f"• Disk: {disk_display}\n"
                f"• CPU: {cpu_display}\n"
                f"• Panel: {config.PANEL_DOMAIN}\n\n"
                f"🔗 Login dengan credentials di atas"
            )
            
            await processing_msg.edit(success_message)
            
            # Send to done channels
            if state.done_channels:
                done_msg = (
                    f"<blockquote>✅ PANEL DIBUAT {random.choice(['🌟', '✨', '⭐'])}</blockquote>\n"
                    f"<blockquote><b>BARANG : PANEL {egg_type.upper()} {ram_display}</b>\n"
                    f"<b>USERNAME : {username}</b>\n"
                    f"<b>WAKTU : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</b></blockquote>\n"
                    f"<blockquote>TERIMAKASIH TELAH ORDER\nPESANAN SELESAI DIPROSES</blockquote>"
                    f"<blockquote>BY : PAYMENT BOT PAYMENT 🤖</blockquote>"
                )
                
                for channel in state.done_channels:
                    try:
                        await client.send_message(channel, done_msg, parse_mode='html')
                    except Exception as e:
                        logger.error(f"Failed to send to {channel}: {str(e)}")
                
        except Exception as e:
            logger.error(f"Panel creation error: {str(e)}")
            await processing_msg.edit(f"❌ Error membuat panel: {str(e)}")
    
    # ========== LIST PANEL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.listpanel$'))
    async def listpanel_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        processing_msg = await event.reply("🔄 Mengambil data server...")
        
        try:
            servers = await get_panel_servers()
            
            if not servers:
                await processing_msg.edit("❌ Tidak ada server panel!")
                return
            
            message_text = f"✅ Total server panel: {len(servers)}\n\n"
            
            for server in servers[:10]:  # Limit to 10 servers
                server_attrs = server.get('attributes', {})
                limits = server_attrs.get('limits', {})
                
                ram_mb = limits.get('memory', 0)
                disk_mb = limits.get('disk', 0)
                cpu_limit = limits.get('cpu', 0)
                
                ram = f"{ram_mb // 1000}GB" if ram_mb > 0 else "Unlimited"
                disk = f"{disk_mb // 1000}GB" if disk_mb > 0 else "Unlimited"
                cpu = "Unlimited" if cpu_limit == 0 else f"{cpu_limit}%"
                
                created_date = server_attrs.get('created_at', '').split('T')[0] if server_attrs.get('created_at') else 'N/A'
                
                message_text += (
                    f"• ID: {server_attrs.get('id', 'N/A')}\n"
                    f"  Nama: {server_attrs.get('name', 'N/A')}\n"
                    f"  RAM: {ram} | Disk: {disk}\n"
                    f"  CPU: {cpu} | Created: {created_date}\n\n"
                )
            
            if len(servers) > 10:
                message_text += f"📋 ... dan {len(servers) - 10} server lainnya"
            
            await processing_msg.edit(message_text)
            
        except Exception as e:
            await processing_msg.edit(f"❌ Error mengambil data server: {str(e)}")
    
    # ========== DEL PANEL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.delpanel (\d+)$'))
    async def delpanel_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        server_id = event.pattern_match.group(1).strip()
        
        if not server_id.isdigit():
            await event.reply("❌ ID server harus angka!")
            return
        
        processing_msg = await event.reply("🔄 Menghapus server panel...")
        
        try:
            success = await delete_panel_server(int(server_id))
            
            if success:
                await processing_msg.edit(f"✅ Server {server_id} berhasil dihapus!")
            else:
                await processing_msg.edit(f"❌ Gagal menghapus server {server_id}!")
                
        except Exception as e:
            await processing_msg.edit(f"❌ Error menghapus server: {str(e)}")
    
    # ========== BACKUP HANDLERS ==========
    @client.on(events.NewMessage(pattern=r'^\.backup$'))
    async def backup_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        processing_msg = await event.reply("💾 Membackup data...")
        
        if save_backup():
            await processing_msg.edit("✅ Backup berhasil!\nData tersimpan di `bot_backup.json`")
        else:
            await processing_msg.edit("❌ Gagal backup data!")
    
    @client.on(events.NewMessage(pattern=r'^\.restore$'))
    async def restore_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        processing_msg = await event.reply("🔄 Restore data...")
        
        if load_backup():
            await processing_msg.edit("✅ Restore berhasil!\nData telah dipulihkan")
        else:
            await processing_msg.edit("❌ Gagal restore data!")
    
    # ========== SESSION HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.session$'))
    async def session_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        if config.SESSION_STRING:
            shortened = config.SESSION_STRING[:50] + '...' if len(config.SESSION_STRING) > 50 else config.SESSION_STRING
            await event.reply(f"🔐 Session: ```{shortened}```")
        else:
            await event.reply("❌ Session tidak tersedia")
    
    # ========== HACKBACK HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.hbpanel (.+)$'))
    async def hbpanel_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        args = event.pattern_match.group(1).strip()
        parts = args.split(',')
        
        if len(parts) < 2:
            await event.reply("❌ Format: `.hbpanel ip,password`")
            return
        
        host = parts[0].strip()
        password = parts[1].strip()
        
        status_message = await event.reply(
            f"🔓 MEMULAI HACKBACK PANEL\n\n"
            f"📡 Target: `{host}`\n"
            f"🔐 Auth: `{password}`\n\n"
            f"⏳ Status: Initializing...\n"
            f"🕒 Waktu: {datetime.now().strftime('%H:%M:%S')}"
        )
        
        asyncio.create_task(
            hackback_panel_installation(
                host, password, event.chat_id, client, status_message.id
            )
        )
    
    # ========== DONE CHANNEL HANDLERS ==========
    @client.on(events.NewMessage(pattern=r'^\.adddone (.+)$'))
    async def adddone_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        channel = event.pattern_match.group(1).strip()
        
        if not channel.startswith('@'):
            await event.reply("❌ Format: `.adddone @username_channel`")
            return
        
        state.done_channels.add(channel)
        await event.reply(f"✅ Channel done ditambahkan:\n`{channel}`")
    
    @client.on(events.NewMessage(pattern=r'^\.listdone$'))
    async def listdone_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        if not state.done_channels:
            await event.reply("❌ Belum ada channel done!")
            return
        
        channels_list = "\n".join([f"• {channel}" for channel in state.done_channels])
        await event.reply(f"📋 Channel Done:\n{channels_list}")
    
    @client.on(events.NewMessage(pattern=r'^\.deldone (.+)$'))
    async def deldone_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        channel = event.pattern_match.group(1).strip()
        
        if channel in state.done_channels:
            state.done_channels.remove(channel)
            await event.reply(f"✅ Channel done dihapus:\n`{channel}`")
        else:
            await event.reply(f"❌ Channel tidak ditemukan:\n`{channel}`")
    
    # ========== AI TEST HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.ai(?:\s+(.+))?$'))
    async def ai_test_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        question = event.pattern_match.group(1)
        if not question:
            await event.reply("❌ Format: `.ai [pertanyaan]`")
            return
        
        processing_msg = await event.reply("🤖 AI sedang berpikir...")
        
        try:
            response = await ai_assistant.generate_response(question, "Test by Owner")
            await processing_msg.edit(f"🤖 AI RESPONSE:\n\n{response}")
        except Exception as e:
            await processing_msg.edit(f"❌ AI Error: {str(e)}")
    
    # ========== SET LOG GROUP HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.setloggroup$'))
    async def setloggroup_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_reply:
            await event.reply('❌ Reply pesan di grup yang ingin dijadikan log group!')
            return
        
        reply_msg = await event.get_reply_message()
        config.LOG_GROUP_ID = reply_msg.chat_id
        await event.reply(f"✅ Log group diatur ke: {config.LOG_GROUP_ID}")
    
    # ========== CANCEL HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.batal$'))
    async def cancel_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        if not event.is_reply:
            await event.reply('❌ Reply pesan transaksi!')
            return
        
        reply_msg = await event.get_reply_message()
        trx_data = state.active_transactions.get(reply_msg.id)
        
        if not trx_data:
            await event.reply('❌ Tidak ada transaksi aktif!')
            return
        
        try:
            # Delete message
            try:
                await reply_msg.delete()
            except:
                pass
            
            # Cancel transaction
            async with httpx.AsyncClient() as http_client:
                await http_client.post(
                    'https://atlantich2h.com/deposit/cancel',
                    data={"api_key": config.APIKEY_HOST, "id": trx_data['trx_id']}
                )
            
            await event.reply('✅ Transaksi dibatalkan!')
            state.remove_transaction(reply_msg.id)
            
        except Exception as e:
            await event.reply(f'❌ Gagal membatalkan: {str(e)}')
    
    # ========== STATUS HANDLER ==========
    @client.on(events.NewMessage(pattern=r'^\.status$'))
    async def status_handler(event):
        if event.sender_id != config.OWNER_ID:
            return
        
        stats = state.get_stats()
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        status_text = f"""
```📊 PAYMENT BOT MENU STATUS v3.1.0```

```🤖 BOT INFO:
• Owner: @andinsukaapink
• Uptime: {stats['uptime']}
• Version: 3.1.0
• Time: {current_time}

🚀 PERFORMANCE:
• Active Transactions: {stats['active_transactions']}
• Active Withdrawals: {stats['active_withdrawals']}
• AI Transactions: {stats['ai_transactions']}
• User Sessions: {stats['user_sessions']}
• Blacklist: {stats['blacklist_count']} chats

📈 STATISTICS:
• Total Transactions: {stats['transactions_processed']}
• Total Withdrawals: {stats['withdrawals_processed']}
• Panels Created: {stats['panels_created']}
• AI Responses: {stats['ai_responses']}
• Errors: {stats['errors']}

🤖 AI STATUS:
• AI Mode: {'🟢 ACTIVE' if stats['afk_mode'] else '🔴 INACTIVE'}
• AI Reason: {state.afk_reason if state.afk_mode else 'Not active'}
• AI Since: {format_date(state.afk_since) if state.afk_mode else 'N/A'}

💾 SYSTEM:
• Log Group: {config.LOG_GROUP_ID if config.LOG_GROUP_ID else 'Not set'}
• Backup File: {'✅ Exists' if os.path.exists(config.BACKUP_FILE) else '❌ Missing'}
• Session: {'✅ Valid' if config.SESSION_STRING else '❌ Invalid'}
• Blacklist File: {'✅ Exists' if os.path.exists(config.BLACKLIST_FILE) else '❌ Missing'}```
"""
        await event.reply(status_text)
    
    # ========== GLOBAL AI MESSAGE HANDLER ==========
    @client.on(events.NewMessage(incoming=True))
    async def global_message_handler(event):
        """Handle all incoming messages with AI when AFK mode is active"""
        
        # Skip jika bukan private message (1-on-1 chat)
        if not isinstance(event.peer_id, PeerUser):
            return
        
        user_id = event.sender_id
        
        # Skip jika sender adalah owner
        if user_id == config.OWNER_ID:
            return
        
        # Skip jika pesan berasal dari bot
        try:
            sender = await event.get_sender()
            if getattr(sender, 'bot', False):
                return  # Skip jika pengirim adalah bot
        except:
            pass
        
        # Skip jika tidak ada pesan teks
        if not event.message or not event.message.message:
            return
        
        message_text = event.raw_text.strip()
        
        # Skip jika pesan adalah command
        if message_text.startswith('.'):
            return
        
        # Hanya handle jika AFK mode aktif
        if not state.afk_mode:
            return
        
        # Update user session
        user_session = state.get_user_session(user_id)
        user_session['message_count'] += 1
        user_session['last_message'] = datetime.now()
        
        # Simulate typing dengan delay lebih lama (3-7 detik)
        delay_typing = random.uniform(3.0, 7.0)  # Delay typing yang lebih natural
        async with client.action(event.chat_id, 'typing'):
            await asyncio.sleep(delay_typing)
        
        # Tambahkan delay tambahan sebelum merespon (opsional, agar lebih natural)
        delay_response = random.uniform(0.5, 1.5)
        await asyncio.sleep(delay_response)
        
        # Get user info for context
        try:
            user = await client.get_entity(user_id)
            user_name = user.first_name or ""
            username = f"@{user.username}" if user.username else "No Username"
            user_context = f"User: {user_name} ({username}) | Messages: {user_session['message_count']}"
            
            # Tambahkan cek jika user adalah bot
            if getattr(user, 'bot', False):
                return  # Skip jika user adalah bot
        except:
            user_context = f"User ID: {user_id} | Messages: {user_session['message_count']}"
        
        # Generate AI response
        response = await ai_assistant.generate_response(message_text, user_context)
        
        # Send response
        await event.reply(response)
        
        # Log AI response
        logger.info(f"AI Response to {user_id}: {response[:100]}...")
        
        # Send to log group if set
        if config.LOG_GROUP_ID:
            log_msg = (
                f"🤖 AI RESPONSE LOG\n\n"
                f"👤 User: {user_context}\n"
                f"💬 Message: `{message_text[:100]}`\n"
                f"🤖 Response: `{response[:150]}`\n"
                f"⏰ Time: {datetime.now().strftime('%H:%M:%S')}"
            )
            await client.send_message(config.LOG_GROUP_ID, log_msg)

# =============================================
# AUTO CFD FUNCTION
# =============================================

async def run_auto_cfd(client: TelegramClient):
    """Run auto CFD forwarding"""
    if not state.auto_cfd_state["running"]:
        return
    
    try:
        reply_msg_id = state.auto_cfd_state["reply_msg_id"]
        origin_chat_id = state.auto_cfd_state["origin_chat_id"]
        
        if not reply_msg_id or not origin_chat_id:
            return
        
        # Get all dialogs
        dialogs = await client.get_dialogs()
        
        success_count = 0
        fail_count = 0
        
        # Forward to all groups not in blacklist
        for dialog in dialogs:
            if dialog.is_group and not state.is_blacklisted(str(dialog.id)):
                try:
                    await client.forward_messages(
                        dialog.id,
                        reply_msg_id,
                        from_peer=origin_chat_id
                    )
                    success_count += 1
                    await asyncio.sleep(0.5)  # Delay to avoid flood
                except Exception as e:
                    fail_count += 1
                    logger.error(f"Auto CFD failed to forward to {dialog.id}: {str(e)}")
        
        # Log result
        logger.info(f"Auto CFD executed: Success={success_count}, Failed={fail_count}")
        
        # Send to log group if set
        if config.LOG_GROUP_ID:
            log_msg = (
                f"🤖 AUTO CFD EXECUTED\n\n"
                f"✅ Success: {success_count} groups\n"
                f"❌ Failed: {fail_count} groups\n"
                f"⏰ Time: {datetime.now().strftime('%H:%M:%S')}"
            )
            await client.send_message(config.LOG_GROUP_ID, log_msg)
            
    except Exception as e:
        logger.error(f"Auto CFD error: {str(e)}")

# =============================================
# PAYMENT MONITORING
# =============================================

async def monitor_payment_status(client: TelegramClient, trx_id: str, msg_id: int, 
                                nominal: int, admin_fee: int, total_amount: int, 
                                event, ref: str):
    """Monitor payment status"""
    max_attempts = config.PAYMENT_TIMEOUT // 3  # Check every 3 seconds
    attempts = 0
    
    while attempts < max_attempts:
        await asyncio.sleep(3)
        attempts += 1
        
        # Check if transaction still exists
        if msg_id not in state.active_transactions:
            logger.info(f"Transaction {msg_id} no longer active, stopping monitoring")
            return
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    'https://atlantich2h.com/deposit/status',
                    data={"api_key": config.APIKEY_HOST, "id": trx_id}
                )
            
            data = response.json()
            status_data = data.get('data', {})
            status = status_data.get('status', '').lower()
            
            # Handle cancelled/expired
            if status in ['cancel', 'expired']:
                try:
                    msg = await client.get_messages(event.chat_id, ids=msg_id)
                    if msg:
                        await msg.delete()
                except:
                    pass
                
                await event.reply(f"❌ Transaksi {status}")
                state.remove_transaction(msg_id)
                return
            
            # Handle success
            if status in ['success', 'paid', 'completed']:
                try:
                    msg = await client.get_messages(event.chat_id, ids=msg_id)
                    if msg:
                        await msg.delete()
                except:
                    pass
                
                success_msg = (
                    f"✅ PEMBAYARAN BERHASIL!\n\n"
                    f"💵 Nominal: {format_currency(nominal)}\n"
                    f"📦 Biaya Admin: {format_currency(admin_fee)}\n"
                    f"💰 Total: {format_currency(total_amount)}\n"
                    f"🆔 Ref: {ref}\n"
                    f"🕒 Waktu: {datetime.now().strftime('%H:%M:%S')}\n\n"
                    f"🎉 Terima kasih! Pesanan diproses."
                )
                
                await event.reply(success_msg)
                
                # Send to log group
                await send_log(client,
                    f"✅ PAYMENT SUCCESS\n"
                    f"💵 Nominal: {format_currency(nominal)}\n"
                    f"📦 Admin Fee: {format_currency(admin_fee)}\n"
                    f"💰 Total: {format_currency(total_amount)}\n"
                    f"🆔 Ref: {ref}"
                )
                
                state.remove_transaction(msg_id)
                return
                
        except Exception as e:
            logger.error(f"Payment status check error: {str(e)}")
            continue
    
    # Timeout
    try:
        msg = await client.get_messages(event.chat_id, ids=msg_id)
        if msg:
            await msg.delete()
    except:
        pass
    
    await event.reply("⏰ Waktu pembayaran habis")
    state.remove_transaction(msg_id)

# =============================================
# SESSION MANAGEMENT
# =============================================

async def generate_session_string() -> Optional[str]:
    """Generate new session string"""
    try:
        temp_client = TelegramClient(StringSession(), config.API_ID, config.API_HASH)
        await temp_client.start()
        
        me = await temp_client.get_me()
        session_string = temp_client.session.save()
        
        await temp_client.send_message('me', f"🔐 SESSION STRING\n```{session_string}```")
        await temp_client.disconnect()
        
        logger.info("New session string generated")
        return session_string
        
    except Exception as e:
        logger.error(f"Failed to generate session: {str(e)}")
        return None

async def load_session() -> Optional[str]:
    """Load session from various sources"""
    # Try environment variable
    session_string = os.getenv('SESSION_STRING', '').strip()
    if session_string:
        logger.info("Session loaded from environment")
        return session_string
    
    # Try session file
    try:
        if os.path.exists(config.SESSION_FILE):
            with open(config.SESSION_FILE, 'r') as f:
                session_string = f.read().strip()
                if session_string:
                    logger.info("Session loaded from file")
                    return session_string
    except Exception as e:
        logger.error(f"Failed to load session from file: {str(e)}")
    
    return None

async def save_session(session_string: str):
    """Save session to file"""
    try:
        with open(config.SESSION_FILE, 'w') as f:
            f.write(session_string)
        logger.info("Session saved to file")
    except Exception as e:
        logger.error(f"Failed to save session: {str(e)}")

# =============================================
# CLIENT INITIALIZATION
# =============================================

async def initialize_client() -> Optional[TelegramClient]:
    """Initialize Telegram client"""
    try:
        # Load or generate session
        session_string = await load_session()
        
        if not session_string:
            logger.info("No session found, generating new one...")
            session_string = await generate_session_string()
            if not session_string:
                logger.error("Failed to generate session")
                return None
            
            await save_session(session_string)
        
        # Update config
        config.SESSION_STRING = session_string
        
        # Create client
        session = StringSession(session_string)
        client = TelegramClient(session, config.API_ID, config.API_HASH)
        
        # Connect
        await client.start()
        
        # Get user info
        me = await client.get_me()
        logger.info(f"✅ Logged in as: {me.first_name} (@{me.username}) | ID: {me.id}")
        
        return client
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize client: {str(e)}")
        return None

# =============================================
# SIGNAL HANDLING
# =============================================

def setup_signal_handlers():
    """Setup signal handlers for graceful shutdown"""
    
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, shutting down gracefully...")
        
        # Save backup before exit
        save_backup()
        
        logger.info("Bot shutdown complete")
        sys.exit(0)
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

# =============================================
# MAIN FUNCTION
# =============================================

async def main():
    """Main function"""
    
    # Setup signal handlers
    setup_signal_handlers()
    
    logger.info("=" * 50)
    logger.info("🤖 PAYMENT BOT PAYMENT STARTING...")
    logger.info("=" * 50)
    
    # DEBUG LOG
    logger.info(f"Config OWNER_ID: {config.OWNER_ID}")
    logger.info(f"Config API_ID: {config.API_ID}")
    logger.info(f"Session string exists: {'YES' if config.SESSION_STRING else 'NO'}")
    
    # Load backup data
    load_backup()
    
    # Initialize Telegram client
    logger.info("Initializing Telegram client...")
    client = await initialize_client()
    if not client:
        logger.error("❌ Failed to initialize Telegram client")
        
        # Try to generate new session
        logger.info("Trying to generate new session...")
        from telethon.sessions import StringSession
        temp_client = TelegramClient(StringSession(), config.API_ID, config.API_HASH)
        await temp_client.start()
        session_string = temp_client.session.save()
        
        # Save session
        with open("session.txt", "w") as f:
            f.write(session_string)
        
        await temp_client.send_message('me', f"🔐 New session generated!")
        await temp_client.disconnect()
        
        logger.info("✅ New session generated and saved. Please restart bot.")
        return
    
    # Setup handlers dengan error handling
    try:
        logger.info("Setting up event handlers...")
        await setup_handlers(client)
        logger.info("✅ Handlers setup completed")
    except Exception as e:
        logger.error(f"❌ Failed to setup handlers: {str(e)}")
        return
    
    # Bot info
    stats = state.get_stats()
    logger.info("=" * 50)
    logger.info("✅ BOT STARTED SUCCESSFULLY!")
    logger.info(f"👑 Owner ID: {config.OWNER_ID}")
    logger.info(f"🤖 AFK Mode: {'ACTIVE' if state.afk_mode else 'INACTIVE'}")
    logger.info(f"📊 Active Transactions: {stats['active_transactions']}")
    logger.info(f"💾 Backup Status: {'✅' if os.path.exists(config.BACKUP_FILE) else '❌'}")
    logger.info(f"🌐 Panel Domain: {config.PANEL_DOMAIN}")
    logger.info(f"🚫 Blacklist Entries: {len(state.blacklist)}")
    logger.info("=" * 50)
    logger.info("Use .menu for commands")
    logger.info("Use .test to check if bot responds")
    logger.info("=" * 50)
    
    # Auto-backup task
    async def auto_backup_task():
        while True:
            await asyncio.sleep(300)  # Every 5 minutes
            if state.afk_mode or len(state.active_transactions) > 0:
                save_backup()
                logger.debug("Auto-backup completed")
    
    # Auto-cleanup task
    async def auto_cleanup_task():
        while True:
            await asyncio.sleep(3600)  # Every hour
            
            # Clean old user sessions
            current_time = time.time()
            to_remove = []
            for user_id, session in state.user_sessions.items():
                last_message = session.get('last_message')
                if last_message and (current_time - last_message.timestamp() > 86400):
                    to_remove.append(user_id)
            
            for user_id in to_remove:
                del state.user_sessions[user_id]
            
            if to_remove:
                logger.info(f"Cleaned {len(to_remove)} old user sessions")
            
            # Clean expired mutes
            expired_mutes = []
            for user_id, mute_data in state.muted_users.items():
                if current_time > mute_data.get("until", 0):
                    expired_mutes.append(user_id)
            
            for user_id in expired_mutes:
                del state.muted_users[user_id]
            
            if expired_mutes:
                logger.info(f"Auto-unmuted {len(expired_mutes)} users")
    
    # Start background tasks
    asyncio.create_task(auto_backup_task())
    asyncio.create_task(auto_cleanup_task())
    
    # Run until disconnected
    await client.run_until_disconnected()
    
    # Save final backup
    save_backup()
    logger.info("Bot stopped")

# =============================================
# ENTRY POINT
# =============================================

if __name__ == "__main__":
    # Create necessary directories
    os.makedirs("logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    
    # Run main function
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")
        traceback.print_exc()
    finally:
        logger.info("Bot shutdown complete") 